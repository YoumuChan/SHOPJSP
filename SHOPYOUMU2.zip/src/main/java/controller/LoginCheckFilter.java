package controller;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter(urlPatterns = {"/mypage.jsp", "/InProduct.jsp"})
public class LoginCheckFilter implements Filter {

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession();

        // 🌟 이름표 통일: 'loginUser' 하나만 검사합니다.
        if (session.getAttribute("loginUser") == null) {
            
            // 사용자가 가려고 했던 전체 주소를 nextPage에 킵합니다.
            String requestURI = req.getRequestURI();
            session.setAttribute("nextPage", requestURI);
            
            // 로그인 페이지로 이송
            res.sendRedirect(req.getContextPath() + "/login.jsp");
        } else {
            // 로그인 되어 있으면 통과
            chain.doFilter(request, response);
        }
    }
}