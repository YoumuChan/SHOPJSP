package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginAction")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String userId = request.getParameter("id");
        String userPw = request.getParameter("pw");
        
        if ("admin".equals(userId) && "1234".equals(userPw)) {
            HttpSession session = request.getSession();
            
            // 🌟 [상단바 구원투수] nav.jsp와 옛날 페이지가 인식할 수 있게 모든 세션 이름표를 다 꽂아줍니다.
            session.setAttribute("loginUser", userId);    // 새 필터용[cite: 18]
            session.setAttribute("sessionId", userId);    // 기존 nav.jsp ID 표기용
            session.setAttribute("sessionName", "관리자"); // 기존 nav.jsp 이름 표기용
            session.setAttribute("isAdmin", true);     
            
            session.setMaxInactiveInterval(60 * 30); // 30분 유지[cite: 18]
            
            // 필터가 세션에 저장해둔 목적지 주소가 있는지 확인
            String nextPage = (String) session.getAttribute("nextPage");
            
            if (nextPage != null && !nextPage.trim().isEmpty()) {
                session.removeAttribute("nextPage"); // 청소
                response.sendRedirect(nextPage);     // 원래 가려던 상품 등록창으로 직행
            } else {
                response.sendRedirect(request.getContextPath() + "/main.jsp");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=true");
        }
    }
}