package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    public static Connection getConnection() {
        Connection conn = null;
        try {
            // ojdbc8 드라이버 로드
            Class.forName("oracle.jdbc.OracleDriver");
            
            // Oracle 18c XE thin 접속 URL 및 계정 정보
            String url = "jdbc:oracle:thin:@localhost:1521/xepdb1"; // 또는 @localhost:1521:xe
            String user = "C##dbexam";
            String password = "oracle"; // 설정하신 비밀번호

            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC 드라이버 로드 실패: ojdbc8.jar를 확인하세요.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("DB 연결 실패: 계정, 비밀번호 또는 리스너 상태를 확인하세요.");
            e.printStackTrace();
        }
        return conn;
    }
}