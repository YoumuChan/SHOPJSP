<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
        response.sendRedirect("login.jsp");
        return;
    }

    String numStr = request.getParameter("num");
    String pageNumStr = request.getParameter("pageNum");

    if (numStr == null || numStr.trim().isEmpty()) {
        response.sendRedirect("list.jsp");
        return;
    }

    int num = Integer.parseInt(numStr);

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // 작성자 본인이거나 admin일 때만 삭제 처리
        String sql = "";
        if ("admin".equalsIgnoreCase(sessionId)) {
            sql = "DELETE FROM board WHERE num = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, num);
        } else {
            sql = "DELETE FROM board WHERE num = ? AND id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, num);
            pstmt.setString(2, sessionId.trim());
        }

        int result = pstmt.executeUpdate();

        if (result > 0) {
%>
            <script>
                alert("게시글이 삭제되었습니다.");
                location.href = "list.jsp?pageNum=<%= pageNumStr %>";
            </script>
<%
        } else {
%>
            <script>
                alert("삭제 권한이 없거나 게시글 삭제에 실패했습니다.");
                history.back();
            </script>
<%
        }
    } catch (Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("삭제 중 오류: <%= e.getMessage() %>");
            history.back();
        </script>
<%
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>