<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.net.URLDecoder" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>orderConfirmation</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<%
    request.setCharacterEncoding("utf-8");

    String Shipping_cartId = "";
    String Shipping_name = "";
    String Shipping_date = "";
    String Shipping_address = "";
    String Shipping_postId = "";

    // 🌟 강사님 화면 코드 100% 동일 루프 적용
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
        for (int i = 0; i < cookies.length; i++) {
            Cookie thisCookie = cookies[i];
            String n = thisCookie.getName();
            if (n.equals("Shipping_cartId")) Shipping_cartId = URLDecoder.decode(thisCookie.getValue(), "utf-8");
            if (n.equals("Shipping_name")) Shipping_name = URLDecoder.decode(thisCookie.getValue(), "utf-8");
            if (n.equals("Shipping_date")) Shipping_date = URLDecoder.decode(thisCookie.getValue(), "utf-8");
            if (n.equals("Shipping_address")) Shipping_address = URLDecoder.decode(thisCookie.getValue(), "utf-8");
            if (n.equals("Shipping_postId")) Shipping_postId = URLDecoder.decode(thisCookie.getValue(), "utf-8");
        }
    }

    ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartList");
    if (cartList == null || cartList.isEmpty()) {
        response.sendRedirect("Products.jsp");
        return;
    }

    int sum = 0;
    DecimalFormat formatter = new DecimalFormat("#,###");
%>

    <% request.setAttribute("currentPage", "주문 확인"); %>
    <jsp:include page="nav.jsp" />
    </div>

    <div class="container my-5" style="max-width: 850px; min-height: 600px; padding: 40px 15px;">
        <div class="text-center mb-4">
            <h2 style="font-weight: 800; color: #222;">📦 주문 정보 확인</h2>
            <p style="color: #666;">입력하신 배송 정보와 장바구니 상품 목록을 확인해 주세요.</p>
        </div>

        <!-- 배송 정보 카드 -->
        <div class="card mb-4" style="border: 1px solid #e9ecef; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
            <div class="card-header text-white" style="background-color: #252525; font-weight: bold; font-size: 16px;">
                배송지 정보
            </div>
            <div class="card-body" style="background-color: #ffffff; padding: 25px;">
                <div class="row mb-2">
                    <div class="col-sm-3 fw-bold" style="color: #555;">주문 번호 (Cart ID)</div>
                    <div class="col-sm-9"><%= Shipping_cartId %></div>
                </div>
                <div class="row mb-2">
                    <div class="col-sm-3 fw-bold" style="color: #555;">성명</div>
                    <div class="col-sm-9"><%= Shipping_name %></div>
                </div>
                <div class="row mb-2">
                    <div class="col-sm-3 fw-bold" style="color: #555;">우편번호</div>
                    <div class="col-sm-9"><%= Shipping_postId %></div>
                </div>
                <div class="row mb-2">
                    <div class="col-sm-3 fw-bold" style="color: #555;">주소</div>
                    <div class="col-sm-9"><%= Shipping_address %></div>
                </div>
                <div class="row">
                    <div class="col-sm-3 fw-bold" style="color: #555;">배송일</div>
                    <div class="col-sm-9"><%= Shipping_date %></div>
                </div>
            </div>
        </div>

        <!-- 주문 상품 목록 카드 -->
        <div class="card mb-4" style="border: 1px solid #e9ecef; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
            <div class="card-header text-white" style="background-color: #252525; font-weight: bold; font-size: 16px;">
                주문 상품 목록
            </div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0" style="vertical-align: middle;">
                    <thead style="background-color: #f8f9fa;">
                        <tr class="text-center">
                            <th style="text-align: left; padding: 15px 20px;">상품명</th>
                            <th style="width: 20%;">가격</th>
                            <th style="width: 15%;">수량</th>
                            <th style="width: 20%;">소계</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                            for (Product product : cartList) {
                                int quantity = 1;
                                int totalProductPrice = product.getUnitPrice() * quantity;
                                sum += totalProductPrice;
                        %>
                        <tr class="text-center">
                            <td style="text-align: left; padding: 15px 20px; font-weight: bold;"><%= product.getNameString() %></td>
                            <td><%= formatter.format(product.getUnitPrice()) %>원</td>
                            <td><%= quantity %></td>
                            <td style="color: #ff0000; font-weight: bold;"><%= formatter.format(totalProductPrice) %>원</td>
                        </tr>
                        <%
                            }
                        %>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-end bg-white py-3" style="border-top: 1px solid #dee2e6;">
                <h4 style="font-weight: bold; margin: 0;">
                    총 결제 금액: <span style="color: #ff0000; font-size: 24px;"><%= formatter.format(sum) %></span>원
                </h4>
            </div>
        </div>

        <!-- 버튼 영역 -->
        <div class="d-flex justify-content-between mb-5">
            <a href="shippingInfo.jsp" class="btn btn-secondary px-4 py-2">이전</a>
            <div class="d-flex gap-2">
                <a href="checkOutCancelled.jsp" class="btn btn-danger px-4 py-2">주문 취소</a>
                <a href="thankCustomer.jsp" class="btn btn-success px-4 py-2 fw-bold text-white">주문 완료</a>
            </div>
        </div>
    </div>

    <jsp:include page="footer.jsp" />
</body>
</html>