<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<jsp:include page="nav.jsp" />

<div class="container" style="padding: 60px 15px; min-height: 600px;">
    <div class="row">
        <div class="col-md-12">
            <h2 style="font-weight: bold; margin-bottom: 30px; color: #222;">
                🛒 Shopping Cart
            </h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-hover" style="border-bottom: 1px solid #dee2e6;">
                <thead class="thead-dark" style="background-color: #252525; color: #fff;">
                    <tr>
                        <th scope="col" style="width: 40%;">상품명</th>
                        <th scope="col" style="text-align: center; width: 20%;">가격</th>
                        <th scope="col" style="text-align: center; width: 15%;">수량</th>
                        <th scope="col" style="text-align: center; width: 15%;">소계</th>
                        <th scope="col" style="text-align: center; width: 10%;">비우기</th>
                    </tr>
                </thead>
                <tbody>
                    <%
                        ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartList");
                        int sum = 0;
                        DecimalFormat formatter = new DecimalFormat("#,###");

                        if (cartList == null || cartList.isEmpty()) {
                    %>
                        <!-- 🛒 장바구니가 비었을 때 쇼핑 계속하기 버튼 배치 -->
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 60px 0; color: #666;">
                                <p style="font-size: 18px; font-weight: bold; margin-bottom: 20px;">장바구니가 텅 비었습니다.</p>
                                <a href="Products.jsp" class="btn btn-warning" style="font-weight: bold; color: #fff; background-color: #ffc107; border-color: #ffc107; padding: 12px 30px; font-size: 15px; border-radius: 4px; box-shadow: 0 4px 10px rgba(255,193,7,0.3);">
                                    🛍️ 쇼핑 계속하기
                                </a>
                            </td>
                        </tr>
                    <%
                        } else {
                            for (Product product : cartList) {
                                int quantity = 1; 
                                int totalProductPrice = product.getUnitPrice() * quantity;
                                sum += totalProductPrice;
                    %>
                        <tr style="vertical-align: middle;">
                            <td style="font-weight: bold; padding: 15px;"><%= product.getNameString() %></td>
                            <td style="text-align: center;"><%= formatter.format(product.getUnitPrice()) %>원</td>
                            <td style="text-align: center;"><%= quantity %></td>
                            <td style="text-align: center; color: #ff0000; font-weight: bold;"><%= formatter.format(totalProductPrice) %>원</td>
                            <td style="text-align: center;">
                                <a href="javascript:removeFromCart('<%= product.getProductIDString() %>')" class="badge badge-danger" style="padding: 6px 10px; background-color: #ff0000; color:#fff; text-decoration:none; border-radius:4px;">삭제</a>
                            </td>
                        </tr>
                    <%
                            }
                        }
                    %>
                </tbody>
            </table>
        </div>
    </div>

    <% if (cartList != null && !cartList.isEmpty()) { %>
    <div class="row" style="margin-top: 30px;">
        <div class="col-md-12" style="text-align: right;">
            <h4 style="font-weight: bold; margin-bottom: 20px;">
                총 결제 금액: <span style="color: #ff0000; font-size: 24px;"><%= formatter.format(sum) %></span>원
            </h4>
            <a href="javascript:clearCart()" class="btn btn-outline-danger" style="margin-right: 10px; padding: 10px 20px;">장바구니 전체 비우기</a>
            <a href="shippingInfo.jsp" class="btn btn-dark" style="background-color: #252525; padding: 10px 30px; font-weight: bold;">주문하기</a>
        </div>
    </div>
    <% } %>
</div>

<jsp:include page="footer.jsp" />

<script src="js/cart.js"></script>

</body>
</html>