<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<% request.setAttribute("currentPage", "로그인"); %>
<jsp:include page="nav.jsp" />

<style>
    .auth-container {
        min-height: 80vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #fafafa;
        padding: 60px 20px;
    }

    /* 옆으로 넉넉하게 확장된 카드 너비 */
    .auth-card {
        background: #ffffff;
        border: 1px solid #eaeaea;
        border-radius: 12px;
        width: 100%;
        max-width: 520px;
        padding: 50px 45px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
    }

    .auth-title {
        font-size: 26px;
        font-weight: 700;
        color: #111111;
        letter-spacing: -0.5px;
        margin-bottom: 8px;
    }

    .auth-subtitle {
        font-size: 14px;
        color: #767676;
        margin-bottom: 36px;
    }

    .auth-field {
        margin-bottom: 22px;
    }

    .auth-label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #333333;
        margin-bottom: 8px;
    }

    .auth-input {
        width: 100%;
        height: 50px;
        padding: 0 16px;
        background-color: #f8f9fa;
        border: 1px solid #e1e4e8;
        border-radius: 8px;
        font-size: 14px;
        color: #111111;
        outline: none;
        transition: all 0.2s ease;
        box-sizing: border-box;
    }

    .auth-input:focus {
        background-color: #ffffff;
        border-color: #111111;
    }

    .auth-input::placeholder {
        color: #aaa;
    }

    .btn-auth-submit {
        width: 100%;
        height: 52px;
        background-color: #111111;
        color: #ffffff;
        border: none;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: background-color 0.2s;
        margin-top: 10px;
    }

    .btn-auth-submit:hover {
        background-color: #333333;
    }

    .auth-footer {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 16px;
        margin-top: 30px;
        padding-top: 24px;
        border-top: 1px solid #f1f1f1;
        font-size: 13px;
        color: #666;
    }

    .auth-footer a {
        color: #555;
        text-decoration: none;
        font-weight: 500;
        transition: color 0.2s;
    }

    .auth-footer a:hover {
        color: #111;
    }

    .auth-footer span {
        color: #e0e0e0;
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <h2 class="auth-title">로그인</h2>
        <p class="auth-subtitle">COFFO 계정으로 로그인하여 서비스를 이용해보세요.</p>

        <form action="loginProcess.jsp" method="post">
            <div class="auth-field">
                <label class="auth-label">아이디</label>
                <input type="text" name="id" class="auth-input" placeholder="아이디 입력" required autocomplete="off">
            </div>

            <div class="auth-field">
                <label class="auth-label">비밀번호</label>
                <input type="password" name="pw" class="auth-input" placeholder="비밀번호 입력" required>
            </div>

            <button type="submit" class="btn-auth-submit">로그인</button>
        </form>

        <div class="auth-footer">
            <a href="register.jsp">회원가입</a>
            <span>•</span>
            <a href="Products.jsp">상품 둘러보기</a>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>