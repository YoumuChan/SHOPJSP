<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:include page="nav.jsp" />

<div class="login_section" style="background-color: #f4f5f7; padding: 100px 0;">
    <div class="container" style="max-width: 450px; margin: 0 auto;">
        <div class="card" style="background: #fff; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); padding: 45px 35px;">
            <h2 style="text-align: center; font-weight: 900; color: #111; margin-bottom: 35px; border-bottom: 3px solid #252525; padding-bottom: 10px; width: 100%;">LOGIN</h2>
            
            <form action="loginProcess.jsp" method="post">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">아이디</label>
                    <input type="text" name="id" placeholder="관리자 ID: admin" required 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <div style="margin-bottom: 30px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">비밀번호</label>
                    <input type="password" name="pw" placeholder="비밀번호 입력" required 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <button type="submit" style="width: 100%; height: 55px; background-color: #252525; color: #fff; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer;">로그인</button>
            </form>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>