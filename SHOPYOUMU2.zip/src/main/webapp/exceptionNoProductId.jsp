<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>상품 아이디 오류</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="container my-5 text-center" style="min-height: 450px; padding-top: 60px;">
        <div class="alert alert-danger py-4" style="max-width: 600px; margin: 0 auto;">
            <h2 class="fw-bold mb-0">해당 상품이 존재하지 않습니다.</h2>
        </div>
        
        <p class="text-muted mt-4">
            요청 주소: <%= request.getRequestURL() %>?<%= request.getQueryString() %>
        </p>

        <div class="mt-4">
            <a href="Products.jsp" class="btn btn-secondary px-4 py-2">상품 목록 &raquo;</a>
        </div>
    </div>

    <jsp:include page="footer.jsp" />
</body>
</html>