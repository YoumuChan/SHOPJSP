<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // 현재 세션을 완전히 초기화하여 로그인 정보 날리기
    session.invalidate();
    
    // 로그아웃 완료 후 메인 페이지로 이동
    response.sendRedirect("main.jsp");
%>