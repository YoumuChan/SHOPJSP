<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.net.URLEncoder" %>
<%
    request.setCharacterEncoding("UTF-8");

    String cartId = request.getParameter("cartId");
    String name = request.getParameter("name");
    String shippingDate = request.getParameter("shippingDate");
    // 🌟 addressName 파라미터와 매핑 일치
    String address = request.getParameter("addressName");
    if (address == null) address = request.getParameter("address");
    String postId = request.getParameter("zipCode");

    if (cartId == null || cartId.trim().isEmpty()) {
        cartId = session.getId();
    }

    Cookie cookie_cartId = new Cookie("Shipping_cartId", URLEncoder.encode(cartId != null ? cartId : "", "UTF-8"));
    Cookie cookie_name = new Cookie("Shipping_name", URLEncoder.encode(name != null ? name : "", "UTF-8"));
    Cookie cookie_date = new Cookie("Shipping_date", URLEncoder.encode(shippingDate != null ? shippingDate : "", "UTF-8"));
    Cookie cookie_address = new Cookie("Shipping_address", URLEncoder.encode(address != null ? address : "", "UTF-8"));
    Cookie cookie_postId = new Cookie("Shipping_postId", URLEncoder.encode(postId != null ? postId : "", "UTF-8"));

    cookie_cartId.setMaxAge(24 * 60 * 60);
    cookie_name.setMaxAge(24 * 60 * 60);
    cookie_date.setMaxAge(24 * 60 * 60);
    cookie_address.setMaxAge(24 * 60 * 60);
    cookie_postId.setMaxAge(24 * 60 * 60);

    response.addCookie(cookie_cartId);
    response.addCookie(cookie_name);
    response.addCookie(cookie_date);
    response.addCookie(cookie_address);
    response.addCookie(cookie_postId);

    response.sendRedirect("orderConfirmation.jsp");
%>