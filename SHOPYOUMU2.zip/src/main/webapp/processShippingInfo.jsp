<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.net.URLEncoder" %>
<%
    request.setCharacterEncoding("UTF-8");

    // 폼 파라미터 가져오기
    String cartId = request.getParameter("cartId");
    String name = request.getParameter("name");
    String shippingDate = request.getParameter("shippingDate");
    String address = request.getParameter("address");
    String postId = request.getParameter("zipCode");

    if (cartId == null || cartId.trim().isEmpty()) {
        cartId = session.getId();
    }

    // 강사님 지정 쿠키명 규칙 적용
    Cookie cookie_cartId = new Cookie("Shipping_cartId", URLEncoder.encode(cartId != null ? cartId : "", "UTF-8"));
    Cookie cookie_name = new Cookie("Shipping_name", URLEncoder.encode(name != null ? name : "", "UTF-8"));
    Cookie cookie_date = new Cookie("Shipping_date", URLEncoder.encode(shippingDate != null ? shippingDate : "", "UTF-8"));
    Cookie cookie_address = new Cookie("Shipping_address", URLEncoder.encode(address != null ? address : "", "UTF-8"));
    Cookie cookie_postId = new Cookie("Shipping_postId", URLEncoder.encode(postId != null ? postId : "", "UTF-8"));

    // 유효 기간 24시간 설정
    cookie_cartId.setMaxAge(24 * 60 * 60);
    cookie_name.setMaxAge(24 * 60 * 60);
    cookie_date.setMaxAge(24 * 60 * 60);
    cookie_address.setMaxAge(24 * 60 * 60);
    cookie_postId.setMaxAge(24 * 60 * 60);

    // 응답 객체에 쿠키 탑재
    response.addCookie(cookie_cartId);
    response.addCookie(cookie_name);
    response.addCookie(cookie_date);
    response.addCookie(cookie_address);
    response.addCookie(cookie_postId);

    response.sendRedirect("orderConfirmation.jsp");
%>