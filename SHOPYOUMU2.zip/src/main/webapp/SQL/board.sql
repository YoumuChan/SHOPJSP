
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE board CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP SEQUENCE num';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- 2. 테이블 생성
CREATE TABLE board(
    num NUMBER PRIMARY KEY,
    id VARCHAR2(20) NOT NULL,
    name VARCHAR2(20) NOT NULL,
    subject VARCHAR2(100) NOT NULL,
    content VARCHAR2(1000) NOT NULL,
    hit NUMBER DEFAULT 0,
    ip VARCHAR2(20),
    regist_day DATE DEFAULT SYSDATE,
    update_day DATE DEFAULT SYSDATE
);

-- 3. 시퀀스 생성
CREATE SEQUENCE num NOCYCLE NOCACHE;

-- 4. 페이징 테스트용 데이터 26개 삽입
INSERT INTO board VALUES (num.NEXTVAL, 'pretty', '정민우', '배송 언제 오나요?', '주문한지 일주일이 지났는데 아직 배송이 안되었어요.ㅠㅠ', 1, '128.120.0.02', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '원두 배송 안내 공지사항', '기본 배송은 CJ대한통운을 통해 평일 오후 2시 이전 주문건은 당일 출고됩니다.', 15, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'cuty', '이지은', '에티오피아 예가체프 원두 산미 문의', '화사한 꽃향기와 감귤 계열의 산미를 선호하는데 이 제품이 잘 맞을까요?', 3, '192.168.0.11', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '홈페이지 리뉴얼 이벤트 공지', '회원가입 후 첫 구매 고객 대상 10% 할인 쿠폰을 발급해 드립니다.', 28, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'coffee_mania', '박찬호', '핸드드립 분쇄도 질문드립니다', '하리오 V60 드리퍼 사용 중인데 분쇄 굵기는 어느 정도로 맞추면 될까요?', 5, '192.168.0.15', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'roaster_k', '김태환', '디카페인 콜롬비아 향미가 훌륭하네요', '화학 용매 없이 추출된 원두라 깔끔하고 단맛이 아주 좋습니다. 재구매 의사 100%입니다.', 8, '172.30.1.20', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'pretty', '정민우', '결제 수단 추가 건의', '카카오페이와 네이버페이 간편결제 기능도 추가해주시면 결제가 훨씬 편할 것 같습니다.', 4, '128.120.0.02', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '서버 정기 점검 안내 (새벽 02시~04시)', '더 안정적인 결제 서비스를 위해 시스템 정기 데이터베이스 점검을 진행합니다.', 42, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'barista_yun', '윤도현', '콜드브루용 원두 추천 요청', '더치 기구로 장시간 추출할 때 잡미가 적고 고소한 원두 라인업 추천 부탁드립니다.', 7, '210.104.12.3', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'coffee_lover', '한소희', '주문 상품 교환 신청합니다', '주문 옵션에서 홀빈을 골라야 했는데 분쇄 원두로 잘못 선택했습니다.', 2, '223.131.44.8', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '원두 보관 팁 및 린싱 가이드', '원두는 개봉 후 직사광선을 피해 서늘하고 건조한 밀폐 용기에 보관하시기 바랍니다.', 51, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'tea_tree', '송강', '선물 세트 포장 가능한가요?', '기획 패키지로 구매 시 선물용 하드케이스 쇼핑백이 동봉되는지 궁금합니다.', 6, '118.235.1.99', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'java_dev', '최우식', '장바구니 담기 수량 오류 건의', '동일 상품을 5개 이상 담을 때 수량 카운트가 정상 반영되는지 테스트 부탁드립니다.', 1, '121.160.8.45', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'coffee_mania', '박찬호', '블렌드 원두 재입고 문의', '시그니처 다크 블렌드 품절 상태인데 언제쯤 재입고되나요?', 9, '192.168.0.15', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'cuty', '이지은', '매장 픽업 서비스는 지원 안 하나요?', '성수동 쇼룸 매장에서 직접 로스팅 일자 확인하고 수령할 수 있는지 궁금합니다.', 11, '192.168.0.11', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '추석 연휴 배송 마감 일정 공지', '택배사 집하 마감 일정에 따라 9월 둘째 주부터 순차 출고가 마감됩니다.', 35, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'barista_yun', '윤도현', '정기 배송 구독 할인율 질문', '원두 월간 정기구독 신청 시 적용되는 프로모션 등급별 할인율 안내 부탁드립니다.', 4, '210.104.12.3', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'pretty', '정민우', '주문 취소 및 환불 소요 기간', '발송 전 취소 완료했는데 카드사 결제 취소 반영은 며칠 정도 걸리나요?', 3, '128.120.0.02', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'roaster_k', '김태환', '과테말라 안티구아 스모키향 만족', '중배전 로스팅 정도가 매우 균일하여 드립 시 크레마 팽창이 아주 훌륭합니다.', 14, '172.30.1.20', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'user01', '강민호', '회원정보 수정 관련 문의', '마이페이지에서 배송지 주소를 변경했는데 기존 주문에도 소급 적용되나요?', 5, '125.130.55.12', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'user02', '조유리', '텀블러 에디션 입고 일정', '지난 시즌 보온 텀블러 블랙 색상 재출시 계획이 있는지 알고 싶습니다.', 8, '112.170.80.33', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', '개인정보처리방침 개정 안내', '이용자 권익 보호 강화를 위해 약관의 일부 조항이 변경되었습니다.', 19, '127.0.0.1', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'coffee_lover', '한소희', '원두 유통기한 및 권장 소비기한', '로스팅 일자로부터 에이징 기간 3일 후 마시는 게 가장 좋은가요?', 12, '223.131.44.8', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'tea_tree', '송강', '대량 주문 견적서 발행 가능한가요?', '사내 카페테리아용으로 월 20kg 단위 납품 견적 요청드립니다.', 6, '118.235.1.99', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'java_dev', '최우식', 'Q&A 페이징 5개씩 출력 테스트', '게시글이 총 26건이므로 페이지당 5개 설정 시 총 6페이지가 구성되어야 합니다.', 2, '121.160.8.45', SYSDATE, SYSDATE);
INSERT INTO board VALUES (num.NEXTVAL, 'admin', '관리자', 'Q&A 게시판 오픈 및 운영 수칙', '회원 여러분들의 자유로운 질의응답과 쇼핑몰 피드백을 남겨주세요.', 64, '127.0.0.1', SYSDATE, SYSDATE);

-- 5. 확정 반영
COMMIT;

-- 6. 검증 조회
SELECT COUNT(*) AS total_count FROM board;
SELECT num, id, name, subject, hit, regist_day FROM board ORDER BY num DESC;