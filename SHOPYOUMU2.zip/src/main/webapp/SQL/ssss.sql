-- 1. 회원(member) 테이블 생성 (registerProcess.jsp 규격 완벽 일치)
CREATE TABLE member (
    mem_num NUMBER NOT NULL PRIMARY KEY,
    id VARCHAR2(30) NOT NULL UNIQUE,
    password VARCHAR2(50) NOT NULL,
    name VARCHAR2(50) NOT NULL,
    gender VARCHAR2(10),
    birth VARCHAR2(20),
    mail VARCHAR2(100),
    phone VARCHAR2(30),
    address VARCHAR2(200),
    regist_day VARCHAR2(30),
    logtime DATE DEFAULT SYSDATE,
    updatetime DATE DEFAULT SYSDATE
);

-- 기본 관리자(admin) 계정 1건 등록
INSERT INTO member (mem_num, id, password, name, gender, birth, mail, phone, address, regist_day)
VALUES (1, 'admin', '1234', '관리자', '남성', '2000-01-01', 'admin@coffo.com', '010-0000-0000', '서울', '2026-09-05');

-- 2. 게시판(board) 테이블 및 시퀀스 생성 (BoardDAO 규격)
CREATE SEQUENCE board_seq START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

CREATE TABLE board (
    num NUMBER NOT NULL PRIMARY KEY,
    id VARCHAR2(30) NOT NULL,
    name VARCHAR2(50) NOT NULL,
    subject VARCHAR2(100) NOT NULL,
    content VARCHAR2(2000) NOT NULL,
    regist_day VARCHAR2(30),
    hit NUMBER DEFAULT 0,
    ip VARCHAR2(50)
);
INSERT INTO member (mem_num, id, password, name, gender, birth, mail, phone, address, regist_day)
VALUES (2, 'admin', '1234', '관리자', '남성', '2000-01-01', 'admin@coffo.com', '010-0000-0000', '서울', '2026-09-05');
select * from member;
DROP SEQUENCE num;
CREATE SEQUENCE num NOCYCLE NOCACHE;
COMMIT;
ALTER TABLE board ADD (update_day DATE DEFAULT SYSDATE);
COMMIT;
select * from board;
COMMIT;
COMMIT;

-- 시퀀스 초기화 및 생성
DROP SEQUENCE num;
CREATE SEQUENCE num NOCYCLE NOCACHE;

