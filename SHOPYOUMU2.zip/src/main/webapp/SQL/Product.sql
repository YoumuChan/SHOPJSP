-- 1. 기존 테이블 정리
DROP TABLE product;
DROP TABLE member;
PURGE RECYCLEBIN;

-- 2. 상품(Product) 테이블 생성
CREATE TABLE product(
    p_id VARCHAR2(20) NOT NULL,
    p_name VARCHAR2(100),
    p_unitPrice NUMBER,
    p_description VARCHAR2(1000),
    p_category VARCHAR2(50),
    p_manufacturer VARCHAR2(50),
    p_unitsInStock NUMBER,
    p_condition VARCHAR2(20),
    p_fileName VARCHAR2(200),
    p_quantity NUMBER DEFAULT 0,
    PRIMARY KEY (p_id)
);

-- 3. 회원(Member) 테이블 생성
CREATE TABLE member(
    id VARCHAR2(20) NOT NULL UNIQUE,
    password VARCHAR2(20) NOT NULL,
    name VARCHAR2(30) NOT NULL,
    gender VARCHAR2(10),
    birth VARCHAR2(20),
    mail VARCHAR2(30),
    phone VARCHAR2(30),
    address VARCHAR2(100),
    regist_day VARCHAR2(30),
    mem_num NUMBER PRIMARY KEY,
    logtime DATE,
    updatetime DATE
);

-- 4. 샘플 상품 데이터 등록 (기본 3개 상품)
-- 상품 1: SONY A7R5
INSERT INTO product VALUES(
    'P1234',
    'SONY A7R5',
    5995520,
    '분류:미러리스 / 화소:6100만화소 / 센서:풀프레임 / 손떨림보정:5축광학식 / 보정효과:8.5단계 / 프로세서:Bionz XR2 / 마운트:SONY FE / 화면:3.2인치 / 화면형태:회전+틸트형 / 화면화소:209만화소 / 화면특징:전자식 뷰파인더, 터치 / 셔터:전자식 / 초점포인트:759개 / 감도:ISO32000 / 확장감도:ISO50-102400 / 셔터스피드:1-8000초 / 연사:초당10매(기계식, 전자식) / 해상도:8K / 프레임:30p / 컬러샘플링:10bit / 색상비율:4-2-2 / 다이내믹레인지:DR-16스탑 이상 / 포맷:RAW / 기타:SONY 크리에이티브룩 / 단자:마이크, USB-C, HDMI, 이어폰',
    'computer device',
    'SONY',
    1000,
    'New',
    'img-1.png',
    0
);

-- 상품 2: SONY A7M4
INSERT INTO product VALUES(
    'P1235',
    'SONY A7M4',
    2890000,
    '분류:미러리스 / 화소:3300만화소 / 센서:풀프레임 / 손떨림보정:5축광학식 / 프로세서:Bionz XR / 마운트:SONY FE / 화면:3.0인치 / 화면형태:회전형 / 초점포인트:759개 / 감도:ISO51200 / 해상도:4K / 프레임:60p / 포맷:RAW / 단자:마이크, USB-C, HDMI',
    'computer device',
    'SONY',
    500,
    'New',
    'img-2.png',
    0
);

-- 상품 3: Canon EOS R6 Mark II
INSERT INTO product VALUES(
    'P1236',
    'Canon EOS R6 Mark II',
    3190000,
    '분류:미러리스 / 화소:2420만화소 / 센서:풀프레임 / 손떨림보정:5축광학식 / 보정효과:8.0단계 / 프로세서:DIGIC X / 마운트:Canon RF / 화면:3.0인치 / 화면형태:회전형 / 초점포인트:1053개 / 감도:ISO102400 / 연사:초당40매(전자식) / 해상도:4K / 프레임:60p / 포맷:RAW',
    'computer device',
    'Canon',
    300,
    'New',
    'img-3.png',
    0
);

-- 5. 데이터 검증 및 반영
DESC product;
DESC member;
SELECT * FROM product;
COMMIT;