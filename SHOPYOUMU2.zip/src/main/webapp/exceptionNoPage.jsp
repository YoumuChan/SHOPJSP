<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:include page="nav.jsp" />

<div class="container" style="padding: 80px 15px; max-width: 800px;">
    <div style="background-color: #fce8e6; color: #a83434; font-size: 38px; font-weight: 500; padding: 40px 20px; text-align: center; border-radius: 4px; margin-bottom: 40px; border: 1px solid #fbc4c4;">
        요청하신 페이지를 찾을 수 없습니다.
    </div>
    
    <div style="padding-left: 20px; margin-bottom: 30px;">
        <p style="color: #666; font-size: 15px; font-family: monospace;">
            http://localhost:8080/WebMarket/exceptionNoPage.jsp
        </p>
    </div>
    
    <div style="padding-left: 20px;">
        <a href="Products.jsp" class="btn btn-secondary" style="background-color: #6c757d; border: none; padding: 10px 18px; font-size: 15px; border-radius: 4px;">
            상품 목록 &raquo;
        </a>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>