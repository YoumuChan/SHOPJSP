<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.oreilly.servlet.MultipartRequest" %>
<%@ page import="com.oreilly.servlet.multipart.DefaultFileRenamePolicy" %>
<%@ page import="java.util.Enumeration" %>
<%@ page import="java.io.File" %>
<%@ page import="java.io.FileInputStream" %>
<%@ page import="java.io.OutputStream" %>
<%@ page import="java.net.HttpURLConnection" %>
<%@ page import="java.net.URL" %>
<%@ page import="java.io.BufferedReader" %>
<%@ page import="java.io.InputStreamReader" %>
<%@ page import="java.util.Base64" %>
<%@ page import="java.sql.*" %>
<%@ page import="dto.Product" %>
<%@ page import="dao.ProductRapository" %>

<%
    request.setCharacterEncoding("UTF-8");

    String tempPath = request.getServletContext().getRealPath("/images");
    File tempDir = new File(tempPath);
    if (!tempDir.exists()) {
        tempDir.mkdirs();
    }

    int maxSize = 50 * 1024 * 1024;
    String encType = "UTF-8";

    MultipartRequest multi = new MultipartRequest(
        request, 
        tempPath, 
        maxSize, 
        encType, 
        new DefaultFileRenamePolicy()
    );

    String productId = multi.getParameter("productId");
    String name = multi.getParameter("name");
    String unitPriceStr = multi.getParameter("unitPrice");
    String description = multi.getParameter("description");
    String manufacturer = multi.getParameter("manufacturer");
    String category = multi.getParameter("category");
    String unitsInStockStr = multi.getParameter("unitsInStock");
    String condition = multi.getParameter("condition");

    if (unitPriceStr == null || unitPriceStr.trim().isEmpty()) {
%>
        <script>
            alert("[등록 실패] 가격을 입력해 주세요.");
            history.back();
        </script>
<%
        return;
    }

    int unitPrice = 0;
    try {
        unitPrice = Integer.parseInt(unitPriceStr.trim());
    } catch (NumberFormatException e) {
%>
        <script>
            alert("[등록 실패] 가격은 숫자만 입력해야 합니다.");
            history.back();
        </script>
<%
        return;
    }

    if (unitPrice <= 0) {
%>
        <script>
            alert("[등록 실패] 가격은 1원 이상이어야 합니다.");
            history.back();
        </script>
<%
        return;
    }

    if (unitsInStockStr == null || unitsInStockStr.trim().isEmpty()) {
%>
        <script>
            alert("[등록 실패] 재고 수량을 입력해 주세요.");
            history.back();
        </script>
<%
        return;
    }

    long unitsInStock = 0;
    try {
        unitsInStock = Long.parseLong(unitsInStockStr.trim());
    } catch (NumberFormatException e) {
%>
        <script>
            alert("[등록 실패] 재고 수량은 숫자만 입력해야 합니다.");
            history.back();
        </script>
<%
        return;
    }

    if (unitsInStock < 0) {
%>
        <script>
            alert("[등록 실패] 재고 수량은 음수일 수 없습니다.");
            history.back();
        </script>
<%
        return;
    }

    String finalImageUrl = "https://i.ibb.co/4M3g96v/img-1.png";
    
    Enumeration files = multi.getFileNames();
    if (files != null && files.hasMoreElements()) {
        String fname = (String) files.nextElement();
        String fileName = multi.getFilesystemName(fname);

        if (fileName != null && !fileName.isEmpty()) {
            File uploadFile = new File(tempPath + File.separator + fileName);
            if (uploadFile.exists()) {
                try {
                    FileInputStream fis = new FileInputStream(uploadFile);
                    byte[] fileBytes = new byte[(int) uploadFile.length()];
                    fis.read(fileBytes);
                    fis.close();
                    String base64Image = Base64.getEncoder().encodeToString(fileBytes);

                    String apiKey = "748e6981b8bb761d0d129be5c11c8b92";
                    String apiURL = "https://api.imgbb.com/1/upload?key=" + apiKey;
                    
                    URL url = new URL(apiURL);
                    HttpURLConnection connApi = (HttpURLConnection) url.openConnection();
                    connApi.setDoOutput(true);
                    connApi.setRequestMethod("POST");
                    connApi.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                    String postData = "image=" + java.net.URLEncoder.encode(base64Image, "UTF-8");

                    OutputStream os = connApi.getOutputStream();
                    os.write(postData.getBytes("UTF-8"));
                    os.flush();
                    os.close();

                    int responseCode = connApi.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader in = new BufferedReader(new InputStreamReader(connApi.getInputStream()));
                        String inputLine;
                        StringBuilder responseJson = new StringBuilder();
                        while ((inputLine = in.readLine()) != null) {
                            responseJson.append(inputLine);
                        }
                        in.close();

                        String responseStr = responseJson.toString();
                        int urlStartIndex = responseStr.indexOf("\"url\":\"") + 7;
                        int urlEndIndex = responseStr.indexOf("\"", urlStartIndex);
                        if (urlStartIndex > 6) {
                            finalImageUrl = responseStr.substring(urlStartIndex, urlEndIndex).replace("\\/", "/");
                        }
                    }
                    uploadFile.delete();
                } catch (Exception e) {
                    finalImageUrl = fileName;
                }
            }
        }
    }

    Product newProduct = new Product();
    newProduct.setProductIDString(productId);
    newProduct.setNameString(name);
    newProduct.setUnitPrice(unitPrice);
    newProduct.setDescripString(description);
    newProduct.setManufacturer(manufacturer);
    newProduct.setCategoryString(category);
    newProduct.setUnitsInStock(unitsInStock);
    newProduct.setConditionString(condition != null ? condition : "New");
    newProduct.setFilenameString(finalImageUrl);

    ProductRapository dao = ProductRapository.getInstance();
    dao.addProduct(newProduct);

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "1234");

        String sql = "INSERT INTO product (p_id, p_name, p_unitPrice, p_description, p_category, p_manufacturer, p_unitsInStock, p_condition, p_fileName, p_quantity) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)";
        
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, productId);
        pstmt.setString(2, name);
        pstmt.setInt(3, unitPrice);
        pstmt.setString(4, description != null ? description : "");
        pstmt.setString(5, category != null ? category : "");
        pstmt.setString(6, manufacturer != null ? manufacturer : "");
        pstmt.setLong(7, unitsInStock);
        pstmt.setString(8, condition != null ? condition : "New");
        pstmt.setString(9, finalImageUrl);

        pstmt.executeUpdate();
    } catch (Exception ignored) {
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    response.sendRedirect("Products.jsp");
%>