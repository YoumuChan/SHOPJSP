<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%
    // 삭제할 상품 ID 가져오기
    String id = request.getParameter("id");

    if (id != null && !id.isEmpty()) {
        // 세션에서 현재 장바구니 리스트 꺼내기
        ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartList");
        
        if (cartList != null) {
            // 장바구니 돌면서 ID가 일치하는 상품 찾아서 삭제
            for (int i = 0; i < cartList.size(); i++) {
                Product product = cartList.get(i);
                if (product.getProductIDString().equals(id)) {
                    cartList.remove(i);
                    break; // 지웠으면 반복문 탈출
                }
            }
        }
    }

    // 삭제 완료 후 다시 장바구니 화면(cart.jsp)으로 강제 소환
    response.sendRedirect("cart.jsp");
%>