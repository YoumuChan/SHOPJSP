<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null) sessionId = (String) session.getAttribute("loginUser");

    if (sessionId == null || sessionId.trim().isEmpty()) {
        response.sendRedirect("login.jsp");
        return;
    }

    String password = request.getParameter("password");
    String name = request.getParameter("name");
    String gender = request.getParameter("gender");
    String birth = request.getParameter("birth");
    String mail = request.getParameter("mail");
    String phone = request.getParameter("phone");
    String address = request.getParameter("address");

    if (password == null || password.trim().isEmpty() || name == null || name.trim().isEmpty()) {
%>
        <script>
            alert("필수 입력값을 모두 채워주세요.");
            history.back();
        </script>
<%
        return;
    }

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        conn.setAutoCommit(false);

        String sql = "UPDATE member SET password = ?, name = ?, gender = ?, birth = ?, mail = ?, phone = ?, address = ?, updatetime = SYSDATE WHERE UPPER(TRIM(id)) = UPPER(?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, password.trim());
        pstmt.setString(2, name.trim());
        pstmt.setString(3, gender != null ? gender : "남성");
        pstmt.setString(4, birth != null ? birth : "");
        pstmt.setString(5, mail != null ? mail : "");
        pstmt.setString(6, phone != null ? phone : "");
        pstmt.setString(7, address != null ? address : "");
        pstmt.setString(8, sessionId.trim());

        pstmt.executeUpdate();
        conn.commit();

        session.setAttribute("sessionName", name.trim());
        response.sendRedirect("resultMember.jsp?msg=0");
    } catch (Exception e) {
        if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
        e.printStackTrace();
%>
        <script>
            alert("수정 처리 중 에러가 발생했습니다: <%= e.getMessage() %>");
            history.back();
        </script>
<%
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>