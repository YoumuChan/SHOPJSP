<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.net.URLDecoder" %>
<%
    String shippingDate = "";

    // 쿠키에서 배송일 가져오고 관련 쿠키 전부 삭제
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
        for (Cookie cookie : cookies) {
            if ("Shipping_date".equals(cookie.getName())) {
                shippingDate = URLDecoder.decode(cookie.getValue(), "UTF-8");
            }
            if (cookie.getName().startsWith("Shipping_")) {
                cookie.setMaxAge(0);
                response.addCookie(cookie);
            }
        }
    }

    // 장바구니 세션 삭제
    session.removeAttribute("cartList");
%>

    <% request.setAttribute("currentPage", "주문 완료"); %>
    <jsp:include page="nav.jsp" />
    </div>

    <div class="container my-5" style="max-width: 650px; min-height: 500px; padding: 60px 15px;">
        <div class="card text-center p-5 shadow-sm" style="border: 1px solid #e9ecef; border-radius: 12px; background: #ffffff;">
            <div style="font-size: 60px; margin-bottom: 20px;">🎉</div>
            <h2 style="font-weight: 800; color: #222; margin-bottom: 15px;">주문이 완료되었습니다!</h2>
            <p style="color: #666; font-size: 16px; margin-bottom: 25px;">
                주문해 주셔서 진심으로 감사드립니다.<br>
                배송 예정일: <strong style="color: #ff0000;"><%= shippingDate.isEmpty() ? "순차 배송 예정" : shippingDate %></strong>
            </p>
            
            <div class="d-flex justify-content-center gap-3 mt-3">
                <a href="Products.jsp" class="btn btn-primary px-4 py-2 fw-bold">쇼핑 계속하기</a>
                <a href="main.jsp" class="btn btn-dark px-4 py-2 fw-bold" style="background-color: #252525;">메인 화면으로</a>
            </div>
        </div>
    </div>

    <jsp:include page="footer.jsp" />
</body>
</html>