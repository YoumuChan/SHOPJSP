<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    // 넘어오는 모든 파라미터명 수용
    String id = request.getParameter("id");
    if (id == null) id = request.getParameter("memberId");
    if (id == null) id = request.getParameter("j_username");

    String password = request.getParameter("pw");
    if (password == null) password = request.getParameter("password");
    if (password == null) password = request.getParameter("memberPw");
    if (password == null) password = request.getParameter("j_password");

    if (id == null || password == null || id.trim().isEmpty() || password.trim().isEmpty()) {
%>
        <script>
            alert("아이디와 비밀번호를 입력해주세요.");
            history.back();
        </script>
<%
        return;
    }

    id = id.trim();
    password = password.trim();

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // DB 컬럼의 공백도 모두 제거(TRIM)하고 대소문자 무시(UPPER) 비교
        String sql = "SELECT * FROM member WHERE UPPER(TRIM(id)) = UPPER(?) AND TRIM(password) = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id);
        pstmt.setString(2, password);

        rs = pstmt.executeQuery();

        if (rs.next()) {
            String dbId = rs.getString("id").trim();
            String dbName = rs.getString("name");
            if (dbName == null || dbName.trim().isEmpty() || dbName.contains("?")) {
                dbName = "관리자";
            } else {
                dbName = dbName.trim();
            }

            // 모든 JSP/nav에서 참조하는 세션 키값 일괄 세팅
            session.setAttribute("sessionId", dbId);
            session.setAttribute("loginUser", dbId);
            session.setAttribute("sessionName", dbName);

            response.sendRedirect("main.jsp");
        } else {
%>
            <script>
                alert("아이디 또는 비밀번호가 올바르지 않습니다.");
                history.back();
            </script>
<%
        }
    } catch (Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("DB 에러 발생: <%= e.getMessage() %>");
            history.back();
        </script>
<%
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>