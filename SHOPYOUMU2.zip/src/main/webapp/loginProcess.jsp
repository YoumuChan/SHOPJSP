<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    request.setCharacterEncoding("UTF-8");
    
    String userId = request.getParameter("id");
    if (userId == null) userId = request.getParameter("userId");
    
    String userPw = request.getParameter("pw");
    if (userPw == null) userPw = request.getParameter("userPw");

    String nextPage = (String) session.getAttribute("nextPage");

    if ("admin".equals(userId) && "1234".equals(userPw)) {
        session.setAttribute("sessionId", "admin");
        session.setAttribute("loginUser", "admin");
        session.setAttribute("sessionName", "관리자");
        session.setAttribute("isAdmin", true);

        if (nextPage != null && !nextPage.trim().isEmpty()) {
            session.removeAttribute("nextPage");
            response.sendRedirect(nextPage);
        } else {
            response.sendRedirect("Products.jsp");
        }
    } else if ("test".equals(userId) && "1234".equals(userPw)) {
        session.setAttribute("sessionId", "test");
        session.setAttribute("loginUser", "test");
        session.setAttribute("sessionName", "테스터");
        session.setAttribute("isAdmin", false);

        if (nextPage != null) session.removeAttribute("nextPage");
        response.sendRedirect("Products.jsp");
    } else {
%>
        <script>
            alert("아이디 또는 비밀번호가 올바르지 않습니다.");
            history.back();
        </script>
<%
    }
%>