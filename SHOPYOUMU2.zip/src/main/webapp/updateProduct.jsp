<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || !sessionId.equals("admin")) {
        response.sendRedirect("login.jsp");
        return;
    }

    String id = request.getParameter("id");
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    String name = "", description = "", manufacturer = "", category = "", condition = "", filename = "";
    int unitPrice = 0;
    long unitsInStock = 0;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        // 🌟 C##dbexam / m1234로 변경
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM product WHERE UPPER(TRIM(p_id)) = UPPER(TRIM(?))";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            name = rs.getString("p_name");
            unitPrice = rs.getInt("p_unitPrice");
            description = rs.getString("p_description");
            manufacturer = rs.getString("p_manufacturer");
            category = rs.getString("p_category");
            unitsInStock = rs.getLong("p_unitsInStock");
            condition = rs.getString("p_condition");
            filename = rs.getString("p_fileName");
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<%@ include file="nav.jsp" %>
</div>

<div class="container my-5" style="max-width: 800px; min-height: 600px; padding: 40px 15px;">
    <h2 class="text-center fw-bold mb-4">🛠️ 상품 정보 수정 (관리자)</h2>

    <form name="updateForm" action="processUpdateProduct.jsp" method="post" enctype="multipart/form-data">
        <input type="hidden" name="productId" value="<%= id %>">
        <input type="hidden" name="oldFileName" value="<%= filename %>">

        <div class="mb-3">
            <label class="form-label fw-bold">상품 코드</label>
            <input type="text" class="form-control" value="<%= id %>" disabled>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">상품명</label>
            <input type="text" name="name" class="form-control" value="<%= name %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">가격</label>
            <input type="number" name="unitPrice" class="form-control" value="<%= unitPrice %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">제조사</label>
            <input type="text" name="manufacturer" class="form-control" value="<%= manufacturer %>">
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">분류</label>
            <input type="text" name="category" class="form-control" value="<%= category %>">
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">재고 수량</label>
            <input type="number" name="unitsInStock" class="form-control" value="<%= unitsInStock %>" required>
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">상태</label><br>
            <input type="radio" name="condition" value="New" <%= "New".equals(condition) ? "checked" : "" %>> 신규 제품
            <input type="radio" name="condition" value="Old" <%= "Old".equals(condition) ? "checked" : "" %> class="ms-3"> 중고 제품
            <input type="radio" name="condition" value="Refurbished" <%= "Refurbished".equals(condition) ? "checked" : "" %> class="ms-3"> 재생 제품
        </div>
        <div class="mb-3">
            <label class="form-label fw-bold">상세 스펙 설명</label>
            <textarea name="description" rows="3" class="form-control"><%= description %></textarea>
        </div>
        <div class="mb-4">
            <label class="form-label fw-bold">이미지 변경 (미선택 시 기존 이미지 유지)</label>
            <input type="file" name="productImage" class="form-control">
        </div>

        <div class="d-flex gap-2">
            <input type="submit" class="btn btn-success flex-grow-1 fw-bold text-white py-2" value="수정 완료">
            <a href="editProduct.jsp?edit=update" class="btn btn-secondary px-4 py-2">취소</a>
        </div>
    </form>
</div>

<%@ include file="footer.jsp" %>
</body>
</html>