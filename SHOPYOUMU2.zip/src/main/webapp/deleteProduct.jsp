<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");
    String id = request.getParameter("id");

    if (id != null && !id.trim().isEmpty()) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "1234");

            String sql = "DELETE FROM product WHERE UPPER(TRIM(p_id)) = UPPER(TRIM(?))";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, id.trim());
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
            if (conn != null) try { conn.close(); } catch (Exception e) {}
        }
    }

    response.sendRedirect("editProduct.jsp?edit=delete");
%>