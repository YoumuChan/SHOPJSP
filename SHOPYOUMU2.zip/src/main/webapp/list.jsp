<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.*" %>
<%@ page import="dto.BoardDTO" %>

<%
    request.setCharacterEncoding("UTF-8");

    // 세션 정보 확인
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    // 검색 파라미터 수신
    String items = request.getParameter("items");
    String text = request.getParameter("text");

    // 페이징 변수 설정
    int pageNum = 1;
    if (request.getParameter("pageNum") != null) {
        try {
            pageNum = Integer.parseInt(request.getParameter("pageNum"));
        } catch (Exception e) {
            pageNum = 1;
        }
    }
    int limit = 5; // 한 페이지당 5개씩

    ArrayList<BoardDTO> boardList = new ArrayList<BoardDTO>();
    int totalRecord = 0;

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // 1. 전체 글 수 조회
        String countSql = "SELECT COUNT(*) FROM board";
        if (items != null && text != null && !text.trim().isEmpty()) {
            countSql += " WHERE " + items + " LIKE ?";
            pstmt = conn.prepareStatement(countSql);
            pstmt.setString(1, "%" + text.trim() + "%");
        } else {
            pstmt = conn.prepareStatement(countSql);
        }
        rs = pstmt.executeQuery();
        if (rs.next()) {
            totalRecord = rs.getInt(1);
        }
        rs.close();
        pstmt.close();

        // 2. 오라클 페이징 쿼리 (ROWNUM 활용)
        int startRow = (pageNum - 1) * limit + 1;
        int endRow = startRow + limit - 1;

        String listSql = "";
        if (items != null && text != null && !text.trim().isEmpty()) {
            listSql = "SELECT * FROM ("
                    + "  SELECT ROWNUM rnum, a.* FROM ("
                    + "    SELECT * FROM board WHERE " + items + " LIKE ? ORDER BY num DESC"
                    + "  ) a WHERE ROWNUM <= ?"
                    + ") WHERE rnum >= ?";
            pstmt = conn.prepareStatement(listSql);
            pstmt.setString(1, "%" + text.trim() + "%");
            pstmt.setInt(2, endRow);
            pstmt.setInt(3, startRow);
        } else {
            listSql = "SELECT * FROM ("
                    + "  SELECT ROWNUM rnum, a.* FROM ("
                    + "    SELECT * FROM board ORDER BY num DESC"
                    + "  ) a WHERE ROWNUM <= ?"
                    + ") WHERE rnum >= ?";
            pstmt = conn.prepareStatement(listSql);
            pstmt.setInt(1, endRow);
            pstmt.setInt(2, startRow);
        }

        rs = pstmt.executeQuery();
        while (rs.next()) {
            BoardDTO dto = new BoardDTO();
            dto.setNum(rs.getInt("num"));
            dto.setId(rs.getString("id"));
            dto.setName(rs.getString("name"));
            dto.setSubject(rs.getString("subject"));
            dto.setContent(rs.getString("content"));
            dto.setRegist_day(rs.getString("regist_day"));
            dto.setHit(rs.getInt("hit"));
            dto.setIp(rs.getString("ip"));
            boardList.add(dto);
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    int totalPage = (int) Math.ceil((double) totalRecord / limit);
    if (totalPage == 0) totalPage = 1;
%>

<% request.setAttribute("currentPage", "블로그"); %>
<jsp:include page="nav.jsp" />

<style>
    .board-hero {
        background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        padding: 50px 0 75px;
        color: #ffffff;
        border-bottom: 2px solid #ff3344;
    }
    .board-container {
        margin-top: -45px;
        margin-bottom: 80px;
    }
    .board-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        border: 1px solid #edf2f7;
        padding: 35px 40px;
    }
    .board-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        margin-top: 20px;
    }
    .board-table th {
        background-color: #f8fafc;
        color: #475569;
        font-weight: 700;
        padding: 14px 16px;
        border-bottom: 2px solid #e2e8f0;
        font-size: 14px;
        text-align: center;
    }
    .board-table td {
        padding: 16px;
        border-bottom: 1px solid #f1f5f9;
        font-size: 14px;
        color: #1e293b;
        vertical-align: middle;
        text-align: center;
    }
    .board-table td.subject-td {
        text-align: left;
    }
    .board-table tr:hover {
        background-color: #fcfcfc;
    }
    .board-title-link {
        color: #0f172a;
        text-decoration: none;
        font-weight: 600;
        transition: color 0.15s ease;
    }
    .board-title-link:hover {
        color: #ff3344;
    }
    .hit-badge {
        background: #f1f5f9;
        color: #ff3344;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 12px;
    }
    .btn-write {
        background: #0f172a;
        color: #ffffff !important;
        padding: 10px 22px;
        border-radius: 8px;
        font-weight: 700;
        font-size: 14px;
        text-decoration: none !important;
        transition: 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-write:hover {
        background: #ff3344;
        box-shadow: 0 4px 12px rgba(255, 51, 68, 0.25);
    }
    .page-btn {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        color: #475569;
        text-decoration: none;
        border: 1px solid #e2e8f0;
        margin: 0 3px;
        background: #fff;
    }
    .page-btn.active {
        background: #ff3344;
        color: #fff;
        border-color: #ff3344;
    }
    .page-btn:hover:not(.active) {
        background: #f1f5f9;
    }
</style>

<div class="board-hero">
    <div class="container text-center">
        <h2 style="font-weight: 800; font-size: 30px; margin-bottom: 6px;">고객 소통 Q&A 게시판</h2>
        <p style="color: #94a3b8; font-size: 14px; margin: 0;">원두 문의, 배송 질문 및 쇼핑몰 이용 후기를 확인하세요.</p>
    </div>
</div>

<div class="container board-container">
    <div class="board-card">
        <!-- 상단 헤더 및 통계 -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <span style="font-size: 14px; color: #64748b;">전체 게시글: <strong style="color: #ff3344;"><%= totalRecord %></strong>건</span>
            </div>
            <div>
                <% if (sessionId != null && !sessionId.trim().isEmpty()) { %>
                    <a href="writeForm.jsp" class="btn-write">✏️ 글쓰기</a>
                <% } else { %>
                    <a href="login.jsp" class="btn-write" onclick="alert('로그인 후 작성 가능합니다.');">✏️ 글쓰기</a>
                <% } %>
            </div>
        </div>

        <!-- 게시글 테이블 -->
        <table class="board-table">
            <thead>
                <tr>
                    <th style="width: 80px;">번호</th>
                    <th>제목</th>
                    <th style="width: 120px;">작성자</th>
                    <th style="width: 140px;">작성일</th>
                    <th style="width: 90px;">조회</th>
                </tr>
            </thead>
            <tbody>
                <%
                    if (boardList.size() == 0) {
                %>
                    <tr>
                        <td colspan="5" style="padding: 50px 0; color: #94a3b8;">등록된 게시글이 없습니다.</td>
                    </tr>
                <%
                    } else {
                        for (int i = 0; i < boardList.size(); i++) {
                            BoardDTO row = boardList.get(i);
                %>
                    <tr>
                        <td style="color: #94a3b8; font-weight: 600;"><%= row.getNum() %></td>
                        <td class="subject-td">
                            <a href="view.jsp?num=<%= row.getNum() %>&pageNum=<%= pageNum %>" class="board-title-link">
                                <%= row.getSubject() %>
                            </a>
                        </td>
                        <td><strong><%= row.getName() %></strong></td>
                        <td style="color: #64748b; font-size: 13px;"><%= row.getRegist_day() != null ? row.getRegist_day().substring(0, 10) : "-" %></td>
                        <td><span class="hit-badge"><%= row.getHit() %></span></td>
                    </tr>
                <%
                        }
                    }
                %>
            </tbody>
        </table>

        <!-- 하단 페이징 영역 -->
        <div class="d-flex justify-content-center mt-4">
            <div>
                <% if (pageNum > 1) { %>
                    <a class="page-btn" href="list.jsp?pageNum=<%= pageNum - 1 %><%= (text != null) ? "&items=" + items + "&text=" + text : "" %>">&lt;</a>
                <% } %>

                <% for (int p = 1; p <= totalPage; p++) { %>
                    <a class="page-btn <%= (p == pageNum) ? "active" : "" %>" 
                       href="list.jsp?pageNum=<%= p %><%= (text != null) ? "&items=" + items + "&text=" + text : "" %>">
                       <%= p %>
                    </a>
                <% } %>

                <% if (pageNum < totalPage) { %>
                    <a class="page-btn" href="list.jsp?pageNum=<%= pageNum + 1 %><%= (text != null) ? "&items=" + items + "&text=" + text : "" %>">&gt;</a>
                <% } %>
            </div>
        </div>

        <!-- 하단 검색창 -->
        <div class="text-center mt-4">
            <form action="list.jsp" method="get" class="d-inline-flex gap-2">
                <select name="items" class="form-select form-select-sm" style="width: 110px; border-radius: 8px;">
                    <option value="subject" <%= "subject".equals(items) ? "selected" : "" %>>제목</option>
                    <option value="content" <%= "content".equals(items) ? "selected" : "" %>>본문</option>
                    <option value="name" <%= "name".equals(items) ? "selected" : "" %>>작성자</option>
                </select>
                <input type="text" name="text" value="<%= (text != null) ? text : "" %>" class="form-control form-control-sm" placeholder="검색어 입력" style="width: 200px; border-radius: 8px;">
                <button type="submit" class="btn btn-sm btn-dark" style="border-radius: 8px; font-weight: 700; padding: 6px 16px;">검색</button>
            </form>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>