<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.net.URLDecoder" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>배송 정보</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<%
    // 기존에 저장된 쿠키 값 불러오기
    String cartId = "";
    String shippingDate = "";
    String country = "";
    String zipCode = "";
    String addressName = "";

    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
        for (Cookie cookie : cookies) {
            String cName = cookie.getName();
            String cValue = URLDecoder.decode(cookie.getValue(), "UTF-8");
            if ("Shipping_cartId".equals(cName)) cartId = cValue;
            if ("Shipping_shippingDate".equals(cName)) shippingDate = cValue;
            if ("Shipping_country".equals(cName)) country = cValue;
            if ("Shipping_zipCode".equals(cName)) zipCode = cValue;
            if ("Shipping_addressName".equals(cName)) addressName = cValue;
        }
    }
%>

    <jsp:include page="nav.jsp" />
    </div>

    <div class="container my-5" style="max-width: 600px;">
        <h2 class="mb-4 text-center fw-bold">배송 정보</h2>
        
        <form action="processShippingInfo.jsp" method="post">
            <input type="hidden" name="cartId" value="<%= session.getId() %>">

            <!-- 성명 -->
            <div class="mb-3">
                <label for="name" class="form-label fw-bold">성명</label>
                <input type="text" class="form-control" id="name" name="name" value="<%= (session.getAttribute("loginUser") != null) ? session.getAttribute("loginUser") : "" %>" required>
            </div>

            <!-- 배송일 -->
            <div class="mb-3">
                <label for="shippingDate" class="form-label fw-bold">배송일</label>
                <input type="text" class="form-control" id="shippingDate" name="shippingDate" value="<%= shippingDate %>" placeholder="yyyy/mm/dd" required>
            </div>

            <!-- 국가명 (교재 표준 필드) -->
            <div class="mb-3">
                <label for="country" class="form-label fw-bold">국가명</label>
                <input type="text" class="form-control" id="country" name="country" value="<%= country.isEmpty() ? "한국" : country %>" required>
            </div>

            <!-- 우편번호 입력 -->
            <div class="mb-3">
                <label for="zipCode" class="form-label fw-bold">우편번호 입력</label>
                <input type="text" class="form-control" id="zipCode" name="zipCode" value="<%= zipCode %>" required>
            </div>

            <!-- 주소입력 -->
            <div class="mb-4">
                <label for="addressName" class="form-label fw-bold">주소입력</label>
                <input type="text" class="form-control" id="addressName" name="addressName" value="<%= addressName %>" required>
            </div>

            <!-- 이전 / 등록 / 취소 버튼 -->
            <div class="d-flex gap-2">
                <a href="./cart.jsp" class="btn btn-secondary px-3">이전</a>
                <input type="submit" class="btn btn-warning flex-grow-1 fw-bold text-white" value="등록">
                <a href="./checkOutCancelled.jsp" class="btn btn-danger px-3">취소</a>
            </div>
        </form>
    </div>

    <jsp:include page="footer.jsp" />
</body>
</html>