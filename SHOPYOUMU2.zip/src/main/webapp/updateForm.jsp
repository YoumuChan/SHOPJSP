<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
%>
    <script>
        alert("로그인 후 이용 가능합니다.");
        location.href = "login.jsp";
    </script>
<%
        return;
    }

    String numStr = request.getParameter("num");
    String pageNumStr = request.getParameter("pageNum");
    if (pageNumStr == null || pageNumStr.trim().isEmpty()) {
        pageNumStr = "1";
    }

    if (numStr == null || numStr.trim().isEmpty()) {
        response.sendRedirect("list.jsp");
        return;
    }

    int num = Integer.parseInt(numStr);

    String writerId = "";
    String writerName = "";
    String subject = "";
    String content = "";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM board WHERE num = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, num);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            writerId = rs.getString("id");
            writerName = rs.getString("name");
            subject = rs.getString("subject");
            content = rs.getString("content");

            // 권한 체크: 작성자 본인 또는 admin 계정만 허용
            if (!sessionId.equals(writerId) && !"admin".equalsIgnoreCase(sessionId)) {
%>
                <script>
                    alert("수정 권한이 없습니다.");
                    history.back();
                </script>
<%
                return;
            }
        } else {
%>
            <script>
                alert("존재하지 않는 게시글입니다.");
                location.href = "list.jsp";
            </script>
<%
            return;
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<% request.setAttribute("currentPage", "블로그"); %>
<jsp:include page="nav.jsp" />

<style>
    .edit-hero {
        background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        padding: 50px 0 75px;
        color: #ffffff;
        border-bottom: 2px solid #ff3344;
    }
    .edit-container {
        margin-top: -45px;
        margin-bottom: 80px;
        max-width: 860px;
    }
    .edit-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        border: 1px solid #edf2f7;
        padding: 40px;
    }
    .form-label {
        font-weight: 700;
        color: #334155;
        font-size: 14px;
        margin-bottom: 8px;
    }
    .form-control {
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        padding: 10px 14px;
        font-size: 14px;
    }
    .form-control:focus {
        border-color: #ff3344;
        box-shadow: 0 0 0 3px rgba(255, 51, 68, 0.15);
    }
    .btn-submit {
        background: #0f172a;
        color: #fff;
        padding: 12px 30px;
        border-radius: 8px;
        font-weight: 700;
        border: none;
        transition: 0.2s ease;
    }
    .btn-submit:hover {
        background: #ff3344;
        box-shadow: 0 4px 12px rgba(255, 51, 68, 0.25);
    }
    .btn-cancel {
        background: #f1f5f9;
        color: #475569;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        text-decoration: none;
        display: inline-block;
    }
    .btn-cancel:hover {
        background: #e2e8f0;
        color: #1e293b;
    }
</style>

<div class="edit-hero">
    <div class="container text-center">
        <h2 style="font-weight: 800; font-size: 28px; margin-bottom: 6px;">Q&A 게시글 수정</h2>
        <p style="color: #94a3b8; font-size: 14px; margin: 0;">작성하신 게시글의 제목과 본문을 수정합니다.</p>
    </div>
</div>

<div class="container edit-container">
    <div class="edit-card">
        <form action="updateProcess.jsp" method="post">
            <input type="hidden" name="num" value="<%= num %>">
            <input type="hidden" name="pageNum" value="<%= pageNumStr %>">

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">작성자 아이디</label>
                    <input type="text" class="form-control" value="<%= writerId %>" readonly style="background-color: #f8fafc;">
                </div>
                <div class="col-md-6">
                    <label class="form-label">작성자 이름</label>
                    <input type="text" class="form-control" value="<%= writerName %>" readonly style="background-color: #f8fafc;">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">제목</label>
                <input type="text" name="subject" class="form-control" value="<%= subject %>" required>
            </div>

            <div class="mb-4">
                <label class="form-label">내용</label>
                <textarea name="content" rows="10" class="form-control" required><%= content %></textarea>
            </div>

            <div class="d-flex justify-content-between align-items-center pt-2">
                <a href="view.jsp?num=<%= num %>&pageNum=<%= pageNumStr %>" class="btn-cancel">취소</a>
                <button type="submit" class="btn-submit">수정 완료하기</button>
            </div>
        </form>
    </div>
</div>

<jsp:include page="footer.jsp" />