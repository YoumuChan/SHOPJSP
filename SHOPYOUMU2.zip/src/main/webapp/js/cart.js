/**
 * 🛒 장바구니 관련 공통 자바스크립트 기능 (최종본)
 */

// 1. 상품을 장바구니에 추가하는 함수 (확인/취소 버튼 글자 커스텀)
function addToCart(productId) {
    // 중복 팝업 방지
    const oldAlert = document.getElementById('custom-cart-alert');
    if (oldAlert) oldAlert.remove();

    // 배경 어둡게 처리 (마스크)
    const mask = document.createElement('div');
    mask.id = 'custom-cart-alert';
    mask.style.position = 'fixed';
    mask.style.top = '0';
    mask.style.left = '0';
    mask.style.width = '100%';
    mask.style.height = '100%';
    mask.style.backgroundColor = 'rgba(0, 0, 0, 0.4)';
    mask.style.display = 'flex';
    mask.style.justifyContent = 'center';
    mask.style.alignItems = 'center';
    mask.style.zIndex = '9999';

    // 팝업 하얀 박스
    const box = document.createElement('div');
    box.style.backgroundColor = '#fff';
    box.style.padding = '30px';
    box.style.borderRadius = '8px';
    box.style.boxShadow = '0 4px 20px rgba(0,0,0,0.15)';
    box.style.textAlign = 'center';
    box.style.minWidth = '340px';

    // 안내 문구
    const text = document.createElement('p');
    text.innerText = '이 상품을 장바구니에 담으시겠습니까?';
    text.style.fontSize = '16px';
    text.style.fontWeight = 'bold';
    text.style.marginBottom = '25px';
    text.style.color = '#222';
    box.appendChild(text);

    // 버튼 정렬 컨테이너
    const btnContainer = document.createElement('div');
    btnContainer.style.display = 'flex';
    btnContainer.style.gap = '12px';
    btnContainer.style.justifyContent = 'center';

    // 왼쪽 버튼: [쇼핑 계속하기] (취소 역할)
    const cancelBtn = document.createElement('button');
    cancelBtn.innerText = '쇼핑 계속하기';
    cancelBtn.style.padding = '10px 20px';
    cancelBtn.style.border = '1px solid #ddd';
    cancelBtn.style.backgroundColor = '#f8f9fa';
    cancelBtn.style.color = '#666';
    cancelBtn.style.borderRadius = '4px';
    cancelBtn.style.cursor = 'pointer';
    cancelBtn.style.fontWeight = 'bold';
    cancelBtn.onclick = function() {
        mask.remove(); // 담지 않고 팝업만 닫기
    };

    // 오른쪽 버튼: [장바구니 가기] (확인 역할)
    const confirmBtn = document.createElement('button');
    confirmBtn.innerText = '장바구니 가기';
    confirmBtn.style.padding = '10px 20px';
    confirmBtn.style.border = 'none';
    confirmBtn.style.backgroundColor = '#ffc107'; // 예쁜 노란색
    confirmBtn.style.color = '#fff';
    confirmBtn.style.borderRadius = '4px';
    confirmBtn.style.cursor = 'pointer';
    confirmBtn.style.fontWeight = 'bold';
    confirmBtn.onclick = function() {
        // 백엔드로 상품 보내면서 장바구니 페이지로 이동!
        location.href = "addCart.jsp?id=" + productId;
    };

    // 조립 가동
    btnContainer.appendChild(cancelBtn);
    btnContainer.appendChild(confirmBtn);
    box.appendChild(btnContainer);
    mask.appendChild(box);

    // 화면에 뿌리기
    document.body.appendChild(mask);
}

// 2. 장바구니에서 특정 상품 하나 삭제하는 함수
function removeFromCart(productId) {
    if (confirm("선택하신 상품을 장바구니에서 삭제하시겠습니까?")) {
        location.href = "removeCart.jsp?id=" + productId;
    }
}

// 3. 장바구니 전체 비우기 함수
function clearCart() {
    if (confirm("장바구니의 모든 상품을 비우시겠습니까?")) {
        location.href = "clearCart.jsp";
    }
}