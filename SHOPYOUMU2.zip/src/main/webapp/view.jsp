<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    // 세션 사용자 확인
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    String numStr = request.getParameter("num");
    String pageNumStr = request.getParameter("pageNum");
    if (pageNumStr == null || pageNumStr.trim().isEmpty()) {
        pageNumStr = "1";
    }

    if (numStr == null || numStr.trim().isEmpty()) {
        response.sendRedirect("list.jsp");
        return;
    }

    int num = Integer.parseInt(numStr);

    String writerId = "";
    String writerName = "";
    String subject = "";
    String content = "";
    String registDay = "";
    int hit = 0;
    String ip = "";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // 1. 조회수 1 증가
        String updateHitSql = "UPDATE board SET hit = hit + 1 WHERE num = ?";
        pstmt = conn.prepareStatement(updateHitSql);
        pstmt.setInt(1, num);
        pstmt.executeUpdate();
        pstmt.close();

        // 2. 게시글 상세 조회
        String selectSql = "SELECT * FROM board WHERE num = ?";
        pstmt = conn.prepareStatement(selectSql);
        pstmt.setInt(1, num);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            writerId = rs.getString("id");
            writerName = rs.getString("name");
            subject = rs.getString("subject");
            content = rs.getString("content");
            registDay = rs.getString("regist_day");
            hit = rs.getInt("hit");
            ip = rs.getString("ip");
        } else {
%>
            <script>
                alert("존재하지 않거나 삭제된 게시글입니다.");
                location.href = "list.jsp";
            </script>
<%
            return;
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<% request.setAttribute("currentPage", "블로그"); %>
<jsp:include page="nav.jsp" />

<style>
    .view-hero {
        background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        padding: 50px 0 75px;
        color: #ffffff;
        border-bottom: 2px solid #ff3344;
    }
    .view-container {
        margin-top: -45px;
        margin-bottom: 80px;
        max-width: 900px;
    }
    .view-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        border: 1px solid #edf2f7;
        padding: 40px;
    }
    .view-title {
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 20px;
        word-break: break-all;
    }
    .view-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        padding-bottom: 20px;
        border-bottom: 1px solid #e2e8f0;
        font-size: 14px;
        color: #64748b;
    }
    .view-meta strong {
        color: #1e293b;
    }
    .view-content {
        padding: 35px 5px;
        min-height: 250px;
        font-size: 15px;
        line-height: 1.8;
        color: #334155;
        white-space: pre-wrap;
        border-bottom: 1px solid #e2e8f0;
    }
    .btn-action {
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 700;
        font-size: 14px;
        text-decoration: none !important;
        display: inline-block;
    }
    .btn-back {
        background: #f1f5f9;
        color: #475569;
    }
    .btn-back:hover {
        background: #e2e8f0;
        color: #0f172a;
    }
    .btn-edit {
        background: #0f172a;
        color: #fff !important;
    }
    .btn-edit:hover {
        background: #ff3344;
    }
    .btn-delete {
        background: #ef4444;
        color: #fff !important;
    }
    .btn-delete:hover {
        background: #dc2626;
    }
</style>

<div class="view-hero">
    <div class="container text-center">
        <h2 style="font-weight: 800; font-size: 28px; margin-bottom: 6px;">Q&A 게시글 상세</h2>
        <p style="color: #94a3b8; font-size: 14px; margin: 0;">고객님의 소중한 문의와 답변 내용입니다.</p>
    </div>
</div>

<div class="container view-container">
    <div class="view-card">
        <!-- 글 제목 -->
        <h3 class="view-title"><%= subject %></h3>

        <!-- 메타 정보 (작성자, 등록일, 조회수 등) -->
        <div class="view-meta">
            <div>작성자: <strong><%= writerName %> (<%= writerId %>)</strong></div>
            <div>등록일: <strong><%= (registDay != null) ? registDay : "-" %></strong></div>
            <div>조회수: <strong style="color: #ff3344;"><%= hit %></strong></div>
            <div>IP: <strong><%= ip %></strong></div>
        </div>

        <!-- 글 본문 -->
        <div class="view-content"><%= content %></div>

        <!-- 하단 컨트롤 버튼 -->
        <div class="d-flex justify-content-between align-items-center mt-4">
            <a href="list.jsp?pageNum=<%= pageNumStr %>" class="btn-action btn-back">목록으로</a>

            <div class="d-flex gap-2">
                <%-- 본인 작성 글이거나 관리자 계정일 때만 수정/삭제 노출 --%>
                <% if (sessionId != null && (sessionId.equals(writerId) || "admin".equalsIgnoreCase(sessionId))) { %>
                    <a href="updateForm.jsp?num=<%= num %>&pageNum=<%= pageNumStr %>" class="btn-action btn-edit">수정</a>
                    <a href="deleteProcess.jsp?num=<%= num %>&pageNum=<%= pageNumStr %>" 
                       class="btn-action btn-delete" 
                       onclick="return confirm('정말 이 게시글을 삭제하시겠습니까?');">삭제</a>
                <% } %>
            </div>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />