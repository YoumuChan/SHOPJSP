<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
%>
    <script>
        alert("로그인 후 이용 가능합니다.");
        location.href = "login.jsp";
    </script>
<%
        return;
    }

    String sessionName = (String) session.getAttribute("sessionName");
    if (sessionName == null || sessionName.trim().isEmpty()) {
        sessionName = sessionId;
    }
%>

<% request.setAttribute("currentPage", "블로그"); %>
<jsp:include page="nav.jsp" />

<style>
    .write-hero {
        background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        padding: 50px 0 75px;
        color: #ffffff;
        border-bottom: 2px solid #ff3344;
    }
    .write-container {
        margin-top: -45px;
        margin-bottom: 80px;
        max-width: 860px;
    }
    .write-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
        border: 1px solid #edf2f7;
        padding: 40px;
    }
    .form-label {
        font-weight: 700;
        color: #334155;
        font-size: 14px;
        margin-bottom: 8px;
    }
    .form-control {
        border-radius: 8px;
        border: 1px solid #cbd5e1;
        padding: 10px 14px;
        font-size: 14px;
    }
    .form-control:focus {
        border-color: #ff3344;
        box-shadow: 0 0 0 3px rgba(255, 51, 68, 0.15);
    }
    .btn-submit {
        background: #0f172a;
        color: #fff;
        padding: 12px 30px;
        border-radius: 8px;
        font-weight: 700;
        border: none;
        transition: 0.2s ease;
    }
    .btn-submit:hover {
        background: #ff3344;
        box-shadow: 0 4px 12px rgba(255, 51, 68, 0.25);
    }
    .btn-cancel {
        background: #f1f5f9;
        color: #475569;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        text-decoration: none;
        display: inline-block;
    }
    .btn-cancel:hover {
        background: #e2e8f0;
        color: #1e293b;
    }
</style>

<div class="write-hero">
    <div class="container text-center">
        <h2 style="font-weight: 800; font-size: 28px; margin-bottom: 6px;">Q&A 게시글 작성</h2>
        <p style="color: #94a3b8; font-size: 14px; margin: 0;">쇼핑몰 운영진 및 회원들과 자유롭게 소통해보세요.</p>
    </div>
</div>

<div class="container write-container">
    <div class="write-card">
        <form action="writeProcess.jsp" method="post">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="form-label">작성자 아이디</label>
                    <input type="text" name="id" class="form-control" value="<%= sessionId %>" readonly style="background-color: #f8fafc;">
                </div>
                <div class="col-md-6">
                    <label class="form-label">작성자 이름</label>
                    <input type="text" name="name" class="form-control" value="<%= sessionName %>" readonly style="background-color: #f8fafc;">
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">제목</label>
                <input type="text" name="subject" class="form-control" placeholder="제목을 입력하세요" required>
            </div>

            <div class="mb-4">
                <label class="form-label">내용</label>
                <textarea name="content" rows="10" class="form-control" placeholder="문의 사항 및 게시글 내용을 상세히 작성해주세요" required></textarea>
            </div>

            <div class="d-flex justify-content-between align-items-center pt-2">
                <a href="list.jsp" class="btn-cancel">목록으로</a>
                <button type="submit" class="btn-submit">게시글 등록하기</button>
            </div>
        </form>
    </div>
</div>

<jsp:include page="footer.jsp" />