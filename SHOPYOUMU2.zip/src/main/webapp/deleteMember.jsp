<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null) sessionId = (String) session.getAttribute("loginUser");

    if (sessionId == null || sessionId.trim().isEmpty()) {
        response.sendRedirect("login.jsp");
        return;
    }

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        conn.setAutoCommit(false);

        String sql = "DELETE FROM member WHERE UPPER(TRIM(id)) = UPPER(?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, sessionId.trim());
        pstmt.executeUpdate();

        conn.commit();
        session.invalidate(); // 탈퇴 후 세션 완전 정리

        response.sendRedirect("resultMember.jsp");
    } catch (Exception e) {
        if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
        e.printStackTrace();
%>
        <script>
            alert("회원 탈퇴 처리 에러: <%= e.getMessage() %>");
            history.back();
        </script>
<%
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>