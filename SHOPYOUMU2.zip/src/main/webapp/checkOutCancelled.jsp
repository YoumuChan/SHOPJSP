<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<jsp:include page="nav.jsp" />
</div>

<div class="container my-5" style="max-width: 650px; min-height: 500px; padding-top: 50px;">
    <div class="card text-center p-5 shadow-sm" style="border-radius: 12px; background: #ffffff;">
        <div style="font-size: 60px; margin-bottom: 20px;">❌</div>
        <h2 style="font-weight: 800; color: #222; margin-bottom: 15px;">주문이 취소되었습니다.</h2>
        <p style="color: #666; font-size: 16px; margin-bottom: 25px;">
            주문 처리가 취소되었습니다. 장바구니로 돌아가 주문 내역을 다시 확인하실 수 있습니다.
        </p>
        
        <div class="d-flex justify-content-center gap-3 mt-3">
            <a href="cart.jsp" class="btn btn-warning px-4 py-2 fw-bold text-white">장바구니로 돌아가기</a>
            <a href="Products.jsp" class="btn btn-secondary px-4 py-2 fw-bold">상품 목록</a>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>