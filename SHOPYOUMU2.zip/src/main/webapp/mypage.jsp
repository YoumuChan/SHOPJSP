<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
%>
        <script>
            alert("로그인이 필요한 서비스입니다.");
            location.href = "login.jsp";
        </script>
<%
        return;
    }

    String name = "";
    String gender = "-";
    String birth = "-";
    String mail = "-";
    String phone = "-";
    String address = "등록된 배송지가 없습니다.";
    String registDay = "-";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM member WHERE UPPER(TRIM(id)) = UPPER(?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, sessionId);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            name = rs.getString("name");
            if (rs.getString("gender") != null && !rs.getString("gender").isEmpty()) gender = rs.getString("gender");
            if (rs.getString("birth") != null && !rs.getString("birth").isEmpty()) birth = rs.getString("birth");
            if (rs.getString("mail") != null && !rs.getString("mail").isEmpty()) mail = rs.getString("mail");
            if (rs.getString("phone") != null && !rs.getString("phone").isEmpty()) phone = rs.getString("phone");
            if (rs.getString("address") != null && !rs.getString("address").isEmpty()) address = rs.getString("address");
            if (rs.getString("regist_day") != null && !rs.getString("regist_day").isEmpty()) registDay = rs.getString("regist_day");
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<% request.setAttribute("currentPage", "마이페이지"); %>
<jsp:include page="nav.jsp" />

<style>
    .mypage-hero {
        background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        padding: 55px 0 90px;
        color: #ffffff;
        border-bottom: 2px solid #ff3344;
    }
    .mypage-container {
        margin-top: -60px;
        margin-bottom: 80px;
    }
    .dashboard-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        border: 1px solid #edf2f7;
        overflow: hidden;
    }
    .profile-header-box {
        padding: 35px 40px;
        background: #ffffff;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 20px;
    }
    .profile-avatar {
        width: 72px;
        height: 72px;
        background: linear-gradient(135deg, #ff3344, #ff6b4a);
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        font-weight: 800;
        box-shadow: 0 6px 16px rgba(255, 51, 68, 0.25);
    }
    .profile-info h3 {
        margin: 0 0 6px 0;
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
    }
    .profile-badge {
        display: inline-block;
        padding: 3px 12px;
        background: #f1f5f9;
        color: #475569;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    .quick-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
        padding: 25px 40px;
        background: #f8fafc;
        border-bottom: 1px solid #f1f5f9;
    }
    .stat-item {
        background: #ffffff;
        padding: 18px 20px;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        text-align: center;
    }
    .stat-label {
        font-size: 13px;
        color: #64748b;
        margin-bottom: 4px;
        font-weight: 600;
    }
    .stat-value {
        font-size: 20px;
        font-weight: 800;
        color: #0f172a;
    }
    .details-table {
        padding: 35px 40px;
    }
    .info-row {
        display: flex;
        padding: 14px 0;
        border-bottom: 1px solid #f1f5f9;
        font-size: 14px;
    }
    .info-row:last-child {
        border-bottom: none;
    }
    .info-key {
        width: 140px;
        font-weight: 700;
        color: #64748b;
    }
    .info-val {
        flex: 1;
        color: #1e293b;
        font-weight: 500;
    }
    .btn-action-primary {
        background: #0f172a;
        color: #ffffff !important;
        padding: 12px 26px;
        border-radius: 10px;
        font-weight: 700;
        font-size: 14px;
        text-decoration: none !important;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-action-primary:hover {
        background: #ff3344;
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(255, 51, 68, 0.25);
    }
</style>

<div class="mypage-hero">
    <div class="container text-center">
        <h2 style="font-weight: 800; font-size: 32px; letter-spacing: -0.5px; margin-bottom: 8px;">마이페이지</h2>
        <p style="color: #94a3b8; font-size: 15px; margin: 0;">나의 회원 정보와 활동 내역을 확인하세요.</p>
    </div>
</div>

<div class="container mypage-container">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="dashboard-card">
                <!-- 상단 프로필 헤더 -->
                <div class="profile-header-box">
                    <div class="d-flex align-items-center gap-3">
                        <div class="profile-avatar">
                            <%= name.length() > 0 ? name.substring(0, 1) : "U" %>
                        </div>
                        <div class="profile-info">
                            <h3><%= name %> <span style="font-size: 15px; font-weight: 400; color: #64748b;">(@<%= sessionId %>)</span></h3>
                            <span class="profile-badge">정회원</span>
                            <span class="profile-badge" style="background:#fee2e2; color:#ef4444; margin-left:4px;">COFFO 클럽</span>
                        </div>
                    </div>
                    <div>
                        <a href="updateMember.jsp" class="btn-action-primary">
                            <span>✏️</span> 회원정보 수정
                        </a>
                    </div>
                </div>

                <!-- 퀵 스탯 메뉴 -->
                <div class="quick-stats">
                    <div class="stat-item">
                        <div class="stat-label">장바구니</div>
                        <a href="cart.jsp" style="text-decoration: none;" class="stat-value text-primary">확인하기</a>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">주문내역</div>
                        <div class="stat-value">0건</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">가입일시</div>
                        <div class="stat-value" style="font-size: 15px; padding-top: 5px;"><%= registDay %></div>
                    </div>
                </div>

                <!-- 상세 기본 정보 섹션 -->
                <div class="details-table">
                    <h5 style="font-weight: 800; color: #0f172a; margin-bottom: 20px;">기본 계정 정보</h5>
                    
                    <div class="info-row">
                        <div class="info-key">아이디</div>
                        <div class="info-val"><%= sessionId %></div>
                    </div>
                    <div class="info-row">
                        <div class="info-key">성별 / 생년월일</div>
                        <div class="info-val"><%= gender %> / <%= birth %></div>
                    </div>
                    <div class="info-row">
                        <div class="info-key">연락처</div>
                        <div class="info-val"><%= phone %></div>
                    </div>
                    <div class="info-row">
                        <div class="info-key">이메일</div>
                        <div class="info-val"><%= mail %></div>
                    </div>
                    <div class="info-row">
                        <div class="info-key">등록된 배송지</div>
                        <div class="info-val"><%= address %></div>
                    </div>

                    <div class="mt-4 pt-3 d-flex justify-content-between align-items-center" style="border-top: 1px dashed #e2e8f0;">
                        <span style="font-size: 13px; color: #94a3b8;">계정 정보 수정이나 비밀번호 변경은 상단 버튼을 이용하세요.</span>
                        <a href="updateMember.jsp" class="text-danger" style="font-size: 13px; font-weight: 600; text-decoration: none;">회원탈퇴 안내 &gt;</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>