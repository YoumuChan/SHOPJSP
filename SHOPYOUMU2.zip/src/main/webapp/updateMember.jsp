<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
%>
        <script>
            alert("로그인이 필요합니다.");
            location.href = "login.jsp";
        </script>
<%
        return;
    }

    String password = "";
    String name = "";
    String gender = "남성";
    String birth = "";
    String mail = "";
    String phone = "";
    String address = "";

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM member WHERE UPPER(TRIM(id)) = UPPER(?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, sessionId);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            password = rs.getString("password");
            name = rs.getString("name");
            gender = rs.getString("gender");
            birth = rs.getString("birth");
            mail = rs.getString("mail");
            phone = rs.getString("phone");
            address = rs.getString("address");
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<% request.setAttribute("currentPage", "프로필 설정"); %>
<jsp:include page="nav.jsp" />

<style>
    .profile-hero {
        background: linear-gradient(135deg, #1f242d 0%, #0d1117 100%);
        padding: 60px 0 100px;
        color: #fff;
        text-align: center;
        border-bottom: 2px solid #ff3344;
    }
    .profile-container {
        margin-top: -60px;
        margin-bottom: 80px;
    }
    .custom-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 12px 35px rgba(0,0,0,0.08);
        border: 1px solid #edf2f7;
        overflow: hidden;
    }
    .card-top-accent {
        height: 6px;
        background: linear-gradient(90deg, #ff3344, #ff7b00);
    }
    .form-inner {
        padding: 45px 50px;
    }
    .input-box {
        margin-bottom: 22px;
    }
    .input-box label {
        font-size: 13px;
        font-weight: 700;
        color: #4a5568;
        letter-spacing: -0.2px;
        margin-bottom: 8px;
        display: block;
    }
    .custom-input {
        width: 100%;
        height: 50px;
        padding: 0 18px;
        background-color: #f8fafc;
        border: 1.5px solid #e2e8f0;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 500;
        color: #1a202c;
        transition: all 0.25s ease;
        box-sizing: border-box;
    }
    .custom-input:focus {
        background-color: #ffffff;
        border-color: #ff3344;
        box-shadow: 0 0 0 4px rgba(255, 51, 68, 0.1);
        outline: none;
    }
    .custom-input:read-only {
        background-color: #edf2f7;
        color: #718096;
        cursor: not-allowed;
        border-style: dashed;
    }
    .gender-pill-wrap {
        display: flex;
        gap: 12px;
    }
    .gender-pill-wrap input { display: none; }
    .gender-pill-wrap label {
        flex: 1;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f8fafc;
        border: 1.5px solid #e2e8f0;
        border-radius: 10px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 600;
        color: #64748b;
        transition: all 0.2s;
        margin: 0;
    }
    .gender-pill-wrap input:checked + label {
        background-color: #1e293b;
        border-color: #1e293b;
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(30, 41, 59, 0.2);
    }
    .btn-update {
        height: 52px;
        background: #111827;
        color: #ffffff;
        border: none;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 700;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    .btn-update:hover {
        background: #ff3344;
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 6px 18px rgba(255, 51, 68, 0.3);
    }
    .btn-unregister {
        height: 52px;
        background: #fff;
        color: #e11d48;
        border: 1.5px solid #fecdd3;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 600;
        transition: all 0.2s ease;
        padding: 0 24px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .btn-unregister:hover {
        background: #fff1f2;
        border-color: #e11d48;
        color: #be123c;
    }
</style>

<div class="profile-hero">
    <div class="container">
        <h2 style="font-weight: 800; font-size: 30px; letter-spacing: -1px; margin-bottom: 6px;">계정 프로필 관리</h2>
        <p style="color: #94a3b8; font-size: 14px; margin: 0;">원두처럼 신선하게 개인정보를 최신으로 유지하세요.</p>
    </div>
</div>

<div class="container profile-container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="custom-card">
                <div class="card-top-accent"></div>
                <div class="form-inner">
                    <form action="processUpdateMember.jsp" method="post">
                        <div class="row">
                            <div class="col-md-6 input-box">
                                <label>아이디 <span style="color:#94a3b8; font-weight: normal;">(고유값)</span></label>
                                <input type="text" name="id" class="custom-input" value="<%= sessionId %>" readonly>
                            </div>
                            <div class="col-md-6 input-box">
                                <label>보안 비밀번호 <span style="color:#ff3344;">*</span></label>
                                <input type="password" name="password" class="custom-input" value="<%= password %>" required placeholder="비밀번호 재설정">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 input-box">
                                <label>사용자 이름 <span style="color:#ff3344;">*</span></label>
                                <input type="text" name="name" class="custom-input" value="<%= name %>" required placeholder="이름을 입력하세요">
                            </div>
                            <div class="col-md-6 input-box">
                                <label>생년월일</label>
                                <input type="text" name="birth" class="custom-input" value="<%= birth != null ? birth : "" %>" placeholder="YYYY-MM-DD">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 input-box">
                                <label>성별</label>
                                <div class="gender-pill-wrap">
                                    <input type="radio" id="g_m" name="gender" value="남성" <%= "남성".equals(gender) ? "checked" : "" %>>
                                    <label for="g_m">남성</label>
                                    <input type="radio" id="g_w" name="gender" value="여성" <%= "여성".equals(gender) ? "checked" : "" %>>
                                    <label for="g_w">여성</label>
                                </div>
                            </div>
                            <div class="col-md-6 input-box">
                                <label>연락처</label>
                                <input type="tel" name="phone" class="custom-input" value="<%= phone != null ? phone : "" %>" placeholder="010-0000-0000">
                            </div>
                        </div>

                        <div class="input-box">
                            <label>이메일 주소</label>
                            <input type="email" name="mail" class="custom-input" value="<%= mail != null ? mail : "" %>" placeholder="example@coffo.com">
                        </div>

                        <div class="input-box">
                            <label>배송 / 기본 주소</label>
                            <input type="text" name="address" class="custom-input" value="<%= address != null ? address : "" %>" placeholder="주소를 입력해 주세요">
                        </div>

                        <div class="d-flex gap-3 pt-3" style="border-top: 1px solid #f1f5f9; margin-top: 10px;">
                            <button type="submit" class="btn-update flex-grow-1">
                                변경사항 저장하기
                            </button>
                            <a href="javascript:handleDelete()" class="btn-unregister">
                                회원탈퇴
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />

<script>
    function handleDelete() {
        if (confirm("정말로 탈퇴하시겠습니까?\n모든 회원 권한과 주문 이력이 삭제됩니다.")) {
            location.href = "deleteMember.jsp";
        }
    }
</script>
</body>
</html>