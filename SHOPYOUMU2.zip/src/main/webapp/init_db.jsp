<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*"%>
<!DOCTYPE html>
<html>
<head><title>DB 초기화</title></head>
<body>
<%
    Connection conn = null;
    Statement stmt = null;
    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        // 🌟 잠긴 system 대신 C##dbexam 계정으로 접속
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "1234");
        stmt = conn.createStatement();

        // 1. 기존 테이블 삭제 (없으면 무시)
        try { stmt.executeUpdate("DROP TABLE product"); } catch(Exception e) {}

        // 2. 테이블 생성
        String sqlCreate = "CREATE TABLE product("
                         + "p_id VARCHAR2(20) NOT NULL, "
                         + "p_name VARCHAR2(100), "
                         + "p_unitPrice NUMBER, "
                         + "p_description VARCHAR2(1000), "
                         + "p_category VARCHAR2(50), "
                         + "p_manufacturer VARCHAR2(50), "
                         + "p_unitsInStock NUMBER, "
                         + "p_condition VARCHAR2(20), "
                         + "p_fileName VARCHAR2(200), "
                         + "p_quantity NUMBER DEFAULT 0, "
                         + "PRIMARY KEY (p_id))";
        stmt.executeUpdate(sqlCreate);

        // 3. 20개 데이터 일괄 삽입
        String[] inserts = {
            "INSERT INTO product VALUES('P1001', '카페 아메리카노', 4500, '원두 : 에스프레소 로스트 / 바디감 : 미디엄 / 특징 : 진한 에스프레소와 깔끔한 물의 조화', 'Coffee', 'COFFO', 1000, 'New', 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=500', 0)",
            "INSERT INTO product VALUES('P1002', '카페 라떼', 5000, '원두 : 에스프레소 로스트 / 우유 : 고소한 스팀 밀크 / 특징 : 부드럽고 깊은 풍미', 'Coffee', 'COFFO', 1000, 'New', 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=500', 0)",
            "INSERT INTO product VALUES('P1003', '카푸치노', 5000, '원두 : 에스프레소 로스트 / 우유 : 풍성한 벨벳 밀크 폼 / 토핑 : 시나몬 파우더', 'Coffee', 'COFFO', 800, 'New', 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=500', 0)",
            "INSERT INTO product VALUES('P1004', '카라멜 마키아또', 5800, '원두 : 에스프레소 로스트 / 시럽 : 바닐라 시럽 / 드리즐 : 카라멜 소스', 'Coffee', 'COFFO', 500, 'New', 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?w=500', 0)",
            "INSERT INTO product VALUES('P1005', '바닐라 빈 라떼', 5800, '원두 : 에스프레소 로스트 / 시럽 : 천연 바닐라 빈 추출물 / 우유 : 신선한 1등급 원유', 'Coffee', 'COFFO', 600, 'New', 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=500', 0)",
            "INSERT INTO product VALUES('P1006', '콜드브루 커피', 5500, '추출방식 : 14시간 침출식 저온추출 / 원두 : 에티오피아 예가체프 / 바디감 : 깔끔한 클린컵', 'Coffee', 'COFFO', 300, 'New', 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=500', 0)",
            "INSERT INTO product VALUES('P1007', '제주 말차 라떼', 6200, '원료 : 유기농 제주 어린잎 말차 100% / 우유 : 부드러운 스팀 밀크 / 당도 : 은은한 단맛', 'Beverage', 'COFFO', 400, 'New', 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=500', 0)",
            "INSERT INTO product VALUES('P1008', '얼그레이 리저브 티', 4800, '찻잎 : 스리랑카 실론 홍차 / 향 : 천연 베르가못 오일 / 추출시간 : 3분 완벽 브루잉', 'Tea', 'COFFO', 500, 'New', 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500', 0)",
            "INSERT INTO product VALUES('P1009', '자몽 허니 블랙티', 6000, '베이스 : 진한 블랙티 / 과육 : 생자몽 슬라이스 / 꿀 : 아카시아 꿀 블렌딩', 'Tea', 'COFFO', 450, 'New', 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=500', 0)",
            "INSERT INTO product VALUES('P1010', '딸기 요거트 블렌디드', 6500, '과일 : 국산 설향 생딸기 과육 / 베이스 : 무가당 플레인 요거트 / 식감 : 부드러운 스무디', 'Beverage', 'COFFO', 300, 'New', 'https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=500', 0)",
            "INSERT INTO product VALUES('P1011', '플레인 크루아상', 3800, '버터 : 프랑스산 AOP 고메버터 100% / 식감 : 겉바속촉 24겹 레이어 / 제조 : 당일 새벽 베이킹', 'Bakery', 'COFFO Bakery', 150, 'New', 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=500', 0)",
            "INSERT INTO product VALUES('P1012', '뉴욕 치즈 케이크', 6800, '치즈 : 필라델피아 크림치즈 70% / 시트 : 바삭한 통밀 크러스트 / 텍스처 : 꾸덕하고 묵직함', 'Bakery', 'COFFO Bakery', 80, 'New', 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=500', 0)",
            "INSERT INTO product VALUES('P1013', '다크 초코 브라우니', 4500, '초콜릿 : 벨기에산 다크초콜릿 72% / 토핑 : 구운 피칸 / 특징 : 쫀득한 퍼지 스타일', 'Bakery', 'COFFO Bakery', 120, 'New', 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=500', 0)",
            "INSERT INTO product VALUES('P1014', '블루베리 베이글 & 크림치즈', 4200, '베이글 : 천연발효 블루베리 베이글 / 스프레드 : 허니 월넛 크림치즈 기본 제공', 'Bakery', 'COFFO Bakery', 200, 'New', 'https://images.unsplash.com/photo-1585478259715-876acc5be8eb?w=500', 0)",
            "INSERT INTO product VALUES('P1015', '에티오피아 예가체프 원두 (200g)', 16000, '원산지 : 에티오피아 / 컵노트 : 재스민, 살구, 베르가못 / 로스팅 : 미디엄 라이트', 'Beans', 'COFFO Roastery', 250, 'New', 'https://images.unsplash.com/photo-1587734195503-904fca47e0e9?w=500', 0)",
            "INSERT INTO product VALUES('P1016', '과테말라 안티구아 원두 (200g)', 15000, '원산지 : 과테말라 / 컵노트 : 다크초콜릿, 스모키, 아몬드 / 로스팅 : 풀 시티', 'Beans', 'COFFO Roastery', 300, 'New', 'https://images.unsplash.com/photo-1611854779393-1b2da9d400fe?w=500', 0)",
            "INSERT INTO product VALUES('P1017', '시그니처 하우스 블렌드 (500g)', 28000, '배합비 : 콜롬비아 50%, 브라질 30%, 에티오피아 20% / 밸런스 : 고소함과 단맛의 완벽 조화', 'Beans', 'COFFO Roastery', 150, 'New', 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=500', 0)",
            "INSERT INTO product VALUES('P1018', 'COFFO 세라믹 드립 세트', 35000, '재질 : 무광 세라믹 도자기 / 구성 : V60 드라이퍼 1~2인용 + 전용 유리 서버 600ml', 'Goods', 'COFFO Design', 90, 'New', 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?w=500', 0)",
            "INSERT INTO product VALUES('P1234', 'SONY 알파 A7R VI', 5995520, '종류 : 미러리스 / 화소 : 6680만화소 / 센서 : 풀프레임 / 손떨림보정 : 8.5스톱 광학식', 'computer device', 'SONY', 50, 'New', 'img-1.png', 0)",
            "INSERT INTO product VALUES('P1235', '네오북 N16GO', 339000, '제조사 : NEOBOOK / 브랜드 : 네오북(자체제작) / 화면 : 16인치 IPS / CPU : 인텔 N100', 'computer device', 'NEOBOOK', 100, 'New', 'img-2.png', 0)"
        };

        for (String sql : inserts) {
            stmt.executeUpdate(sql);
        }
        out.println("<h2 style='color:green;'>20개 상품 데이터가 오라클 DB(C##dbexam)에 성공적으로 저장되었습니다!</h2>");
        out.println("<a href='Products.jsp' style='font-size:18px;'>상품 목록 페이지(Products.jsp)로 이동</a>");
    } catch(Exception e) {
        out.println("<h2 style='color:red;'>에러 발생: " + e.getMessage() + "</h2>");
    } finally {
        if (stmt != null) try { stmt.close(); } catch(Exception e) {}
        if (conn != null) try { conn.close(); } catch(Exception e) {}
    }
%>
</body>
</html>