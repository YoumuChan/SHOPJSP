<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="dao.ProductRapository" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<jsp:include page="nav.jsp" />

<style>
    /* ------------------------------------------------------
       🌟 깨진 좌우 화살표 버튼을 양옆으로 구출하는 CSS
    --------------------------------------------------------- */
    .shop_layout_container {
        max-width: 1140px !important;
        margin: 0 auto !important;
        padding: 0 15px !important;
    }

    .slider_wrapper {
        position: relative !important;
        padding: 0 45px !important; 
        margin-bottom: 20px;
    }

    .slider_wrapper .owl-nav {
        display: block !important;
        position: absolute !important;
        width: 100% !important;
        top: 50% !important;
        left: 0 !important;
        transform: translateY(-50%) !important;
        z-index: 9999 !important;
        pointer-events: none;
    }
    .slider_wrapper .owl-nav .owl-prev,
    .slider_wrapper .owl-nav .owl-next {
        width: 40px !important;
        height: 40px !important;
        font-size: 16px !important;
        color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        position: absolute !important;
        pointer-events: auto;
        cursor: pointer !important;
        margin: 0 !important;
        padding: 0 !important;
        transition: background-color 0.2s ease-in-out !important;
    }
    .slider_wrapper .owl-nav .owl-prev { left: 0px !important; background-color: #ff0000 !important; }
    .slider_wrapper .owl-nav .owl-next { right: 0px !important; background-color: #424242 !important; }
    .slider_wrapper .owl-nav .owl-prev:hover, .slider_wrapper .owl-nav .owl-next:hover { background-color: #111111 !important; }

    .product_card_custom {
        box-shadow: 0 2px 8px rgba(0,0,0,0.04) !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease !important;
    }
    .product_card_custom:hover {
        transform: translateY(-4px) !important;
        box-shadow: 0 6px 16px rgba(0,0,0,0.08) !important;
    }
</style>

      <!-- 메인 배너 구역 -->
      <div class="banner_section layout_padding">
         <div class="container">
            <div id="banner_slider" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="row">
                        <div class="col-md-12">
                           <div class="banner_taital_main">
                              <h1 class="banner_taital"><fmt:message key="menu_shop" /></h1>
                              <%-- 🔄 하드코딩 변경: 배너 설명 --%>
                              <p class="banner_text"><fmt:message key="banner_desc" /></p>
                              <div class="btn_main">
                                 <div class="about_bt active"><a href="#"><fmt:message key="menu_about" /></a></div>
                                 <%-- 🔄 하드코딩 변경: 전화하기 버튼 --%>
                                 <div class="callnow_bt"><a href="#"><fmt:message key="btn_call_now" /></a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
   </div> <!-- header_section 종료 -->

   <!-- 인사말 구역 -->
   <div style="padding: 40px 0; text-align: center; background-color: #f8f9fa; border-top: 1px solid #eee; border-bottom: 1px solid #eee;">
       <% request.setAttribute("currentPage", "홈"); %>
       <%-- 🔄 하드코딩 자바 변수 제거하고 다국어 바인딩 --%>
       <h1 style="font-weight: bold; color: #222222 !important;"><fmt:message key="main_greeting" /></h1>
       <h3 style="color: #666666 !important;"><fmt:message key="main_tagline" /></h3>
   </div>

   <!-- About Our Shop 섹션 -->
   <div class="about_section layout_padding">
      <div class="container">
         <div class="about_section_2">
            <div class="row">
               <div class="col-md-6"> 
                  <div class="about_taital_box">
                     <%-- 🔄 하드코딩 변경: 매장 소개 제목/소제목/설명 --%>
                     <h1 class="about_taital"><fmt:message key="about_shop_title" /></h1>
                     <h1 class="about_taital_1"><fmt:message key="about_shop_subtitle" /></h1>
                     <p class=" about_text"><fmt:message key="about_shop_desc" /></p>
                     <div class="readmore_btn"><a href="#"><fmt:message key="btn_read_more" /></a></div>
                  </div>
               </div>
               <div class="col-md-6"> 
                  <div class="image_iman"><img src="images/about-img.png" class="about_img"></div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <!-- 상품 슬라이더 섹션 -->
   <div class="coffee_section layout_padding">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <%-- 🔄 하드코딩 변경: OUR SHOP OFFER 전체 치환 --%>
               <h1 class="coffee_taital"><fmt:message key="coffee_offer_title" /></h1>
            </div>
         </div>
      </div>
      
      <div class="shop_layout_container">
         <div class="slider_wrapper">
            <div id="new-carousel" class="owl-carousel owl-theme">
                <%
                    ProductRapository dao = ProductRapository.getInstance();
                    ArrayList<Product> newProducts = dao.getNewProducts();
                    DecimalFormat formatter = new DecimalFormat("#,###");
                    
                    if(newProducts != null && !newProducts.isEmpty()) {
                        for (Product product : newProducts) {
                            String filename = product.getFilenameString();
                            String finalSrc = "images/img-1.png";
                            
                            if (filename != null && !filename.isEmpty()) {
                                if (filename.trim().startsWith("http")) {
                                    finalSrc = filename.trim();
                                } else {
                                    finalSrc = "images/" + filename.trim();
                                }
                            }
                %>
                <div class="item">
                    <div class="product_card_custom" style="border: 1px solid #e9ecef !important; border-radius: 6px !important; background: #ffffff !important; overflow: hidden !important; display: flex !important; flex-direction: column !important; height: 100% !important;">
                        <div class="coffee_img" style="height: 200px !important; display: flex !important; align-items: center !important; justify-content: center !important; background: #fafafa !important;">
                            <img src="<%= finalSrc %>" alt="<%= product.getNameString() %>" style="max-height: 90% !important; width: auto !important; object-fit: contain !important;" onerror="this.src='images/img-1.png';">
                        </div>
                        <div class="coffee_box" style="padding: 18px 12px !important; background: #ffffff !important; text-align: center !important; flex-grow: 1 !important; display: flex !important; flex-direction: column !important; justify-content: space-between !important;">
                            <h3 class="types_text" style="font-size: 16px !important; font-weight: bold !important; color: #222222 !important; white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important; margin-bottom: 6px !important;"><%= product.getNameString() %></h3>
                            <p style="font-size: 13px !important; color: #666666 !important; line-height: 1.4 !important; height: 36px !important; overflow: hidden; margin-bottom: 12px !important; display: -webkit-box !important; -webkit-line-clamp: 2; -webkit-box-orient: vertical !important; word-break: break-all !important;"><%= product.getDescripString() != null ? product.getDescripString() : "" %></p>
                            <p class="looking_text" style="font-size: 16px !important; font-weight: bold !important; color: #ff0000 !important; margin-bottom: 12px !important;"><%= formatter.format(product.getUnitPrice()) %>원</p>
                            <div style="text-align: center !important; margin-top: auto !important;">
                                <a href="ShowProductData.jsp?id=<%= product.getProductIDString() %>" style="display: inline-block !important; width: 100% !important; padding: 8px 0 !important; background-color: #252525 !important; color: #ffffff !important; font-size: 13px !important; font-weight: bold !important; border-radius: 4px !important; text-decoration: none; transition: background-color 0.2s !important;">상세정보</a>
                            </div>
                        </div>
                    </div>
                </div>
                <% 
                        }
                    }
                %>
            </div>
         </div>
      </div>
   </div>

   <!-- Blog 섹션 -->
   <div class="blog_section layout_padding">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <h1 class="about_taital">Our <fmt:message key="menu_blog" /></h1>
            </div>
         </div>
         <div class="blog_section_2">
            <div class="row">
               <%-- 블로그 카드 1 --%>
               <div class="col-md-6">
                  <div class="blog_box">
                     <div class="blog_img"><img src="images/blog-img1.png"></div>
                     <%-- 🔄 하드코딩 변경: 블로그 날짜, 제목, 설명 --%>
                     <h4 class="date_text"><fmt:message key="blog_date" /></h4>
                     <h4 class="prep_text"><fmt:message key="blog_sub_1" /></h4>
                     <p class="lorem_text"><fmt:message key="blog_desc" /></p>
                  </div>
                  <div class="read_btn"><a href="#"><fmt:message key="btn_read_more" /></a></div>
               </div>
               <%-- 블로그 카드 2 --%>
               <div class="col-md-6">
                  <div class="blog_box">
                     <div class="blog_img"><img src="images/blog-img2.png"></div>
                     <%-- 🔄 하드코딩 변경: 블로그 날짜, 제목, 설명 --%>
                     <h4 class="date_text"><fmt:message key="blog_date" /></h4>
                     <h4 class="prep_text"><fmt:message key="blog_sub_2" /></h4>
                     <p class="lorem_text"><fmt:message key="blog_desc" /></p>
                  </div>
                  <div class="read_btn"><a href="#"><fmt:message key="btn_read_more" /></a></div>
               </div>
            </div>
         </div>
      </div>
   </div>

<jsp:include page="footer.jsp" />

<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>

<script type="text/javascript">
   $(document).ready(function () {
      $('.navbar-toggler').on('click', function () {
         var target = $(this).attr('data-target');
         $(target).toggleClass('show');
      });
      
      var newOwl = $('#new-carousel');
      if (newOwl.length > 0) {
          newOwl.owlCarousel({
              loop: true,
              margin: 30,
              nav: true,
              autoplay: true,
              autoplayTimeout: 3000,
              autoplayHoverPause: true,
              navText: ["<i class='fa fa-arrow-left'></i>", "<i class='fa fa-arrow-right'></i>"],
              responsive: {
                  0: { items: 1 },
                  576: { items: 2 },
                  768: { items: 3 },
                  992: { items: 4 }
              }
          });
      }
   });
</script>

</body>
</html>