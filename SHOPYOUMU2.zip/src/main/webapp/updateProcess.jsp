<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    if (sessionId == null || sessionId.trim().isEmpty()) {
        response.sendRedirect("login.jsp");
        return;
    }

    String numStr = request.getParameter("num");
    String pageNumStr = request.getParameter("pageNum");
    String subject = request.getParameter("subject");
    String content = request.getParameter("content");

    if (numStr == null || subject == null || content == null) {
        response.sendRedirect("list.jsp");
        return;
    }

    int num = Integer.parseInt(numStr);

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "";
        if ("admin".equalsIgnoreCase(sessionId)) {
            sql = "UPDATE board SET subject = ?, content = ? WHERE num = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, subject.trim());
            pstmt.setString(2, content.trim());
            pstmt.setInt(3, num);
        } else {
            sql = "UPDATE board SET subject = ?, content = ? WHERE num = ? AND id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, subject.trim());
            pstmt.setString(2, content.trim());
            pstmt.setInt(3, num);
            pstmt.setString(4, sessionId.trim());
        }

        int result = pstmt.executeUpdate();

        if (result > 0) {
%>
            <script>
                alert("게시글이 성공적으로 수정되었습니다.");
                location.href = "view.jsp?num=<%= num %>&pageNum=<%= pageNumStr %>";
            </script>
<%
        } else {
%>
            <script>
                alert("수정 권한이 없거나 처리에 실패했습니다.");
                history.back();
            </script>
<%
        }
    } catch (Exception e) {
        e.printStackTrace();
%>
        <script>
            alert("DB 에러 발생: <%= e.getMessage() %>");
            history.back();
        </script>
<%
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>