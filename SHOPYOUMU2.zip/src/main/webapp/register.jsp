<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<jsp:include page="nav.jsp" />
</div>

<div class="register_section" style="background-color: #f4f5f7; padding: 80px 0;">
    <div class="container" style="max-width: 550px; margin: 0 auto;">
        <div class="card" style="background: #fff; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); padding: 50px 40px;">
            <h2 style="text-align: center; font-weight: 900; color: #111; letter-spacing: 1px; margin-bottom: 40px; border-bottom: 3px solid #ff3b30; display: inline-block; padding-bottom: 10px; width: 100%;">JOIN US</h2>
            
            <form action="registerProcess.jsp" method="post">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">희망 아이디 <span style="color: #ff3b30;">*</span></label>
                    <input type="text" name="userId" placeholder="사용할 아이디 영문/숫자" required 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">비밀번호 <span style="color: #ff3b30;">*</span></label>
                    <input type="password" name="userPw" placeholder="비밀번호 입력" required 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">이름 <span style="color: #ff3b30;">*</span></label>
                    <input type="text" name="userName" placeholder="실명 입력" required 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <div style="margin-bottom: 35px;">
                    <label style="display: block; font-weight: 600; color: #333; margin-bottom: 8px; font-size: 14px;">전화번호</label>
                    <input type="tel" name="phone" placeholder="010-0000-0000" 
                           style="width: 100%; height: 50px; padding: 0 15px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; font-size: 15px;">
                </div>
                
                <button type="submit" style="width: 100%; height: 55px; background-color: #ff3b30; color: #fff; border: none; border-radius: 6px; font-size: 16px; font-weight: bold; cursor: pointer;">회원가입 완료</button>
            </form>

            <div style="text-align: center; margin-top: 25px;">
                <a href="login.jsp" style="color: #666; font-size: 14px; text-decoration: underline;">이미 계정이 있으신가요? 로그인 화면으로</a>
            </div>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>