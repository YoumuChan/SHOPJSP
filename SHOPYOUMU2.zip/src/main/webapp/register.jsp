<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<% request.setAttribute("currentPage", "회원가입"); %>
<jsp:include page="nav.jsp" />

<style>
    .auth-container {
        min-height: 80vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #fafafa;
        padding: 60px 20px;
    }
    .auth-card {
        background: #ffffff;
        border: 1px solid #eaeaea;
        border-radius: 12px;
        width: 100%;
        max-width: 650px;
        padding: 50px 40px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
    }
    .auth-title {
        font-size: 26px;
        font-weight: 700;
        color: #111111;
        margin-bottom: 8px;
    }
    .auth-subtitle {
        font-size: 14px;
        color: #767676;
        margin-bottom: 35px;
    }
    .auth-field {
        margin-bottom: 20px;
    }
    .auth-label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #333333;
        margin-bottom: 8px;
    }
    .auth-label span {
        color: #e53935;
    }
    .auth-input {
        width: 100%;
        height: 48px;
        padding: 0 16px;
        background-color: #f8f9fa;
        border: 1px solid #e1e4e8;
        border-radius: 8px;
        font-size: 14px;
        color: #111111;
        outline: none;
        box-sizing: border-box;
        transition: all 0.2s ease;
    }
    .auth-input:focus {
        background-color: #ffffff;
        border-color: #111111;
    }
    .gender-group {
        display: flex;
        gap: 12px;
    }
    .gender-group input[type="radio"] {
        display: none;
    }
    .gender-group label {
        flex: 1;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #f8f9fa;
        border: 1px solid #e1e4e8;
        border-radius: 8px;
        font-size: 14px;
        color: #555;
        cursor: pointer;
        margin: 0;
        transition: all 0.2s;
    }
    .gender-group input[type="radio"]:checked + label {
        background-color: #111111;
        border-color: #111111;
        color: #ffffff;
        font-weight: 600;
    }
    .btn-auth-submit {
        width: 100%;
        height: 52px;
        background-color: #111111;
        color: #ffffff;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: 600;
        cursor: pointer;
        margin-top: 15px;
        transition: background-color 0.2s;
    }
    .btn-auth-submit:hover {
        background-color: #333333;
    }
    .auth-footer {
        text-align: center;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #f1f1f1;
        font-size: 13px;
        color: #666;
    }
    .auth-footer a {
        color: #111;
        font-weight: 600;
        text-decoration: underline;
        margin-left: 6px;
    }
</style>

<div class="auth-container">
    <div class="auth-card">
        <h2 class="auth-title">회원가입</h2>
        <p class="auth-subtitle">COFFO 스토어의 회원이 되어 다양한 혜택을 이용해 보세요.</p>

        <form action="registerProcess.jsp" method="post">
            <div class="row">
                <div class="col-md-6 auth-field">
                    <label class="auth-label">아이디 <span>*</span></label>
                    <input type="text" name="id" class="auth-input" placeholder="영문/숫자 입력" required autocomplete="off">
                </div>
                <div class="col-md-6 auth-field">
                    <label class="auth-label">비밀번호 <span>*</span></label>
                    <input type="password" name="password" class="auth-input" placeholder="비밀번호 입력" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 auth-field">
                    <label class="auth-label">성명 <span>*</span></label>
                    <input type="text" name="name" class="auth-input" placeholder="실명 입력" required>
                </div>
                <div class="col-md-6 auth-field">
                    <label class="auth-label">생년월일</label>
                    <input type="text" name="birth" class="auth-input" placeholder="YYYY-MM-DD">
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 auth-field">
                    <label class="auth-label">성별</label>
                    <div class="gender-group">
                        <input type="radio" id="gender_m" name="gender" value="남성" checked>
                        <label for="gender_m">남성</label>
                        <input type="radio" id="gender_f" name="gender" value="여성">
                        <label for="gender_f">여성</label>
                    </div>
                </div>
                <div class="col-md-6 auth-field">
                    <label class="auth-label">전화번호</label>
                    <input type="tel" name="phone" class="auth-input" placeholder="010-0000-0000">
                </div>
            </div>

            <div class="auth-field">
                <label class="auth-label">이메일</label>
                <input type="email" name="mail" class="auth-input" placeholder="example@coffo.com">
            </div>

            <div class="auth-field">
                <label class="auth-label">주소</label>
                <input type="text" name="address" class="auth-input" placeholder="기본 주소 및 상세 주소 입력">
            </div>

            <button type="submit" class="btn-auth-submit">회원가입 완료</button>
        </form>

        <div class="auth-footer">
            이미 계정이 있으신가요? <a href="login.jsp">로그인하기</a>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>