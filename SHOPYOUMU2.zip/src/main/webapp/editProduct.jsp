<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.DecimalFormat" %>

<%
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || !sessionId.equals("admin")) {
        response.sendRedirect("login.jsp");
        return;
    }

    String edit = request.getParameter("edit");
    if (edit == null) edit = "update";
%>

<%@ include file="nav.jsp" %>
</div>

<div class="container my-5" style="min-height: 600px;">
    <div class="text-center mb-5">
        <h2 class="fw-bold" style="color: #222;">⚙️ 상품 <%= edit.equals("update") ? "수정" : "삭제" %> (관리자)</h2>
        <p class="text-muted">오라클 데이터베이스에 등록된 상품을 실시간 관리합니다.</p>
    </div>

    <div class="row">
        <%
            DecimalFormat formatter = new DecimalFormat("#,###");
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");

                String sql = "SELECT * FROM product ORDER BY p_id ASC";
                pstmt = conn.prepareStatement(sql);
                rs = pstmt.executeQuery();

                while (rs.next()) {
                    String id = rs.getString("p_id");
                    String name = rs.getString("p_name");
                    int unitPrice = rs.getInt("p_unitPrice");
                    String desc = rs.getString("p_description");
                    String filename = rs.getString("p_fileName");

                    String finalSrc = "images/img-1.png";
                    if (filename != null && !filename.isEmpty()) {
                        if (filename.trim().startsWith("http")) finalSrc = filename.trim();
                        else finalSrc = "images/" + filename.trim();
                    }
        %>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 shadow-sm text-center p-3">
                    <div style="height: 180px; display: flex; align-items: center; justify-content: center; background: #fafafa; margin-bottom: 15px;">
                        <img src="<%= finalSrc %>" style="max-height: 100%; max-width: 100%; object-fit: contain;" onerror="this.src='images/img-1.png';">
                    </div>
                    <h5 class="fw-bold text-truncate"><%= name %></h5>
                    <p class="text-muted text-truncate" style="font-size: 13px;"><%= desc != null ? desc : "" %></p>
                    <p class="text-danger fw-bold"><%= formatter.format(unitPrice) %>원</p>
                    <div class="mt-auto">
                        <% if (edit.equals("update")) { %>
                            <a href="updateProduct.jsp?id=<%= id %>" class="btn btn-success w-100 fw-bold">수정 &raquo;</a>
                        <% } else if (edit.equals("delete")) { %>
                            <a href="javascript:deleteConfirm('<%= id %>')" class="btn btn-danger w-100 fw-bold">삭제 &raquo;</a>
                        <% } %>
                    </div>
                </div>
            </div>
        <%
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (rs != null) try { rs.close(); } catch (Exception e) {}
                if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
                if (conn != null) try { conn.close(); } catch (Exception e) {}
            }
        %>
    </div>
</div>

<%@ include file="footer.jsp" %>

<script type="text/javascript">
    function deleteConfirm(id) {
        if (confirm("정말 " + id + " 상품을 삭제하시겠습니까?")) {
            location.href = "deleteProduct.jsp?id=" + id;
        }
    }
</script>
</body>
</html>