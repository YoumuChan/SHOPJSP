<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="dto.Product" %>
<%@ page import="dao.ProductRapository" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>상품 상세 정보</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    
    <style>
        .detail_container { padding-bottom: 60px; margin-top: 40px; }
        .product_title { font-size: 32px; font-weight: 800; color: #111; margin-bottom: 12px; }
        .product_price { font-size: 28px; color: #ff0000; font-weight: bold; margin-bottom: 25px; }
        .info_group p { margin-bottom: 8px; color: #444; font-size: 15px; }
        
        .premium_spec_zone {
            background-color: #fafafa !important;
            border: 1px solid #e5e5e5 !important;
            padding: 18px 22px !important;
            border-radius: 6px !important;
            margin-bottom: 25px !important;
            line-height: 2.2 !important;
        }
        .premium_spec_item { font-size: 14px !important; color: #222222 !important; display: inline-block !important; font-weight: 500; }
        .premium_spec_key { font-weight: 700 !important; color: #007bff !important; }
        .premium_spec_value { color: #333 !important; }
        .premium_divider { color: #dddddd !important; margin: 0 12px !important; font-size: 14px !important; display: inline-block; font-weight: 300; }
    </style>
</head>
<body>

    <% request.setAttribute("currentPage", "상품 상세 정보"); %>
    <jsp:include page="nav.jsp" />

    <%
        request.setCharacterEncoding("UTF-8");
        String id = request.getParameter("id");
        if (id == null || id.trim().isEmpty()) {
            id = "P1001";
        }
        id = id.trim();

        DecimalFormat formatter = new DecimalFormat("#,###");

        String name = "";
        int unitPrice = 0;
        String description = "";
        String manufacturer = "";
        String category = "";
        long unitsInStock = 0;
        String condition = "New";
        String filename = "images/img-1.png";
        boolean isExist = false;
    %>

    <%-- 🌟 1. DB 연결 모듈 로드 --%>
    <%@ include file="dbconn.jsp" %>

    <%
        // 🌟 2. DB 단건 조회 (과제 요구사항 구현)
        try {
            if (conn != null) {
                String sql = "SELECT * FROM product WHERE UPPER(TRIM(p_id)) = UPPER(?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, id);
                rs = pstmt.executeQuery();

                if (rs.next()) {
                    isExist = true;
                    id = rs.getString("p_id");
                    name = rs.getString("p_name");
                    unitPrice = rs.getInt("p_unitPrice");
                    description = rs.getString("p_description");
                    category = rs.getString("p_category");
                    manufacturer = rs.getString("p_manufacturer");
                    unitsInStock = rs.getLong("p_unitsInStock");
                    condition = rs.getString("p_condition");
                    filename = rs.getString("p_fileName");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (Exception e) {}
            if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
            if (conn != null) try { conn.close(); } catch (Exception e) {}
        }

        // 🌟 3. DB 미등록 상품에 대한 백업 리포지토리 매칭
        if (!isExist) {
            ProductRapository dao = ProductRapository.getInstance();
            Product p = dao.getProductById(id);
            if (p == null) p = dao.getProductById(id.toUpperCase());
            if (p == null) p = dao.getProductById(id.toLowerCase());

            if (p != null) {
                isExist = true;
                id = p.getProductIDString();
                name = p.getNameString();
                unitPrice = p.getUnitPrice();
                description = p.getDescripString();
                manufacturer = p.getManufacturer();
                category = p.getCategoryString();
                unitsInStock = p.getUnitsInStock();
                condition = p.getConditionString();
                filename = p.getFilenameString();
            }
        }

        String finalSrc = "images/img-1.png";
        if (filename != null && !filename.isEmpty()) {
            if (filename.trim().startsWith("http")) {
                finalSrc = filename.trim();
            } else if (filename.trim().startsWith("images/")) {
                finalSrc = filename.trim();
            } else {
                finalSrc = "images/" + filename.trim();
            }
        }
    %>

    <div class="detail_container">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <img src="<%= finalSrc %>" style="width: 100%; border: 1px solid #e1e1e1; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);" onerror="this.src='images/img-1.png';">
                </div>
                
                <div class="col-md-7" style="padding-left: 45px;">
                    <h1 class="product_title"><%= name %></h1>
      
                    <div class="premium_spec_zone">
                        <%
                            if (description != null && !description.isEmpty()) {
                                String[] sections = description.split("/");
                                for (int i = 0; i < sections.length; i++) {
                                    String section = sections[i].trim();
                                    if (section.isEmpty()) continue;
                                    
                                    if (section.contains(":")) {
                                        String[] kv = section.split(":");
                                        String key = kv[0].trim();
                                        String val = kv.length > 1 ? kv[1].trim() : "";
                        %>
                                        <span class="premium_spec_item">
                                            <span class="premium_spec_key"><%= key %> :</span>
                                            <span class="premium_spec_value"><%= val %></span>
                                        </span>
                        <%
                                    } else {
                        %>
                                        <span class="premium_spec_item"><%= section %></span>
                        <%
                                    }
                                    if (i < sections.length - 1) { %>
                                        <span class="premium_divider">/</span>
                        <%          }
                                }
                            } else {
                        %>
                            <span class="premium_spec_item">상세 설명이 등록되어 있지 않습니다.</span>
                        <%
                            }
                        %>
                    </div>
           
                    <p class="product_price"><%= formatter.format(unitPrice) %>원</p>
                    
                    <div class="info_group" style="border-top: 1px solid #eee; padding-top: 20px;">
                        <p><strong>상품 코드:</strong> <span class="badge badge-dark" style="font-size:13px; padding: 5px 8px; background-color: #333;"><%= id %></span></p>
                        <p><strong>제조사:</strong> <%= manufacturer != null ? manufacturer : "-" %></p>
                        <p><strong>분류:</strong> <%= category != null ? category : "-" %></p>
                        <p><strong>재고 수량:</strong> <%= unitsInStock %>개</p>
                        <p><strong>상태:</strong> <%= condition != null ? condition : "New" %></p>
                    </div>
                    
                    <div style="margin-top: 35px;">
                        <a href="shippingInfo.jsp" class="btn btn-danger btn-lg px-5 font-weight-bold" style="border-radius:4px;">구매하기</a>
                        <a href="javascript:addToCart('<%= id %>')" class="btn btn-warning btn-lg px-4 font-weight-bold text-white" style="border-radius:4px; margin-left: 10px;">장바구니 담기</a>
                        <a href="Products.jsp" class="btn btn-dark btn-lg px-4 font-weight-bold" style="border-radius:4px; margin-left: 10px;">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i> 상품 목록
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <%@ include file="footer.jsp" %>

    <script type="text/javascript">
        function addToCart(productId) {
            if (confirm("해당 상품을 장바구니에 추가하시겠습니까?")) {
                location.href = "addCart.jsp?id=" + productId;
            }
        }
    </script>
</body>
</html>