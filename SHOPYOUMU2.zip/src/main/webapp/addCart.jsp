<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.sql.*" %>
<%@ page import="dto.Product" %>
<%@ page import="dao.ProductRapository" %>

<%
    request.setCharacterEncoding("UTF-8");
    String id = request.getParameter("id");

    if (id == null || id.trim().isEmpty()) {
        response.sendRedirect("Products.jsp");
        return;
    }
    id = id.trim();

    Product product = null;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // 1. 오라클 데이터베이스에서 단건 조회
    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM product WHERE UPPER(TRIM(p_id)) = UPPER(TRIM(?))";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            product = new Product();
            product.setProductIDString(rs.getString("p_id"));
            product.setNameString(rs.getString("p_name"));
            product.setUnitPrice(rs.getInt("p_unitPrice"));
            product.setDescripString(rs.getString("p_description"));
            product.setCategoryString(rs.getString("p_category"));
            product.setManufacturer(rs.getString("p_manufacturer"));
            product.setUnitsInStock(rs.getLong("p_unitsInStock"));
            product.setConditionString(rs.getString("p_condition"));
            product.setFilenameString(rs.getString("p_fileName"));
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    // 2. DB에 없으면 자바 싱글톤 리포지토리에서 백업 조회
    if (product == null) {
        ProductRapository dao = ProductRapository.getInstance();
        product = dao.getProductById(id);
        if (product == null) product = dao.getProductById(id.toUpperCase());
        if (product == null) product = dao.getProductById(id.toLowerCase());
    }

    // 어디에도 없는 경우 에러 페이지 이동
    if (product == null) {
        response.sendRedirect("exceptionNoProductId.jsp?id=" + id);
        return;
    }

    // 3. 세션 장바구니 리스트(cartList) 처리
    ArrayList<Product> list = (ArrayList<Product>) session.getAttribute("cartList");
    if (list == null) {
        list = new ArrayList<Product>();
        session.setAttribute("cartList", list);
    }

    // 4. 중복 담기 체크 및 추가
    boolean isExist = false;
    for (Product p : list) {
        if (p.getProductIDString() != null && p.getProductIDString().equalsIgnoreCase(id)) {
            isExist = true;
            break;
        }
    }

    if (!isExist) {
        list.add(product);
    }

    // 5. 장바구니 페이지로 이동
    response.sendRedirect("cart.jsp");
%>