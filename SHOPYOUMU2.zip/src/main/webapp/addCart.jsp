<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.sql.*" %>
<%@ page import="dto.Product" %>

<%
    request.setCharacterEncoding("UTF-8");
    String id = request.getParameter("id");

    if (id == null || id.trim().isEmpty()) {
        response.sendRedirect("Products.jsp");
        return;
    }

    Product product = null;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    // 1. 오라클 데이터베이스에서 해당 상품 정보 단건 조회
    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");

        String sql = "SELECT * FROM product WHERE p_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            product = new Product();
            product.setProductIDString(rs.getString("p_id"));
            product.setNameString(rs.getString("p_name"));
            product.setUnitPrice(rs.getInt("p_unitPrice"));
            product.setDescripString(rs.getString("p_description"));
            product.setCategoryString(rs.getString("p_category"));
            product.setManufacturer(rs.getString("p_manufacturer"));
            product.setUnitsInStock(rs.getLong("p_unitsInStock"));
            product.setConditionString(rs.getString("p_condition"));
            product.setFilenameString(rs.getString("p_fileName"));
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    // 상품이 DB에 없으면 예외 페이지 또는 상품 목록으로 이동
    if (product == null) {
        response.sendRedirect("exceptionNoProductId.jsp?id=" + id);
        return;
    }

    // 2. 세션 장바구니 리스트(cartList) 처리
    ArrayList<Product> list = (ArrayList<Product>) session.getAttribute("cartList");
    if (list == null) {
        list = new ArrayList<Product>();
        session.setAttribute("cartList", list);
    }

    // 3. 중복 담기 체크 및 추가
    boolean isExist = false;
    for (Product p : list) {
        if (p.getProductIDString().equals(id)) {
            isExist = true;
            break;
        }
    }

    if (!isExist) {
        list.add(product);
    }

    // 4. 장바구니 페이지로 이동
    response.sendRedirect("cart.jsp");
%>