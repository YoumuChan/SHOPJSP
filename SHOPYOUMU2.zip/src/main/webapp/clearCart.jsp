<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // 세션에서 장바구니 리스트(cartList)를 통째로 지워버리기
    session.removeAttribute("cartList");

    // 다 비웠으니 다시 장바구니 화면(cart.jsp)으로 강제 소환
    response.sendRedirect("cart.jsp");
%>