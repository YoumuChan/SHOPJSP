<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<% request.setAttribute("currentPage", "회원정보"); %>
<jsp:include page="nav.jsp" />

<%
    String msg = request.getParameter("msg");
    boolean isUpdated = "0".equals(msg);
%>

<style>
    .result-wrapper {
        min-height: 550px;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 60px 15px;
        background: #fbfbfc;
    }
    .result-box {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #e9ecef;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
        max-width: 680px;
        width: 100%;
        text-align: center;
        padding: 50px 30px;
    }
    .status-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 64px;
        height: 64px;
        border-radius: 50%;
        margin-bottom: 20px;
        font-size: 26px;
    }
    .badge-blue {
        background-color: #eff6ff;
        color: #2563eb;
        border: 2px solid #bfdbfe;
    }
    .badge-amber {
        background-color: #fffbeb;
        color: #d97706;
        border: 2px solid #fde68a;
    }
    .msg-banner-blue {
        background: #e0f2fe;
        color: #0369a1;
        border: 1px solid #bae6fd;
        padding: 18px 24px;
        border-radius: 12px;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: -0.3px;
        margin: 20px 0 30px;
    }
    .msg-banner-amber {
        background: #fef3c7;
        color: #92400e;
        border: 1px solid #fde68a;
        padding: 18px 24px;
        border-radius: 12px;
        font-size: 19px;
        font-weight: 700;
        letter-spacing: -0.3px;
        margin: 20px 0 30px;
    }
    .action-btn-main {
        display: inline-block;
        background: #111827;
        color: #ffffff !important;
        padding: 12px 32px;
        border-radius: 8px;
        font-weight: 600;
        text-decoration: none !important;
        transition: all 0.2s;
    }
    .action-btn-main:hover {
        background: #ff3344;
        transform: translateY(-2px);
    }
</style>

<div class="result-wrapper">
    <div class="result-box">
        <h3 style="font-weight: 800; color: #1e293b; margin-bottom: 24px;">회원정보</h3>

        <% if (isUpdated) { %>
            <!-- 🌟 회원정보 수정 완료 상태 (msg=0) -->
            <div class="status-badge badge-blue">
                ✓
            </div>
            <div class="msg-banner-blue">
                회원정보가 수정되었습니다.
            </div>
            <p style="color: #64748b; font-size: 14px; margin-bottom: 30px;">
                수정하신 프로필 데이터가 데이터베이스에 성공적으로 반영되었습니다.
            </p>
            <a href="main.jsp" class="action-btn-main">홈으로 돌아가기</a>
        <% } else { %>
            <!-- 🌟 회원 탈퇴 완료 상태 (msg 없음) -->
            <div class="status-badge badge-amber">
                !
            </div>
            <div class="msg-banner-amber">
                회원정보가 존재하지 않습니다.
            </div>
            <p style="color: #64748b; font-size: 14px; margin-bottom: 30px;">
                회원 탈퇴가 안전하게 처리되었으며 세션이 종료되었습니다.
            </p>
            <a href="login.jsp" class="action-btn-main">로그인 화면으로</a>
        <% } %>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>