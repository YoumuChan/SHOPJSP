<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="com.oreilly.servlet.*" %>
<%@ page import="com.oreilly.servlet.multipart.*" %>
<%@ page import="java.util.Enumeration" %>

<%
    request.setCharacterEncoding("UTF-8");

    String realFolder = application.getRealPath("/images");
    int maxSize = 5 * 1024 * 1024;
    String encType = "utf-8";

    MultipartRequest multi = new MultipartRequest(request, realFolder, maxSize, encType, new DefaultFileRenamePolicy());

    String productId = multi.getParameter("productId");
    String name = multi.getParameter("name");
    String unitPriceStr = multi.getParameter("unitPrice");
    String description = multi.getParameter("description");
    String manufacturer = multi.getParameter("manufacturer");
    String category = multi.getParameter("category");
    String unitsInStockStr = multi.getParameter("unitsInStock");
    String condition = multi.getParameter("condition");
    String oldFileName = multi.getParameter("oldFileName");

    int unitPrice = Integer.parseInt(unitPriceStr);
    long unitsInStock = Long.parseLong(unitsInStockStr);

    Enumeration files = multi.getFileNames();
    String fname = (String) files.nextElement();
    String fileName = multi.getFilesystemName(fname);

    if (fileName == null || fileName.isEmpty()) {
        fileName = oldFileName;
    }

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");

        String sql = "UPDATE product SET p_name=?, p_unitPrice=?, p_description=?, p_category=?, p_manufacturer=?, p_unitsInStock=?, p_condition=?, p_fileName=? WHERE p_id=?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, name);
        pstmt.setInt(2, unitPrice);
        pstmt.setString(3, description);
        pstmt.setString(4, category);
        pstmt.setString(5, manufacturer);
        pstmt.setLong(6, unitsInStock);
        pstmt.setString(7, condition);
        pstmt.setString(8, fileName);
        pstmt.setString(9, productId);

        pstmt.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    response.sendRedirect("editProduct.jsp?edit=update");
%>