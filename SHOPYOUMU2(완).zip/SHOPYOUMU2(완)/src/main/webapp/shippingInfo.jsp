<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");
    request.setAttribute("currentPage", "배송 정보");

    String loginUser = (String) session.getAttribute("loginUser");
    if (loginUser == null) {
        loginUser = (String) session.getAttribute("sessionId");
    }

    ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartlist");
    if (cartList == null || cartList.isEmpty()) {
%>
        <script>
            alert("주문할 상품이 없습니다.");
            location.href = "Products.jsp";
        </script>
<%
        return;
    }

    DecimalFormat formatter = new DecimalFormat("#,###");
    int totalOrderPrice = 0;
    for (Product p : cartList) {
        totalOrderPrice += p.getUnitPrice();
    }
%>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>배송 정보 입력 - COFFO</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    
    <!-- 카카오 다음 우편번호 API -->
    <script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>

    <style>
        body {
            background-color: #f8f9fa;
            color: #212529;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 0;
        }

        .checkout-main-area {
            padding: 20px 15px 70px 15px;
        }

        .checkout-card {
            max-width: 820px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e9ecef;
            box-shadow: 0 4px 18px rgba(0,0,0,0.04);
            padding: 35px 40px;
            box-sizing: border-box;
        }

        .checkout-title {
            font-size: 22px;
            font-weight: 800;
            color: #111;
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkout-subtitle {
            font-size: 13.5px;
            color: #6c757d;
            margin-bottom: 24px;
        }

        .order-summary-box {
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px 20px;
            margin-bottom: 26px;
        }
        .order-summary-title {
            font-size: 14px;
            font-weight: 700;
            color: #334155;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
        }
        .order-item-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .order-item-row {
            display: flex;
            justify-content: space-between;
            font-size: 13.5px;
            color: #475569;
            margin-bottom: 4px;
        }

        .field-group {
            margin-bottom: 18px;
        }

        .field-label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            color: #333;
            margin-bottom: 6px;
        }

        .field-label span {
            color: #e53935;
        }

        .custom-input {
            width: 100%;
            height: 46px;
            padding: 0 14px;
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            color: #212529;
            outline: none;
            box-sizing: border-box;
            transition: all 0.2s ease;
        }
        .custom-input:focus {
            background-color: #ffffff;
            border-color: #111111;
        }

        .postcode-flex {
            display: flex;
            gap: 8px;
            margin-bottom: 8px;
        }
        .btn-postcode {
            height: 46px;
            padding: 0 18px;
            background-color: #212934;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
            transition: background-color 0.2s;
        }
        .btn-postcode:hover {
            background-color: #323d4c;
        }

        .btn-action-container {
            display: flex;
            gap: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #edf2f7;
        }
        .btn-submit-order {
            flex: 2;
            height: 50px;
            background-color: #ff0000;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .btn-submit-order:hover {
            background-color: #cc0000;
        }
        .btn-prev-step {
            flex: 1;
            height: 50px;
            background-color: #ffffff;
            color: #495057;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
            line-height: 48px;
            text-decoration: none !important;
            transition: 0.2s;
        }
        .btn-prev-step:hover {
            background-color: #f8f9fa;
            color: #212529;
        }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="checkout-main-area">
        <div class="checkout-card">
            <h2 class="checkout-title"><i class="fa fa-truck text-danger"></i> 배송지 정보 입력</h2>
            <p class="checkout-subtitle">정확한 배송을 위해 수령인 정보와 배송지를 확인해 주세요.</p>

            <!-- 주문 상품 내역 요약 -->
            <div class="order-summary-box">
                <div class="order-summary-title">
                    <span>주문 상품 (<%= cartList.size() %>건)</span>
                    <span class="text-danger font-weight-bold">총 결제금액: <%= formatter.format(totalOrderPrice) %>원</span>
                </div>
                <ul class="order-item-list">
                    <% for (Product p : cartList) { %>
                        <li class="order-item-row">
                            <span>• <%= p.getNameString() %></span>
                            <span class="font-weight-bold"><%= formatter.format(p.getUnitPrice()) %>원</span>
                        </li>
                    <% } %>
                </ul>
            </div>

            <form action="orderConfirmation.jsp" method="post" id="shippingForm" onsubmit="return validateShippingForm()">
                <div class="row">
                    <!-- 수령인 성명 -->
                    <div class="col-md-6 field-group">
                        <label class="field-label">수령인 성명 <span>*</span></label>
                        <input type="text" name="shippingName" id="shippingName" class="custom-input" 
                               value="<%= loginUser != null && !loginUser.equals("guest") ? loginUser : "" %>" 
                               placeholder="받으실 분 성함" required>
                    </div>

                    <!-- 연락처 (실시간 자동 하이픈) -->
                    <div class="col-md-6 field-group">
                        <label class="field-label">연락처 <span>*</span></label>
                        <input type="tel" name="shippingPhone" id="shippingPhone" class="custom-input" 
                               placeholder="010-0000-0000" maxlength="13" oninput="formatPhone(this)" required>
                    </div>
                </div>

                <div class="row">
                    <!-- 희망 배송일자 -->
                    <div class="col-md-6 field-group">
                        <label class="field-label">희망 배송일 <span>*</span></label>
                        <input type="date" name="shippingDate" id="shippingDate" class="custom-input" required>
                    </div>

                    <!-- 배송 국가 -->
                    <div class="col-md-6 field-group">
                        <label class="field-label">국가명</label>
                        <input type="text" name="country" class="custom-input" value="대한민국" readonly style="background-color: #edf2f7; cursor: not-allowed;">
                    </div>
                </div>

                <!-- 배송지 주소 (카카오 우편번호 검색 연동) -->
                <div class="field-group">
                    <label class="field-label">배송지 주소 <span>*</span></label>
                    <div class="postcode-flex">
                        <input type="text" id="postcode" name="zipCode" class="custom-input" style="max-width: 140px;" placeholder="우편번호" readonly required>
                        <button type="button" class="btn-postcode" onclick="execPostcodeSearch()">
                            <i class="fa fa-search mr-1"></i> 주소 검색
                        </button>
                    </div>
                    <input type="text" id="mainAddress" class="custom-input mb-2" placeholder="기본 도로명 주소" readonly required>
                    <input type="text" id="detailAddress" class="custom-input" placeholder="상세 주소를 입력하세요 (동, 호수 등)" oninput="syncShippingAddress()">
                    
                    <input type="hidden" name="shippingAddress" id="shippingAddress">
                </div>

                <!-- 하단 버튼 -->
                <div class="btn-action-container">
                    <a href="cart.jsp" class="btn-prev-step">
                        <i class="fa fa-chevron-left mr-1"></i> 장바구니로
                    </a>
                    <button type="submit" class="btn-submit-order">
                        주문 내용 확인하기 <i class="fa fa-arrow-right ml-1"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <jsp:include page="footer.jsp" />

    <script>
        // 🌟 실시간 전화번호 하이픈 자동 포맷 함수
        function formatPhone(target) {
            var num = target.value.replace(/[^0-9]/g, '');
            var result = '';

            if (num.length < 4) {
                result = num;
            } else if (num.length < 7) {
                result = num.substr(0, 3) + '-' + num.substr(3);
            } else if (num.length < 11) {
                result = num.substr(0, 3) + '-' + num.substr(3, 3) + '-' + num.substr(6);
            } else {
                result = num.substr(0, 3) + '-' + num.substr(3, 4) + '-' + num.substr(7, 4);
            }

            target.value = result;
        }

        window.addEventListener('DOMContentLoaded', function() {
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            var yyyy = tomorrow.getFullYear();
            var mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
            var dd = String(tomorrow.getDate()).padStart(2, '0');
            var minDateStr = yyyy + '-' + mm + '-' + dd;
            
            var dateInput = document.getElementById('shippingDate');
            if (dateInput) {
                dateInput.value = minDateStr;
                dateInput.min = minDateStr;
            }
        });

        function execPostcodeSearch() {
            new daum.Postcode({
                oncomplete: function(data) {
                    var addr = data.userSelectedType === 'R' ? data.roadAddress : data.jibunAddress;
                    document.getElementById('postcode').value = data.zonecode;
                    document.getElementById('mainAddress').value = addr;
                    document.getElementById('detailAddress').focus();
                    syncShippingAddress();
                }
            }).open();
        }

        function syncShippingAddress() {
            var post = document.getElementById('postcode').value;
            var main = document.getElementById('mainAddress').value;
            var detail = document.getElementById('detailAddress').value;
            document.getElementById('shippingAddress').value = (post ? "[" + post + "] " : "") + main + " " + detail;
        }

        function validateShippingForm() {
            syncShippingAddress();
            return true;
        }
    </script>
</body>
</html>