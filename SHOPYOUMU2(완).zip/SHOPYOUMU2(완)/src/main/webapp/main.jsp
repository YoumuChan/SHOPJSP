<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setAttribute("currentPage", "홈");
%>

<jsp:include page="nav.jsp" />

<style>
    .shop_layout_container {
        max-width: 1140px !important;
        margin: 0 auto !important;
        padding: 0 15px !important;
    }

    .slider_wrapper {
        position: relative !important;
        padding: 0 45px !important; 
        margin-bottom: 20px;
    }

    .slider_wrapper .owl-nav {
        display: block !important;
        position: absolute !important;
        width: 100% !important;
        top: 50% !important;
        left: 0 !important;
        transform: translateY(-50%) !important;
        z-index: 9999 !important;
        pointer-events: none;
    }
    .slider_wrapper .owl-nav .owl-prev,
    .slider_wrapper .owl-nav .owl-next {
        width: 40px !important;
        height: 40px !important;
        font-size: 16px !important;
        color: #ffffff !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        position: absolute !important;
        pointer-events: auto;
        cursor: pointer !important;
        margin: 0 !important;
        padding: 0 !important;
        transition: background-color 0.2s ease-in-out !important;
    }
    .slider_wrapper .owl-nav .owl-prev { left: 0px !important; background-color: #ff0000 !important; }
    .slider_wrapper .owl-nav .owl-next { right: 0px !important; background-color: #424242 !important; }
    .slider_wrapper .owl-nav .owl-prev:hover, .slider_wrapper .owl-nav .owl-next:hover { background-color: #111111 !important; }

    .product_card_custom {
        box-shadow: 0 2px 8px rgba(0,0,0,0.04) !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease !important;
    }
    .product_card_custom:hover {
        transform: translateY(-4px) !important;
        box-shadow: 0 6px 16px rgba(0,0,0,0.08) !important;
    }
</style>

    <!-- 메인 배너 구역 -->
    <div class="banner_section layout_padding">
        <div class="container">
            <div id="banner_slider" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="banner_taital_main">
                                    <h1 class="banner_taital">상점</h1>
                                    <p class="banner_text">읽기 좋은 형태의 자연스러운 레이아웃과 세련된 웹디자인 구성을 제공합니다.</p>
                                    <div class="btn_main">
                                        <div class="about_bt active"><a href="Products.jsp">소개</a></div>
                                        <div class="callnow_bt"><a href="tel:02-1234-5678">지금 전화하기</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      
    <!-- About Our Shop 섹션 -->
    <div class="about_section layout_padding">
        <div class="container">
            <div class="about_section_2">
                <div class="row">
                    <div class="col-md-6"> 
                        <div class="about_taital_box">
                            <h1 class="about_taital">저희 매장 소개</h1>
                            <h1 class="about_taital_1">엄선된 최상의 원두 커피 유통</h1>
                            <p class="about_text">본 예시 문구는 디자인 레이아웃이 실제 운영 중인 사이트처럼 자연스럽게 보이도록 배치된 결과물입니다.</p>
                            <div class="readmore_btn"><a href="Products.jsp">상세보기</a></div>
                        </div>
                    </div>
                    <div class="col-md-6"> 
                        <div class="image_iman"><img src="images/about-img.png" class="about_img" alt="매장 소개"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 상품 슬라이더 섹션 -->
    <div class="coffee_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="coffee_taital">OUR COFFEE OFFER</h1>
                </div>
            </div>
        </div>
      
        <div class="shop_layout_container">
            <div class="slider_wrapper">
                <div id="new-carousel" class="owl-carousel owl-theme">
<%
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    DecimalFormat formatter = new DecimalFormat("#,###");

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        String sql = "SELECT p_id, p_name, p_unitPrice, p_description, p_fileName FROM product ORDER BY p_id ASC";
        pstmt = conn.prepareStatement(sql);
        rs = pstmt.executeQuery();

        while (rs.next()) {
            String pId = rs.getString("p_id");
            String pName = rs.getString("p_name");
            int price = rs.getInt("p_unitPrice");
            String desc = rs.getString("p_description");
            String filename = rs.getString("p_fileName");
            
            String finalSrc = "images/coffee1.png";
            if (filename != null && !filename.trim().isEmpty()) {
                finalSrc = "images/" + filename.trim();
            }
%>
                    <div class="item">
                        <div class="product_card_custom" style="border: 1px solid #e9ecef !important; border-radius: 6px !important; background: #ffffff !important; overflow: hidden !important; display: flex !important; flex-direction: column !important; height: 100% !important;">
                            <div class="coffee_img" style="height: 200px !important; display: flex !important; align-items: center !important; justify-content: center !important; background: #fafafa !important;">
                                <img src="<%= finalSrc %>" alt="<%= pName %>" style="max-height: 90% !important; width: auto !important; object-fit: contain !important;" onerror="this.src='images/coffee1.png';">
                            </div>
                            <div class="coffee_box" style="padding: 18px 12px !important; background: #ffffff !important; text-align: center !important; flex-grow: 1 !important; display: flex !important; flex-direction: column !important; justify-content: space-between !important;">
                                <h3 class="types_text" style="font-size: 16px !important; font-weight: bold !important; color: #222222 !important; white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important; margin-bottom: 6px !important;"><%= pName %></h3>
                                <p style="font-size: 13px !important; color: #666666 !important; line-height: 1.4 !important; height: 36px !important; overflow: hidden; margin-bottom: 12px !important; display: -webkit-box !important; -webkit-line-clamp: 2; -webkit-box-orient: vertical !important; word-break: break-all !important;"><%= desc != null ? desc : "" %></p>
                                <p class="looking_text" style="font-size: 16px !important; font-weight: bold !important; color: #ff0000 !important; margin-bottom: 12px !important;"><%= formatter.format(price) %>원</p>
                                <div style="text-align: center !important; margin-top: auto !important;">
                                    <a href="product.jsp?id=<%= pId %>" style="display: inline-block !important; width: 100% !important; padding: 8px 0 !important; background-color: #252525 !important; color: #ffffff !important; font-size: 13px !important; font-weight: bold !important; border-radius: 4px !important; text-decoration: none; transition: background-color 0.2s !important;">상세정보</a>
                                </div>
                            </div>
                        </div>
                    </div>
<%
        }
    } catch (Exception e) {
        out.println("<p style='color:red;'>상품 불러오기 오류: " + e.getMessage() + "</p>");
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>
                </div>
            </div>
        </div>
    </div>

    <!-- Blog 섹션 -->
    <div class="blog_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="about_taital">Our 게시판</h1>
                </div>
            </div>
            <div class="blog_section_2">
                <div class="row">
                    <div class="col-md-6">
                        <div class="blog_box">
                            <div class="blog_img"><img src="images/blog-img1.png" alt="blog1"></div>
                            <h4 class="date_text">2026.09</h4>
                            <h4 class="prep_text">신선한 원두 보관 가이드</h4>
                            <p class="lorem_text">산패를 방지하고 아로마를 길게 유지하는 실온 밀폐 보관 노하우를 확인하세요.</p>
                        </div>
                        <div class="read_btn"><a href="list.jsp">더보기</a></div>
                    </div>
                    <div class="col-md-6">
                        <div class="blog_box">
                            <div class="blog_img"><img src="images/blog-img2.png" alt="blog2"></div>
                            <h4 class="date_text">2026.09</h4>
                            <h4 class="prep_text">핸드드립 분쇄도 가이드</h4>
                            <p class="lorem_text">드리퍼 종류와 물 온도에 맞춘 이상적인 분쇄 굵기 레시피를 소개합니다.</p>
                        </div>
                        <div class="read_btn"><a href="list.jsp">더보기</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <jsp:include page="footer.jsp" />

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            var newOwl = $('#new-carousel');
            if (newOwl.length > 0) {
                newOwl.owlCarousel({
                    loop: true,
                    margin: 30,
                    nav: true,
                    autoplay: true,
                    autoplayTimeout: 3000,
                    autoplayHoverPause: true,
                    navText: ["<i class='fa fa-arrow-left'></i>", "<i class='fa fa-arrow-right'></i>"],
                    responsive: {
                        0: { items: 1 },
                        576: { items: 2 },
                        768: { items: 3 },
                        992: { items: 4 }
                    }
                });
            }
        });
    </script>
</body>
</html>