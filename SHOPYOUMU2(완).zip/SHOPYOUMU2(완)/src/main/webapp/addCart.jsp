<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="dao.ProductRapository" %>

<%
    request.setCharacterEncoding("UTF-8");

    String id = request.getParameter("id");
    String direct = request.getParameter("direct");

    if (id == null || id.trim().isEmpty()) {
        response.sendRedirect("Products.jsp");
        return;
    }

    // 1. 세션 장바구니 리스트 가져오기
    ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartlist");
    if (cartList == null) {
        cartList = new ArrayList<Product>();
        session.setAttribute("cartlist", cartList);
    }

    // 2. 바로 주문(direct=true)일 경우 기존 장바구니 비우기
    if ("true".equals(direct)) {
        cartList.clear();
    }

    // 3. DAO를 통해 정상 등록된 Product 객체 가져오기
    ProductRapository dao = ProductRapository.getInstance();
    Product product = dao.getProductById(id.trim());

    if (product == null) {
        // 혹시 DAO에 없으면 DB에서 직접 읽어오는 대신 이전 화면으로 안내
%>
        <script>
            alert("해당 상품 정보를 찾을 수 없습니다.");
            location.href = "Products.jsp";
        </script>
<%
        return;
    }

    // 4. 장바구니 중복 여부 확인 후 추가
    boolean exists = false;
    for (Product p : cartList) {
        if (p != null && id.trim().equals(p.getProductIDString())) {
            exists = true;
            break;
        }
    }

    if (!exists) {
        cartList.add(product);
    }

    // 5. 이동 분기: 바로 주문이면 shippingInfo.jsp, 일반 담기면 cart.jsp
    if ("true".equals(direct)) {
        response.sendRedirect("shippingInfo.jsp");
    } else {
        response.sendRedirect("cart.jsp");
    }
%>