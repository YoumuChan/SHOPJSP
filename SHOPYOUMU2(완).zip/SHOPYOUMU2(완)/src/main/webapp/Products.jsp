<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");
    request.setAttribute("currentPage", "상점");

    String keyword = request.getParameter("keyword");
    if (keyword != null) {
        keyword = keyword.trim();
    } else {
        keyword = "";
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>상품 목록 - COFFO</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <style>
        .shop-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 15px 60px 15px;
        }
        .shop-top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .section-bar-title {
            font-size: 22px;
            font-weight: 800;
            color: #111;
            margin: 0;
            border-left: 4px solid #ff0000;
            padding-left: 12px;
            line-height: 1.2;
        }
        .search-form-wrap {
            display: flex;
            align-items: center;
        }
        .search-input-custom {
            height: 42px;
            padding: 0 16px;
            border: 1px solid #ccc;
            border-right: none;
            border-radius: 4px 0 0 4px;
            font-size: 14px;
            width: 240px;
            outline: none;
        }
        .search-input-custom:focus {
            border-color: #ff0000;
        }
        .search-btn-custom {
            height: 42px;
            padding: 0 20px;
            background-color: #ff0000;
            color: #ffffff;
            border: none;
            border-radius: 0 4px 4px 0;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .search-btn-custom:hover {
            background-color: #cc0000;
        }
        .btn-reset-search {
            height: 42px;
            line-height: 40px;
            padding: 0 14px;
            margin-left: 8px;
            background-color: #f1f1f1;
            color: #555;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
            text-decoration: none !important;
        }
        .btn-reset-search:hover {
            background-color: #e2e2e2;
            color: #111;
        }

        .shop-card {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            background: #ffffff;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: 100%;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .shop-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.08);
        }
        .shop-card-img {
            height: 200px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fafafa;
            padding: 10px;
        }
        .shop-card-img img {
            max-height: 90%;
            max-width: 90%;
            object-fit: contain;
        }
        .shop-card-body {
            padding: 18px 14px;
            text-align: center;
            display: flex;
            flex-direction: column;
            flex-grow: 1;
            justify-content: space-between;
        }
        .shop-card-title {
            font-size: 16px;
            font-weight: 700;
            color: #222;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .shop-card-desc {
            font-size: 12px;
            color: #777;
            line-height: 1.4;
            height: 34px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            margin-bottom: 10px;
        }
        .shop-card-price {
            font-size: 16px;
            font-weight: 700;
            color: #ff0000;
            margin-bottom: 12px;
        }
        .btn-card-detail {
            display: block;
            width: 100%;
            padding: 8px 0;
            background-color: #252525;
            color: #ffffff !important;
            font-size: 13px;
            font-weight: 700;
            border-radius: 4px;
            text-decoration: none !important;
            transition: background 0.2s;
        }
        .btn-card-detail:hover {
            background-color: #ff0000;
        }

        .slider-wrapper-box {
            position: relative;
            padding: 0 45px;
            margin-bottom: 45px;
        }
        .slider-wrapper-box .owl-nav {
            position: absolute;
            width: 100%;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
            pointer-events: none;
            display: block !important;
        }
        .slider-wrapper-box .owl-nav button.owl-prev,
        .slider-wrapper-box .owl-nav button.owl-next {
            width: 38px;
            height: 38px;
            position: absolute;
            pointer-events: auto;
            border-radius: 0;
            color: #fff !important;
            display: flex !important;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .slider-wrapper-box .owl-nav button.owl-prev { left: 0; background: #ff0000 !important; }
        .slider-wrapper-box .owl-nav button.owl-next { right: 0; background: #424242 !important; }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="shop-container">
        <div class="shop-top-header">
            <div>
                <h2 class="section-bar-title">COFFO STORE</h2>
                <% if (!keyword.isEmpty()) { %>
                    <p class="text-muted font-13 mb-0 mt-1">
                        '<strong><%= keyword %></strong>' 검색 결과입니다.
                    </p>
                <% } %>
            </div>

            <form action="Products.jsp" method="get" class="search-form-wrap">
                <input type="text" name="keyword" value="<%= keyword %>" class="search-input-custom" placeholder="상품명, 카테고리 검색">
                <button type="submit" class="search-btn-custom"><i class="fa fa-search mr-1"></i> 검색</button>
                <% if (!keyword.isEmpty()) { %>
                    <a href="Products.jsp" class="btn-reset-search">초기화</a>
                <% } %>
            </form>
        </div>

<%
    Connection conn = null;
    PreparedStatement pstmtNew = null;
    PreparedStatement pstmtAll = null;
    ResultSet rsNew = null;
    ResultSet rsAll = null;
    DecimalFormat formatter = new DecimalFormat("#,###");

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        if (keyword.isEmpty()) {
            String sqlNew = "SELECT * FROM (SELECT * FROM product ORDER BY p_id DESC) WHERE ROWNUM <= 6";
            pstmtNew = conn.prepareStatement(sqlNew);
            rsNew = pstmtNew.executeQuery();
%>
        <h3 class="section-bar-title mb-3">NEW ARRIVALS</h3>
        <div class="slider-wrapper-box">
            <div id="shop-carousel" class="owl-carousel owl-theme">
<%
            while (rsNew.next()) {
                String pId = rsNew.getString("p_id");
                String pName = rsNew.getString("p_name");
                int price = rsNew.getInt("p_unitPrice");
                String desc = rsNew.getString("p_description");
                String img = rsNew.getString("p_fileName");
                String imgSrc = (img != null && !img.trim().isEmpty()) ? "images/" + img.trim() : "images/coffee1.png";
%>
                <div class="item">
                    <div class="shop-card">
                        <div class="shop-card-img">
                            <img src="<%= imgSrc %>" alt="<%= pName %>" onerror="this.src='images/coffee1.png';">
                        </div>
                        <div class="shop-card-body">
                            <div class="shop-card-title"><%= pName %></div>
                            <div class="shop-card-desc"><%= desc != null ? desc : "" %></div>
                            <div class="shop-card-price"><%= formatter.format(price) %>원</div>
                            <!-- ShowProductData.jsp로 연결 -->
                            <a href="ShowProductData.jsp?id=<%= pId %>" class="btn-card-detail">상세정보</a>
                        </div>
                    </div>
                </div>
<%
            }
%>
            </div>
        </div>
<%
        }

        String sqlAll = "SELECT * FROM product";
        if (!keyword.isEmpty()) {
            sqlAll += " WHERE (p_name LIKE ? OR p_category LIKE ? OR p_manufacturer LIKE ?)";
        }
        sqlAll += " ORDER BY p_id ASC";

        pstmtAll = conn.prepareStatement(sqlAll);
        if (!keyword.isEmpty()) {
            pstmtAll.setString(1, "%" + keyword + "%");
            pstmtAll.setString(2, "%" + keyword + "%");
            pstmtAll.setString(3, "%" + keyword + "%");
        }
        rsAll = pstmtAll.executeQuery();
%>
        <h3 class="section-bar-title mb-4">
            <%= keyword.isEmpty() ? "ALL PRODUCTS" : "SEARCH RESULTS" %>
        </h3>

        <div class="row">
<%
        boolean hasData = false;
        while (rsAll.next()) {
            hasData = true;
            String pId = rsAll.getString("p_id");
            String pName = rsAll.getString("p_name");
            int price = rsAll.getInt("p_unitPrice");
            String desc = rsAll.getString("p_description");
            String img = rsAll.getString("p_fileName");
            String imgSrc = (img != null && !img.trim().isEmpty()) ? "images/" + img.trim() : "images/coffee1.png";
%>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                <div class="shop-card">
                    <div class="shop-card-img">
                        <img src="<%= imgSrc %>" alt="<%= pName %>" onerror="this.src='images/coffee1.png';">
                    </div>
                    <div class="shop-card-body">
                        <div class="shop-card-title"><%= pName %></div>
                        <div class="shop-card-desc"><%= desc != null ? desc : "" %></div>
                        <div class="shop-card-price"><%= formatter.format(price) %>원</div>
                        <!-- ShowProductData.jsp로 연결 -->
                        <a href="ShowProductData.jsp?id=<%= pId %>" class="btn-card-detail">상세정보</a>
                    </div>
                </div>
            </div>
<%
        }

        if (!hasData) {
%>
            <div class="col-12 text-center py-5">
                <p class="text-muted font-16 mb-3">검색된 상품이 없습니다.</p>
                <a href="Products.jsp" class="btn btn-sm btn-dark">전체 상품 보기</a>
            </div>
<%
        }
%>
        </div>
<%
    } catch (Exception e) {
        out.println("<div class='alert alert-danger'>데이터 조회 오류: " + e.getMessage() + "</div>");
    } finally {
        if (rsNew != null) try { rsNew.close(); } catch (Exception e) {}
        if (rsAll != null) try { rsAll.close(); } catch (Exception e) {}
        if (pstmtNew != null) try { pstmtNew.close(); } catch (Exception e) {}
        if (pstmtAll != null) try { pstmtAll.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>
    </div>

    <jsp:include page="footer.jsp" />

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script>
        $(document).ready(function(){
            var owl = $('#shop-carousel');
            if (owl.length > 0) {
                owl.owlCarousel({
                    loop: true,
                    margin: 20,
                    nav: true,
                    dots: false,
                    autoplay: true,
                    autoplayTimeout: 3500,
                    navText: ["<i class='fa fa-arrow-left'></i>", "<i class='fa fa-arrow-right'></i>"],
                    responsive: {
                        0: { items: 1 },
                        576: { items: 2 },
                        768: { items: 3 },
                        992: { items: 4 }
                    }
                });
            }
        });
    </script>
</body>
</html>