<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %>

<%
    request.setCharacterEncoding("UTF-8");

    String id = request.getParameter("id");
    String password = request.getParameter("password");
    String name = request.getParameter("name");
    String gender = request.getParameter("gender");
    String birth = request.getParameter("birth");
    String mail = request.getParameter("mail");
    String phone = request.getParameter("phone");
    String address = request.getParameter("address");

    if (id == null || id.trim().isEmpty() || password == null || password.trim().isEmpty() || name == null || name.trim().isEmpty()) {
%>
        <script>
            alert("아이디, 비밀번호, 성명은 필수 입력 항목입니다.");
            history.back();
        </script>
<%
        return;
    }

    id = id.trim();
    password = password.trim();
    name = name.trim();

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String regist_day = sdf.format(new Date());

    Connection conn = null;
    PreparedStatement pstmtCheck = null;
    PreparedStatement pstmtNum = null;
    PreparedStatement pstmtInsert = null;
    ResultSet rsCheck = null;
    ResultSet rsNum = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        conn.setAutoCommit(false);

        // 1. 아이디 중복 체크
        String sqlCheck = "SELECT COUNT(*) FROM member WHERE UPPER(TRIM(id)) = UPPER(?)";
        pstmtCheck = conn.prepareStatement(sqlCheck);
        pstmtCheck.setString(1, id);
        rsCheck = pstmtCheck.executeQuery();

        if (rsCheck.next() && rsCheck.getInt(1) > 0) {
%>
            <script>
                alert("이미 등록된 아이디입니다. 다른 아이디를 입력해 주세요.");
                history.back();
            </script>
<%
            return;
        }

        // 2. MEM_NUM 자동 채번 (MAX + 1)
        int nextMemNum = 1;
        String sqlNum = "SELECT NVL(MAX(mem_num), 0) + 1 FROM member";
        pstmtNum = conn.prepareStatement(sqlNum);
        rsNum = pstmtNum.executeQuery();
        if (rsNum.next()) {
            nextMemNum = rsNum.getInt(1);
        }

        // 3. member 테이블 12개 컬럼 정확 매핑
        String sqlInsert = "INSERT INTO member "
                         + "(mem_num, id, password, name, gender, birth, mail, phone, address, regist_day, logtime, updatetime) "
                         + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)";
        
        pstmtInsert = conn.prepareStatement(sqlInsert);
        pstmtInsert.setInt(1, nextMemNum);
        pstmtInsert.setString(2, id);
        pstmtInsert.setString(3, password);
        pstmtInsert.setString(4, name);
        pstmtInsert.setString(5, (gender != null && !gender.trim().isEmpty()) ? gender : "남성");
        pstmtInsert.setString(6, (birth != null) ? birth : "");
        pstmtInsert.setString(7, (mail != null) ? mail : "");
        pstmtInsert.setString(8, (phone != null) ? phone : "");
        pstmtInsert.setString(9, (address != null) ? address : "");
        pstmtInsert.setString(10, regist_day);

        int result = pstmtInsert.executeUpdate();

        if (result > 0) {
            conn.commit();
%>
            <script>
                alert("<%= name %>님, 회원가입이 성공적으로 완료되었습니다!\n로그인 화면으로 이동합니다.");
                location.href = "login.jsp";
            </script>
<%
        } else {
            conn.rollback();
%>
            <script>
                alert("회원가입 처리에 실패했습니다.");
                history.back();
            </script>
<%
        }
    } catch (Exception e) {
        if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
        e.printStackTrace();
        String errMsg = (e.getMessage() != null) ? e.getMessage().replace("\"", "'").replace("\r", " ").replace("\n", " ") : "알 수 없는 오류";
%>
        <script>
            alert("회원가입 실패:\n<%= errMsg %>");
            history.back();
        </script>
<%
    } finally {
        if (rsCheck != null) try { rsCheck.close(); } catch (Exception e) {}
        if (pstmtCheck != null) try { pstmtCheck.close(); } catch (Exception e) {}
        if (rsNum != null) try { rsNum.close(); } catch (Exception e) {}
        if (pstmtNum != null) try { pstmtNum.close(); } catch (Exception e) {}
        if (pstmtInsert != null) try { pstmtInsert.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>