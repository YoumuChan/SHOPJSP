<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="dto.Product" %>
<%@ page import="java.text.DecimalFormat" %>

<%
    request.setCharacterEncoding("UTF-8");

    ArrayList<Product> cartList = (ArrayList<Product>) session.getAttribute("cartlist");
    String loginUser = (String) session.getAttribute("loginUser");
    if (loginUser == null) loginUser = (String) session.getAttribute("sessionId");
    if (loginUser == null) loginUser = "guest";

    if (cartList == null || cartList.isEmpty()) {
%>
        <script>
            alert("장바구니가 비어 있습니다.");
            location.href = "Products.jsp";
        </script>
<%
        return;
    }

    String orderId = "ORD" + System.currentTimeMillis();
    String shippingName = request.getParameter("shippingName");
    String shippingPhone = request.getParameter("shippingPhone");
    String shippingAddress = request.getParameter("shippingAddress");

    if (shippingName == null || shippingName.trim().isEmpty()) shippingName = loginUser;
    if (shippingPhone == null) shippingPhone = "-";
    if (shippingAddress == null) shippingAddress = "-";

    Connection conn = null;
    PreparedStatement pstmtCheck = null;
    PreparedStatement pstmtStock = null;
    PreparedStatement pstmtOrder = null;
    PreparedStatement pstmtDetail = null;
    ResultSet rsCheck = null;

    int totalPrice = 0;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        conn.setAutoCommit(false);

        // 1. 총 결제 금액 계산
        for (Product p : cartList) {
            totalPrice += p.getUnitPrice();
        }

        // 2. 재고 확인 및 1개씩 차감 (p_unitsInStock = p_unitsInStock - 1)
        String checkSql = "SELECT p_unitsInStock, p_name FROM product WHERE p_id = ? FOR UPDATE";
        String stockSql = "UPDATE product SET p_unitsInStock = p_unitsInStock - 1 WHERE p_id = ?";
        
        pstmtCheck = conn.prepareStatement(checkSql);
        pstmtStock = conn.prepareStatement(stockSql);

        for (Product p : cartList) {
            String pId = p.getProductIDString();

            pstmtCheck.setString(1, pId);
            rsCheck = pstmtCheck.executeQuery();

            if (rsCheck.next()) {
                int currentStock = rsCheck.getInt("p_unitsInStock");
                String prodName = rsCheck.getString("p_name");

                if (currentStock < 1) {
                    conn.rollback();
%>
                    <script>
                        alert("상품 [<%= prodName %>]의 재고가 모두 소진되었습니다.");
                        history.back();
                    </script>
<%
                    return;
                }

                pstmtStock.setString(1, pId);
                pstmtStock.executeUpdate();
            }
            if (rsCheck != null) rsCheck.close();
        }

        // 3. 주문 마스터 (orders) INSERT
        String orderSql = "INSERT INTO orders (order_id, id, order_date, total_price, shipping_name, shipping_phone, shipping_address, order_status) "
                        + "VALUES (?, ?, SYSDATE, ?, ?, ?, ?, '결제완료')";
        pstmtOrder = conn.prepareStatement(orderSql);
        pstmtOrder.setString(1, orderId);
        pstmtOrder.setString(2, loginUser);
        pstmtOrder.setInt(3, totalPrice);
        pstmtOrder.setString(4, shippingName);
        pstmtOrder.setString(5, shippingPhone);
        pstmtOrder.setString(6, shippingAddress);
        pstmtOrder.executeUpdate();

        // 4. 주문 상세 (order_detail) INSERT
        String detailSql = "INSERT INTO order_detail (order_id, p_id, p_name, p_unitPrice, quantity, sub_total) "
                         + "VALUES (?, ?, ?, ?, 1, ?)";
        pstmtDetail = conn.prepareStatement(detailSql);

        for (Product p : cartList) {
            pstmtDetail.setString(1, orderId);
            pstmtDetail.setString(2, p.getProductIDString());
            pstmtDetail.setString(3, p.getNameString());
            pstmtDetail.setInt(4, p.getUnitPrice());
            pstmtDetail.setInt(5, p.getUnitPrice());
            pstmtDetail.executeUpdate();
        }

        conn.commit();
        session.removeAttribute("cartlist");

    } catch (Exception e) {
        if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
        e.printStackTrace();
%>
        <script>
            alert("주문 결제 중 오류가 발생했습니다.\n<%= e.getMessage() %>");
            history.back();
        </script>
<%
        return;
    } finally {
        if (rsCheck != null) try { rsCheck.close(); } catch (Exception e) {}
        if (pstmtCheck != null) try { pstmtCheck.close(); } catch (Exception e) {}
        if (pstmtStock != null) try { pstmtStock.close(); } catch (Exception e) {}
        if (pstmtDetail != null) try { pstmtDetail.close(); } catch (Exception e) {}
        if (pstmtOrder != null) try { pstmtOrder.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>주문 완료 - COFFO</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
</head>
<body style="background-color: #f8f9fa;">

    <jsp:include page="nav.jsp" />

    <div class="container text-center" style="padding: 80px 20px;">
        <div class="card p-5 mx-auto" style="max-width: 600px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid #e9ecef;">
            <div style="font-size: 50px; color: #28a745; margin-bottom: 20px;">
                <i class="fa fa-check-circle"></i>
            </div>
            <h2 class="font-weight-bold mb-3">주문이 성공적으로 완료되었습니다!</h2>
            <p class="text-muted mb-4" style="line-height: 1.8;">
                주문번호: <strong class="text-dark"><%= orderId %></strong><br>
                총 결제금액: <strong class="text-danger"><%= String.format("%,d", totalPrice) %>원</strong><br>
                재고 수량이 정상적으로 차감되었습니다.
            </p>
            <div>
                <a href="Products.jsp" class="btn btn-dark font-weight-bold px-4 py-2">쇼핑 계속하기</a>
                <a href="main.jsp" class="btn btn-outline-secondary font-weight-bold px-4 py-2 ml-2">홈으로</a>
            </div>
        </div>
    </div>

    <jsp:include page="footer.jsp" />

</body>
</html>