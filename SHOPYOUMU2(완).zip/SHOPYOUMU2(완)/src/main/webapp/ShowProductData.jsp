<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");
    String id = request.getParameter("id");
    if (id == null || id.trim().isEmpty()) {
%>
        <script>
            alert("잘못된 상품 접근입니다.");
            location.href = "Products.jsp";
        </script>
<%
        return;
    }

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    DecimalFormat formatter = new DecimalFormat("#,###");

    String pName = "";
    int pUnitPrice = 0;
    String pDescription = "";
    String pCategory = "";
    String pManufacturer = "";
    int pUnitsInStock = 0;
    String pCondition = "";
    String pFileName = "coffee1.png";

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM product WHERE p_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id.trim());
        rs = pstmt.executeQuery();

        if (rs.next()) {
            pName = rs.getString("p_name");
            pUnitPrice = rs.getInt("p_unitPrice");
            pDescription = rs.getString("p_description");
            pCategory = rs.getString("p_category");
            pManufacturer = rs.getString("p_manufacturer");
            pUnitsInStock = rs.getInt("p_unitsInStock");
            pCondition = rs.getString("p_condition");
            String dbImg = rs.getString("p_fileName");
            if (dbImg != null && !dbImg.trim().isEmpty()) {
                pFileName = dbImg.trim();
            }
        } else {
%>
            <script>
                alert("존재하지 않는 상품입니다.");
                location.href = "Products.jsp";
            </script>
<%
            return;
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><%= pName %> - COFFO</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    
    <style>
        body {
            background-color: #fcfbf9;
            color: #2b2b2b;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        }
        
        .detail-wrapper {
            max-width: 1080px;
            margin: 30px auto 70px auto;
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #eae6df;
            box-shadow: 0 6px 24px rgba(0, 0, 0, 0.04);
            padding: 45px;
        }

        .detail-img-container {
            width: 100%;
            height: 420px;
            background: #f8f6f2;
            border-radius: 10px;
            border: 1px solid #ebe7df;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        .detail-img-container img {
            max-width: 88%;
            max-height: 88%;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        .detail-img-container:hover img {
            transform: scale(1.04);
        }

        .badge-category {
            background-color: #e53e3e;
            color: #ffffff;
            font-size: 12px;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 4px;
            letter-spacing: 0.5px;
            display: inline-block;
            margin-bottom: 12px;
        }
        .item-main-title {
            font-size: 28px;
            font-weight: 800;
            color: #1a1a1a;
            line-height: 1.3;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
        }
        .item-price-box {
            display: flex;
            align-items: baseline;
            gap: 10px;
            padding-bottom: 18px;
            margin-bottom: 20px;
            border-bottom: 2px solid #2b2b2b;
        }
        .item-main-price {
            font-size: 30px;
            font-weight: 800;
            color: #e53e3e;
        }

        .meta-list {
            list-style: none;
            padding: 0;
            margin: 0 0 20px 0;
        }
        .meta-item {
            display: flex;
            font-size: 14px;
            padding: 7px 0;
            border-bottom: 1px dashed #eee;
        }
        .meta-label {
            width: 105px;
            font-weight: 600;
            color: #718096;
            flex-shrink: 0;
        }
        .meta-val {
            color: #2d3748;
            font-weight: 500;
        }

        .spec-desc-box {
            background-color: #fbfbfa;
            border: 1px solid #ede8e1;
            border-radius: 6px;
            padding: 16px 18px;
            font-size: 13.5px;
            color: #4a5568;
            line-height: 1.7;
            margin-bottom: 25px;
            word-break: break-all;
        }

        .qty-control-wrap {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            gap: 15px;
        }
        .qty-box {
            display: flex;
            align-items: center;
            border: 1px solid #cbd5e0;
            border-radius: 6px;
            overflow: hidden;
            background: #fff;
            width: 125px;
        }
        .qty-btn {
            width: 38px;
            height: 38px;
            background: #f7fafc;
            border: none;
            font-size: 15px;
            font-weight: bold;
            color: #4a5568;
            cursor: pointer;
            transition: background 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .qty-btn:hover {
            background: #edf2f7;
            color: #000;
        }
        .qty-input {
            width: 49px;
            height: 38px;
            border: none;
            border-left: 1px solid #cbd5e0;
            border-right: 1px solid #cbd5e0;
            text-align: center;
            font-size: 15px;
            font-weight: 700;
            color: #2d3748;
            outline: none;
        }

        .action-btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .btn-order-direct {
            flex: 1.3;
            min-width: 150px;
            height: 48px;
            background-color: #e53e3e;
            color: #ffffff !important;
            border: 1px solid #e53e3e;
            font-size: 15px;
            font-weight: 700;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
            text-decoration: none !important;
        }
        .btn-order-direct:hover {
            background-color: #c53030;
            border-color: #c53030;
        }

        .btn-cart-put {
            flex: 1.2;
            min-width: 150px;
            height: 48px;
            background-color: #2d3748;
            color: #ffffff !important;
            border: 1px solid #2d3748;
            font-size: 15px;
            font-weight: 700;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-cart-put:hover {
            background-color: #1a202c;
            border-color: #1a202c;
        }

        .btn-to-shop {
            width: 90px;
            height: 48px;
            background-color: #ffffff;
            color: #4a5568 !important;
            border: 1px solid #cbd5e0;
            font-size: 14px;
            font-weight: 600;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none !important;
            transition: 0.2s;
        }
        .btn-to-shop:hover {
            background-color: #f7fafc;
            color: #1a202c !important;
            border-color: #a0aec0;
        }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="container">
        <div class="detail-wrapper">
            <div class="row">
                <!-- 1. 좌측 상품 이미지 -->
                <div class="col-lg-5 col-md-6 mb-4 mb-md-0">
                    <div class="detail-img-container">
                        <img src="<%= request.getContextPath() %>/images/<%= pFileName %>" 
                             alt="<%= pName %>" 
                             onerror="this.src='<%= request.getContextPath() %>/images/coffee1.png';">
                    </div>
                </div>

                <!-- 2. 우측 상세 정보 & 주문 폼 -->
                <div class="col-lg-7 col-md-6 pl-lg-4">
                    <span class="badge-category"><%= pCategory != null ? pCategory : "스페셜티" %></span>
                    <h1 class="item-main-title"><%= pName %></h1>

                    <div class="item-price-box">
                        <span class="item-main-price"><%= formatter.format(pUnitPrice) %>원</span>
                        <span class="text-muted font-14">소비자가 (VAT 포함)</span>
                    </div>

                    <ul class="meta-list">
                        <li class="meta-item">
                            <span class="meta-label"><i class="fa fa-barcode mr-1"></i> 상품코드</span>
                            <span class="meta-val"><%= id %></span>
                        </li>
                        <li class="meta-item">
                            <span class="meta-label"><i class="fa fa-building-o mr-1"></i> 제조/로스터리</span>
                            <span class="meta-val"><%= pManufacturer != null ? pManufacturer : "COFFO Roastery" %></span>
                        </li>
                        <li class="meta-item">
                            <span class="meta-label"><i class="fa fa-cubes mr-1"></i> 재고현황</span>
                            <span class="meta-val text-primary font-weight-bold"><%= pUnitsInStock %>개 보유</span>
                        </li>
                        <li class="meta-item">
                            <span class="meta-label"><i class="fa fa-check-circle-o mr-1"></i> 상품상태</span>
                            <span class="meta-val"><%= pCondition != null ? pCondition : "New (신제품)" %></span>
                        </li>
                        <li class="meta-item">
                            <span class="meta-label"><i class="fa fa-truck mr-1"></i> 배송안내</span>
                            <span class="meta-val text-success">평일 14시 이전 결제 완료 시 당일 출고</span>
                        </li>
                    </ul>

                    <div class="spec-desc-box">
                        <strong>[상세 스펙 &amp; 로스팅 노트]</strong><br>
                        <%= (pDescription != null && !pDescription.trim().isEmpty()) ? pDescription.replace("\r\n", "<br>") : "신선하게 로스팅된 최상급 상품입니다." %>
                    </div>

                    <form id="purchaseForm" method="post">
                        <div class="qty-control-wrap">
                            <span style="font-weight: 700; font-size: 14px; color: #2d3748;">주문 수량</span>
                            <div class="qty-box">
                                <button type="button" class="qty-btn" onclick="adjustQuantity(-1)">-</button>
                                <input type="text" name="quantity" id="orderQty" class="qty-input" value="1" readonly>
                                <button type="button" class="qty-btn" onclick="adjustQuantity(1)">+</button>
                            </div>
                            <span class="text-muted font-13" id="totalPriceCalc">
                                총 금액: <strong class="text-dark"><%= formatter.format(pUnitPrice) %></strong>원
                            </span>
                        </div>

                        <div class="action-btn-group">
                            <!-- 바로 주문 버튼 -->
                            <button type="button" class="btn-order-direct" onclick="submitDirectOrder()">
                                <i class="fa fa-bolt"></i> 바로 주문하기
                            </button>

                            <!-- 장바구니 담기 버튼 -->
                            <button type="button" class="btn-cart-put" onclick="submitAddCart()">
                                <i class="fa fa-shopping-cart"></i> 장바구니 담기
                            </button>

                            <!-- 목록 버튼 -->
                            <a href="Products.jsp" class="btn-to-shop">
                                <i class="fa fa-list mr-1"></i> 목록
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <jsp:include page="footer.jsp" />

    <script>
        var unitPrice = <%= pUnitPrice %>;
        var maxStock = <%= pUnitsInStock %>;

        function adjustQuantity(delta) {
            var qtyInput = document.getElementById("orderQty");
            var currentVal = parseInt(qtyInput.value) || 1;
            var newVal = currentVal + delta;

            if (newVal < 1) newVal = 1;
            if (maxStock > 0 && newVal > maxStock) {
                alert("재고 수량(" + maxStock + "개)을 초과하여 주문할 수 없습니다.");
                newVal = maxStock;
            }

            qtyInput.value = newVal;

            var total = newVal * unitPrice;
            document.getElementById("totalPriceCalc").innerHTML = 
                '총 금액: <strong class="text-dark">' + total.toLocaleString() + '</strong>원';
        }

        function submitAddCart() {
            var form = document.getElementById("purchaseForm");
            form.action = "addCart.jsp?id=<%= id %>";
            form.submit();
        }

        function submitDirectOrder() {
            var form = document.getElementById("purchaseForm");
            form.action = "addCart.jsp?id=<%= id %>&direct=true";
            form.submit();
        }
    </script>
</body>
</html>