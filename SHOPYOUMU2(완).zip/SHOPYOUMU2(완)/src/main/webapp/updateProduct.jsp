<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    request.setCharacterEncoding("UTF-8");

    // 관리자 접근 제한
    String sessionId = (String) session.getAttribute("sessionId");
    String loginUser = (String) session.getAttribute("loginUser");
    if (!"admin".equals(sessionId) && !"admin".equals(loginUser)) {
%>
        <script>
            alert("상품 수정은 관리자(admin)만 가능합니다.");
            location.href = "login.jsp";
        </script>
<%
        return;
    }

    String productId = request.getParameter("id");
    if (productId == null || productId.trim().isEmpty()) {
%>
        <script>
            alert("잘못된 상품 접근입니다.");
            history.back();
        </script>
<%
        return;
    }

    request.setAttribute("currentPage", "수정");

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    String pName = "";
    int pUnitPrice = 0;
    String pDescription = "";
    String pCategory = "";
    String pManufacturer = "";
    int pUnitsInStock = 0;
    String pCondition = "New";
    String pFileName = "";

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        String sql = "SELECT * FROM product WHERE p_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, productId);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            pName = rs.getString("p_name");
            pUnitPrice = rs.getInt("p_unitPrice");
            pDescription = rs.getString("p_description");
            pCategory = rs.getString("p_category");
            pManufacturer = rs.getString("p_manufacturer");
            pUnitsInStock = rs.getInt("p_unitsInStock");
            pCondition = rs.getString("p_condition");
            pFileName = rs.getString("p_fileName");
        } else {
%>
            <script>
                alert("존재하지 않는 상품입니다.");
                history.back();
            </script>
<%
            return;
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        if (rs != null) try { rs.close(); } catch (Exception e) {}
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }

    String curImgSrc = "";
    if (pFileName != null && !pFileName.trim().isEmpty()) {
        curImgSrc = request.getContextPath() + "/images/" + pFileName.trim();
    }
%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>상품 수정 - COFFO</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <style>
        body {
            background-color: #fcfbf9;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }
        .form-container {
            max-width: 850px;
            margin: 40px auto 60px auto;
            background: #ffffff;
            border: 1px solid #e7e5e4;
            border-radius: 8px;
            padding: 40px 45px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
        }
        .my-form-group { margin-bottom: 22px; }
        .my-form-group label {
            font-size: 14px;
            font-weight: 700;
            color: #333333;
            margin-bottom: 8px;
            display: block;
        }
        .my-form-control {
            width: 100% !important;
            padding: 10px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
            outline: none;
        }
        .my-form-control:focus {
            border-color: #28a745;
        }
        .my-form-control[readonly] {
            background-color: #f1f3f5;
            cursor: not-allowed;
        }

        /* 파일 커스텀 업로드 */
        .file-upload-wrapper {
            display: flex;
            align-items: center;
            width: 100%;
        }
        .real-file-input { display: none !important; }
        .custom-file-btn {
            background-color: #f4f4f4;
            border: 1px solid #ccc;
            border-right: none;
            border-radius: 4px 0 0 4px;
            padding: 10px 20px;
            font-size: 14px;
            color: #333;
            cursor: pointer;
            white-space: nowrap;
        }
        .custom-file-btn:hover { background-color: #e9ecef; }
        .custom-file-text {
            flex-grow: 1;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 0 4px 4px 0;
            padding: 10px 15px;
            font-size: 14px;
            color: #666;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
        }

        /* 이미지 미리보기 박스 */
        .image-preview-box {
            margin-top: 12px;
            width: 100%;
            height: 240px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            background-color: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        .image-preview-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        .image-preview-box .placeholder-text {
            color: #868e96;
            font-size: 13px;
        }

        .btn-update {
            background-color: #28a745;
            border: none;
            color: #ffffff;
            font-size: 15px;
            font-weight: 700;
            padding: 12px 35px;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-update:hover { background-color: #218838; }
        .btn-cancel {
            background-color: #6c757d;
            border: none;
            color: #ffffff !important;
            font-size: 15px;
            font-weight: 700;
            padding: 12px 30px;
            border-radius: 4px;
            text-decoration: none !important;
            display: inline-block;
            margin-left: 8px;
        }
        .btn-cancel:hover { background-color: #5a6268; }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="container">
        <div class="form-container">
            <h3 class="mb-4 font-weight-bold" style="color: #212529;">상품 수정</h3>
            
            <form name="updateProduct" action="processUpdateProduct.jsp" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 my-form-group">
                        <label>상품 코드 (ID)</label>
                        <input type="text" name="productId" class="my-form-control" value="<%= productId %>" readonly>
                    </div>
                    <div class="col-md-6 my-form-group">
                        <label>상품명</label>
                        <input type="text" name="name" class="my-form-control" value="<%= (pName != null) ? pName : "" %>" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 my-form-group">
                        <label>가격 (원)</label>
                        <input type="number" name="unitPrice" class="my-form-control" value="<%= pUnitPrice %>" required>
                    </div>
                    <div class="col-md-4 my-form-group">
                        <label>제조사 / 로스터리</label>
                        <input type="text" name="manufacturer" class="my-form-control" value="<%= (pManufacturer != null) ? pManufacturer : "" %>" required>
                    </div>
                    <div class="col-md-4 my-form-group">
                        <label>재고 수량</label>
                        <input type="number" name="unitsInStock" class="my-form-control" value="<%= pUnitsInStock %>" required>
                    </div>
                </div>

                <div class="my-form-group">
                    <label>분류 (Category)</label>
                    <input type="text" name="category" class="my-form-control" value="<%= (pCategory != null) ? pCategory : "" %>" required>
                </div>

                <div class="my-form-group">
                    <label>상태</label>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="condition" id="cond1" value="New" <%= "New".equalsIgnoreCase(pCondition) ? "checked" : "" %>>
                        <label class="form-check-label" for="cond1" style="font-weight: 500;">신규 제품</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="condition" id="cond2" value="Used" <%= "Used".equalsIgnoreCase(pCondition) ? "checked" : "" %>>
                        <label class="form-check-label" for="cond2" style="font-weight: 500;">중고 제품</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="condition" id="cond3" value="Refurbished" <%= "Refurbished".equalsIgnoreCase(pCondition) ? "checked" : "" %>>
                        <label class="form-check-label" for="cond3" style="font-weight: 500;">재생 제품</label>
                    </div>
                </div>

                <div class="my-form-group">
                    <label>상세 스펙 설명</label>
                    <textarea name="description" class="my-form-control" rows="5" required><%= (pDescription != null) ? pDescription : "" %></textarea>
                </div>

                <!-- 기존 이미지 유지 및 변경 미리보기 구역 -->
                <div class="my-form-group">
                    <label>이미지 변경 (미선택 시 기존 이미지 유지)</label>
                    
                    <!-- 새 파일 미선택 시 기존 이미지 파일명을 전송하기 위한 hidden -->
                    <input type="hidden" name="oldFileName" value="<%= (pFileName != null) ? pFileName : "" %>">

                    <div class="file-upload-wrapper">
                        <button type="button" class="custom-file-btn" onclick="document.getElementById('productImageInput').click()">파일 선택</button>
                        <div class="custom-file-text" id="fileNameDisplay">
                            <%= (pFileName != null && !pFileName.isEmpty()) ? pFileName : "선택된 파일 없음" %>
                        </div>
                        <input type="file" name="productImage" id="productImageInput" class="real-file-input" accept="image/*" onchange="handleFileChange(this)">
                    </div>

                    <!-- 실시간 이미지 미리보기 (기존 DB 이미지를 초기값으로 띄움) -->
                    <div class="image-preview-box">
                        <img id="previewImage" 
                             src="<%= curImgSrc %>" 
                             alt="상품 미리보기"
                             style="<%= (curImgSrc.isEmpty()) ? "display: none;" : "display: block;" %>"
                             onerror="this.style.display='none'; document.getElementById('previewPlaceholder').style.display='block';">
                        <span class="placeholder-text" id="previewPlaceholder" style="<%= (!curImgSrc.isEmpty()) ? "display: none;" : "display: block;" %>">
                            등록된 이미지가 없습니다.
                        </span>
                    </div>
                </div>

                <div class="mt-4 pt-2">
                    <button type="submit" class="btn-update">수정 완료</button>
                    <a href="editProduct.jsp?edit=update" class="btn-cancel">취소</a>
                </div>
            </form>
        </div>
    </div>

    <jsp:include page="footer.jsp" />

    <script type="text/javascript">
        var originSrc = "<%= curImgSrc %>";
        var originFileName = "<%= (pFileName != null && !pFileName.isEmpty()) ? pFileName : "선택된 파일 없음" %>";

        function handleFileChange(input) {
            var fileNameText = document.getElementById("fileNameDisplay");
            var previewImg = document.getElementById("previewImage");
            var placeholder = document.getElementById("previewPlaceholder");

            if (input.files && input.files[0]) {
                var file = input.files[0];
                fileNameText.innerText = file.name;
                fileNameText.style.color = "#333";

                // 새 파일 선택 시 미리보기 교체
                var reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    previewImg.style.display = "block";
                    placeholder.style.display = "none";
                };
                reader.readAsDataURL(file);
            } else {
                // 선택 취소 시 원래 등록된 이미지로 복원
                fileNameText.innerText = originFileName;
                fileNameText.style.color = "#666";

                if (originSrc !== "") {
                    previewImg.src = originSrc;
                    previewImg.style.display = "block";
                    placeholder.style.display = "none";
                } else {
                    previewImg.src = "";
                    previewImg.style.display = "none";
                    placeholder.style.display = "block";
                }
            }
        }
    </script>
</body>
</html>