<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");
    request.setAttribute("currentPage", "게시판");

    // 세션 사용자 확인
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    // 페이징 설정 (페이지당 5개 출력)
    int pageSize = 5;
    String pageNumStr = request.getParameter("pageNum");
    int pageNum = 1;
    if (pageNumStr != null && !pageNumStr.trim().isEmpty()) {
        try {
            pageNum = Integer.parseInt(pageNumStr);
        } catch (Exception e) {
            pageNum = 1;
        }
    }

    // 검색 파라미터 처리
    String searchField = request.getParameter("searchField");
    String searchText = request.getParameter("searchText");
    if (searchField == null) searchField = "subject";
    if (searchText == null) searchText = "";
    searchText = searchText.trim();

    Connection conn = null;
    PreparedStatement pstmtCount = null;
    PreparedStatement pstmtList = null;
    ResultSet rsCount = null;
    ResultSet rsList = null;

    int totalCount = 0;
    int totalPage = 1;

    int startRow = (pageNum - 1) * pageSize + 1;
    int endRow = pageNum * pageSize;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // 1. 전체 게시글 수 카운트 (검색 조건 적용)
        String countSql = "SELECT COUNT(*) FROM board";
        if (!searchText.isEmpty()) {
            if ("subject".equals(searchField)) {
                countSql += " WHERE subject LIKE ?";
            } else if ("content".equals(searchField)) {
                countSql += " WHERE content LIKE ?";
            } else if ("name".equals(searchField)) {
                countSql += " WHERE name LIKE ?";
            }
        }

        pstmtCount = conn.prepareStatement(countSql);
        if (!searchText.isEmpty()) {
            pstmtCount.setString(1, "%" + searchText + "%");
        }
        rsCount = pstmtCount.executeQuery();
        if (rsCount.next()) {
            totalCount = rsCount.getInt(1);
        }

        totalPage = (int) Math.ceil((double) totalCount / pageSize);
        if (totalPage == 0) totalPage = 1;

        // 2. 오라클 페이징 쿼리
        String listSql = "SELECT * FROM ("
                       + "  SELECT ROWNUM AS rnum, a.* FROM ("
                       + "    SELECT num, id, name, subject, hit, regist_day "
                       + "    FROM board ";

        if (!searchText.isEmpty()) {
            if ("subject".equals(searchField)) {
                listSql += " WHERE subject LIKE ?";
            } else if ("content".equals(searchField)) {
                listSql += " WHERE content LIKE ?";
            } else if ("name".equals(searchField)) {
                listSql += " WHERE name LIKE ?";
            }
        }

        listSql += "    ORDER BY num DESC"
                + "  ) a WHERE ROWNUM <= ?"
                + ") WHERE rnum >= ?";

        pstmtList = conn.prepareStatement(listSql);
        int paramIdx = 1;
        if (!searchText.isEmpty()) {
            pstmtList.setString(paramIdx++, "%" + searchText + "%");
        }
        pstmtList.setInt(paramIdx++, endRow);
        pstmtList.setInt(paramIdx++, startRow);

        rsList = pstmtList.executeQuery();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>고객 소통 Q&amp;A 게시판</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #fafafa;
            font-family: 'Poppins', -apple-system, sans-serif;
            margin: 0;
            padding: 0;
        }
        .header-title-area {
            text-align: center;
            padding: 55px 0 25px 0;
            color: #212529;
        }
        .header-title-area h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }
        .header-title-area p {
            color: #767676;
            font-size: 14px;
            margin: 0;
        }
        .board-container {
            max-width: 1050px;
            margin: 0 auto 60px auto;
            background: #ffffff;
            border-radius: 12px;
            padding: 35px 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            border: 1px solid #eaeaea;
        }
        .board-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .total-badge {
            font-size: 14px;
            color: #333333;
            font-weight: 600;
        }
        .total-badge span {
            color: #e53935;
            font-weight: 700;
        }
        .btn-write {
            background-color: #111111;
            color: #ffffff !important;
            padding: 8px 18px;
            font-size: 14px;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none !important;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: background-color 0.2s;
        }
        .btn-write:hover {
            background-color: #333333;
        }
        .board-table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
        }
        .board-table th {
            background-color: #f8f9fa;
            color: #495057;
            font-weight: 700;
            font-size: 14px;
            padding: 14px 10px;
            border-top: 1px solid #dee2e6;
            border-bottom: 1px solid #dee2e6;
        }
        .board-table td {
            padding: 16px 10px;
            font-size: 14px;
            color: #333333;
            border-bottom: 1px solid #f1f3f5;
        }
        .board-table td.subject {
            text-align: left;
            padding-left: 20px;
        }
        .board-table td.subject a {
            color: #212529;
            text-decoration: none;
            font-weight: 500;
        }
        .board-table td.subject a:hover {
            color: #e53935;
            text-decoration: underline;
        }
        .pagination-area {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            margin: 30px 0 20px 0;
        }
        .page-link-custom {
            display: inline-block;
            min-width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none !important;
            color: #495057;
            border: 1px solid #dee2e6;
            background: #ffffff;
            transition: all 0.2s;
        }
        .page-link-custom.active {
            background-color: #ff0000;
            border-color: #ff0000;
            color: #ffffff !important;
        }
        .page-link-custom:hover:not(.active) {
            background-color: #f8f9fa;
        }
        .search-area {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        .search-select, .search-input {
            height: 38px;
            padding: 4px 12px;
            font-size: 13px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            outline: none;
        }
        .search-btn {
            background-color: #212529;
            color: #ffffff;
            border: none;
            padding: 0 18px;
            font-size: 13px;
            font-weight: 600;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .search-btn:hover {
            background-color: #343a40;
        }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="header-title-area">
        <h2>고객 소통 Q&amp;A 게시판</h2>
        <p>원두 문의, 배송 질문 및 쇼핑몰 이용 후기를 확인하세요.</p>
    </div>

    <div class="board-container">
        <div class="board-top">
            <div class="total-badge">전체 게시글: <span><%= totalCount %></span>건</div>
            <a href="writeForm.jsp" class="btn-write"><i class="fa fa-pencil"></i> 글쓰기</a>
        </div>

        <table class="board-table">
            <thead>
                <tr>
                    <th style="width: 8%;">번호</th>
                    <th style="width: 52%;">제목</th>
                    <th style="width: 15%;">작성자</th>
                    <th style="width: 15%;">작성일</th>
                    <th style="width: 10%;">조회</th>
                </tr>
            </thead>
            <tbody>
<%
        boolean hasRow = false;
        while (rsList.next()) {
            hasRow = true;
            int num = rsList.getInt("num");
            String subject = rsList.getString("subject");
            String name = rsList.getString("name");
            
            // 🌟 날짜 포맷팅: 26/09/10 또는 26-09-10 -> 2026-09-10 으로 정밀 변환
            String regDay = rsList.getString("regist_day");
            if (regDay == null || regDay.trim().isEmpty()) {
                regDay = "-";
            } else {
                regDay = regDay.trim().replace("/", "-");
                if (regDay.length() == 8 && regDay.charAt(2) == '-') {
                    // 26-09-10 -> 2026-09-10
                    regDay = "20" + regDay;
                } else if (regDay.length() > 10) {
                    regDay = regDay.substring(0, 10);
                }
            }
            
            int hit = rsList.getInt("hit");
%>
                <tr>
                    <td><%= num %></td>
                    <td class="subject">
                        <a href="view.jsp?num=<%= num %>&pageNum=<%= pageNum %>"><%= subject %></a>
                    </td>
                    <td><%= name %></td>
                    <td><%= regDay %></td>
                    <td><%= hit %></td>
                </tr>
<%
        }
        if (!hasRow) {
%>
                <tr>
                    <td colspan="5" style="padding: 40px 0; color: #868e96;">등록된 게시글이 없습니다.</td>
                </tr>
<%
        }
%>
            </tbody>
        </table>

        <!-- 페이징 영역 -->
        <div class="pagination-area">
<%
        for (int i = 1; i <= totalPage; i++) {
%>
            <a href="list.jsp?pageNum=<%= i %>&searchField=<%= searchField %>&searchText=<%= searchText %>" 
               class="page-link-custom <%= (i == pageNum) ? "active" : "" %>"><%= i %></a>
<%
        }
%>
        </div>

        <!-- 검색 영역 -->
        <form action="list.jsp" method="get">
            <div class="search-area">
                <select name="searchField" class="search-select">
                    <option value="subject" <%= "subject".equals(searchField) ? "selected" : "" %>>제목</option>
                    <option value="content" <%= "content".equals(searchField) ? "selected" : "" %>>내용</option>
                    <option value="name" <%= "name".equals(searchField) ? "selected" : "" %>>작성자</option>
                </select>
                <input type="text" name="searchText" value="<%= searchText %>" placeholder="검색어 입력" class="search-input">
                <button type="submit" class="search-btn">검색</button>
            </div>
        </form>
    </div>

    <jsp:include page="footer.jsp" />

</body>
</html>
<%
    } catch (Exception e) {
        e.printStackTrace();
        out.println("<div style='color:red; padding:20px;'>게시글 목록 로딩 오류: " + e.getMessage() + "</div>");
    } finally {
        if (rsList != null) try { rsList.close(); } catch (Exception e) {}
        if (rsCount != null) try { rsCount.close(); } catch (Exception e) {}
        if (pstmtList != null) try { pstmtList.close(); } catch (Exception e) {}
        if (pstmtCount != null) try { pstmtCount.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>