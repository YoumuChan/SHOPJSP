<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setBundle basename="resource" />

<%
    String coffo_nav_loginUser = (String) session.getAttribute("loginUser");
    if (coffo_nav_loginUser == null) {
        coffo_nav_loginUser = (String) session.getAttribute("sessionId");
    }

    String coffo_nav_uri = request.getRequestURI();
    boolean coffo_nav_isMain = coffo_nav_uri.contains("main.jsp") || coffo_nav_uri.endsWith("/");

    String coffo_nav_currentPage = (String) request.getAttribute("currentPage");
    if (coffo_nav_currentPage != null) {
        if (coffo_nav_currentPage.contains("등록")) coffo_nav_currentPage = "등록";
        else if (coffo_nav_currentPage.contains("수정")) coffo_nav_currentPage = "수정";
        else if (coffo_nav_currentPage.contains("삭제")) coffo_nav_currentPage = "삭제";
        else if (coffo_nav_currentPage.contains("상점") || coffo_nav_currentPage.contains("shop") || coffo_nav_currentPage.contains("Products")) coffo_nav_currentPage = "상점";
        else if (coffo_nav_currentPage.contains("게시판") || coffo_nav_currentPage.contains("Q&A") || coffo_nav_currentPage.contains("list") || coffo_nav_currentPage.contains("blog")) coffo_nav_currentPage = "게시판";
        else if (coffo_nav_currentPage.contains("마이페이지") || coffo_nav_currentPage.contains("mypage")) coffo_nav_currentPage = "마이페이지";
        else if (coffo_nav_currentPage.contains("홈") || coffo_nav_currentPage.contains("main")) coffo_nav_currentPage = "홈";
    }
    
    if (coffo_nav_currentPage == null) {
        if (coffo_nav_uri.contains("InProduct.jsp") || coffo_nav_uri.contains("addProduct")) coffo_nav_currentPage = "등록";
        else if (coffo_nav_uri.contains("editProduct.jsp") && coffo_nav_uri.contains("update")) coffo_nav_currentPage = "수정";
        else if (coffo_nav_uri.contains("editProduct.jsp") && coffo_nav_uri.contains("delete")) coffo_nav_currentPage = "삭제";
        else if (coffo_nav_uri.contains("Products.jsp") || coffo_nav_uri.contains("shop.jsp") || coffo_nav_uri.contains("product.jsp")) coffo_nav_currentPage = "상점";
        else if (coffo_nav_uri.contains("list.jsp") || coffo_nav_uri.contains("view.jsp") || coffo_nav_uri.contains("writeForm.jsp") || coffo_nav_uri.contains("updateForm.jsp")) coffo_nav_currentPage = "게시판";
        else if (coffo_nav_uri.contains("mypage.jsp")) coffo_nav_currentPage = "마이페이지";
        else if (coffo_nav_uri.contains("main.jsp") || coffo_nav_uri.endsWith("/")) coffo_nav_currentPage = "홈";
        else coffo_nav_currentPage = "기타";
    }
%>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <title>Coffo - 커피 숍</title>
   
   <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="css/style.css">
   <link rel="stylesheet" href="css/responsive.css">
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   
   <style>
      .header_section { position: relative !important; z-index: 9999 !important; }

      .admin-top-bar {
         background-color: #212934 !important;
         color: #cfd6dc !important;
         padding: 10px 0 !important;
         font-size: 14px !important;
         border-bottom: 1px solid #323d4c;
         position: relative !important;
         z-index: 10000 !important;
      }
      .admin-top-bar .admin-title { color: #ffffff !important; font-weight: 700 !important; font-size: 14px !important; }
      .admin-top-bar .admin-links a {
         color: #cfd6dc !important; text-decoration: none !important; margin-left: 20px !important;
         font-weight: 600 !important; transition: color 0.2s; cursor: pointer !important;
      }
      .admin-top-bar .admin-links a:hover { color: #59ab6e !important; }
      .admin-top-bar .admin-links a.active { color: #ffc107 !important; }

      @media (min-width: 992px) {
         .header_section .container { max-width: 96% !important; width: 96% !important; }
         .navbar { display: flex !important; flex-wrap: nowrap !important; align-items: center !important; width: 100% !important; }
         .navbar-brand { display: inline-block !important; flex-shrink: 0 !important; width: 130px !important; margin-right: 25px !important; }
         .navbar-nav .nav-link { padding: 10px 16px !important; font-size: 15px !important; font-weight: 600 !important; white-space: nowrap !important; }
         .time-link-custom { padding: 0 14px !important; }
      }

      @media (max-width: 991.98px) {
         .navbar { display: flex !important; flex-wrap: wrap !important; justify-content: space-between !important; align-items: center !important; position: relative !important; }
         .navbar-brand { display: inline-block !important; width: 120px !important; margin: 0 !important; }
         .navbar-toggler {
            display: block !important; margin-left: auto !important; background-color: #ffffff !important; border: 1px solid #ddd !important;
            padding: 6px 10px !important; outline: none !important; cursor: pointer !important; z-index: 10001 !important;
         }
         .navbar-collapse { display: none !important; }
         .navbar-collapse.show-mobile {
            display: block !important; flex-basis: 100% !important; background-color: #2b2b2b !important; padding: 20px 15px !important;
            margin-top: 15px !important; border-radius: 8px !important; box-shadow: 0 10px 25px rgba(0,0,0,0.5) !important;
            position: relative !important; z-index: 99999 !important; pointer-events: auto !important;
         }
         .navbar-nav { display: flex !important; flex-direction: column !important; align-items: flex-start !important; width: 100% !important; }
         .navbar-nav .nav-item { width: 100% !important; margin: 4px 0 !important; }
         .navbar-nav .nav-link { color: #ffffff !important; padding: 10px 10px !important; font-size: 15px !important; width: 100% !important; display: block !important; }
         .time-link-custom { padding: 8px 10px !important; display: block !important; }
         .lang-toggle-link { margin: 8px 0 5px 10px !important; display: inline-block !important; }
         .form-inline { width: 100% !important; margin-top: 15px !important; padding-top: 15px !important; border-top: 1px solid #444 !important; display: block !important; }
         .login_bt, .login_bt ul { width: 100% !important; display: flex !important; justify-content: flex-start !important; }
         .dropdown-menu-custom { position: static !important; width: 100% !important; background-color: #3a3a3a !important; margin-top: 8px !important; box-shadow: none !important; }
         .login_bt ul li.dropdown .dropdown-menu-custom a.dropdown-item { color: #ffffff !important; background-color: #3a3a3a !important; padding: 10px 15px !important; }
      }

      .navbar-brand img { display: block !important; width: 100% !important; height: auto !important; }
      .login_bt ul { display: flex !important; align-items: center !important; margin: 0 !important; padding: 0 !important; list-style: none; }
      .login_bt ul li { display: inline-block !important; }
      .login_bt ul li.dropdown { position: relative !important; }
      .login_bt ul li.dropdown a {
         cursor: pointer !important; display: flex !important; align-items: center !important; color: #ffffff !important;
         text-decoration: none !important; white-space: nowrap !important; font-size: 15px; font-weight: 600;
      }
      .login_bt .user_icon { margin-right: 8px !important; }
      
      .dropdown-menu-custom { 
         display: none; position: absolute !important; top: 100% !important; right: 0 !important; min-width: 160px !important;
         background-color: #ffffff !important; border: 1px solid #e1e1e1 !important; border-radius: 6px !important; padding: 6px 0 !important;
         margin-top: 12px !important; box-shadow: 0 5px 15px rgba(0,0,0,0.15) !important; z-index: 999999 !important;
      }
      .dropdown-menu-custom.show { display: block !important; }
      .login_bt ul li.dropdown .dropdown-menu-custom a.dropdown-item {
         color: #000000 !important; background-color: #ffffff !important; display: block !important; width: 100% !important;
         padding: 10px 18px !important; font-size: 13px !important; font-weight: 600 !important; text-align: left !important;
         text-decoration: none !important; box-sizing: border-box !important;
      }
      .login_bt ul li.dropdown .dropdown-menu-custom a.dropdown-item:hover { background-color: #f8f9fa !important; color: #ff0000 !important; }
      .dropdown-divider-custom { height: 1px; margin: 6px 0; overflow: hidden; background-color: #eeeeee; }

      .time-link-custom {
         color: #ff0000 !important; background-color: transparent !important; font-weight: 600 !important; font-size: 14px !important;
         cursor: default !important; pointer-events: none !important; display: inline-block !important; white-space: nowrap !important; margin: 0 !important;
      }
      .lang-toggle-link {
         color: #ffffff !important; font-weight: bold !important; text-decoration: none !important; font-size: 12px !important;
         padding: 4px 10px !important; border: 1px solid rgba(255, 255, 255, 0.4) !important; border-radius: 20px !important;
         transition: all 0.2s ease-in-out !important; background-color: rgba(255, 255, 255, 0.1) !important; white-space: nowrap !important; margin-right: 8px; cursor: pointer !important;
      }
      .lang-toggle-link:hover { background-color: #ff0000 !important; border-color: #ff0000 !important; }

      <% if (coffo_nav_isMain) { %>
      .banner_section {
         background-image: url(<%= request.getContextPath() %>/images/banner-bg.png) !important;
         background-size: 100% 100% !important; background-repeat: no-repeat !important;
      }
      <% } %>
   </style>
   
   <script type="text/javascript">
       var clockPrefixText = "<fmt:message key='clock_prefix' />";
       function startLiveClock() {
           function updateClock() {
               var now = new Date();
               var hours = now.getHours(), minutes = now.getMinutes(), seconds = now.getSeconds();
               var ampm = hours >= 12 ? 'PM' : 'AM';
               hours = hours % 12 || 12;
               var minStr = minutes < 10 ? '0' + minutes : minutes;
               var secStr = seconds < 10 ? '0' + seconds : seconds;
               var clockEl = document.getElementById("liveClock");
               if (clockEl) { clockEl.innerHTML = clockPrefixText + ampm + ' ' + hours + ':' + minStr + ':' + secStr; }
           }
           updateClock();
           setInterval(updateClock, 1000); 
       }
       function toggleMobileMenu(event) {
           event.preventDefault(); event.stopPropagation();
           var menu = document.getElementById("navbarSupportedContent");
           if (menu) menu.classList.toggle("show-mobile");
       }
       function toggleLoginDropdown(event) {
           event.preventDefault(); event.stopPropagation();
           var menu = document.getElementById("customLoginMenu");
           if (menu) menu.classList.toggle("show");
       }
       window.onclick = function(event) {
           var menu = document.getElementById("customLoginMenu");
           if (menu && menu.classList.contains("show")) {
               if (!event.target.matches('#loginDropdown') && !event.target.matches('.user_icon') && !event.target.matches('.fa-user')) {
                   menu.classList.remove("show");
               }
           }
       }
       window.addEventListener("DOMContentLoaded", startLiveClock);
   </script>
</head>
<body>

   <% if (coffo_nav_loginUser != null && coffo_nav_loginUser.equals("admin")) { %>
       <div class="admin-top-bar">
           <div class="container d-flex justify-content-between align-items-center">
               <div class="admin-title">⚙️ 관리자 모드</div>
               <div class="admin-links">
                   <a href="InProduct.jsp" class="<%= "등록".equals(coffo_nav_currentPage) ? "active" : "" %>">상품 등록</a>
                   <a href="editProduct.jsp?edit=update" class="<%= "수정".equals(coffo_nav_currentPage) ? "active" : "" %>">상품 수정</a>
                   <a href="editProduct.jsp?edit=delete" class="<%= "삭제".equals(coffo_nav_currentPage) ? "active" : "" %>">상품 삭제</a>
               </div>
           </div>
       </div>
   <% } %>

   <div class="header_section">
      <div class="container">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="main.jsp"><img src="<%= request.getContextPath() %>/images/logo.png" alt="COFFO"></a>
            
            <button class="navbar-toggler" type="button" onclick="toggleMobileMenu(event)">
               <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item <%= "홈".equals(coffo_nav_currentPage) ? "active" : "" %>">
                     <a class="nav-link" href="main.jsp"><fmt:message key="menu_home" /></a>
                  </li>
                  <li class="nav-item <%= "상점".equals(coffo_nav_currentPage) ? "active" : "" %>">
                     <a class="nav-link" href="Products.jsp"><fmt:message key="menu_shop" /></a>
                  </li>
                  <li class="nav-item <%= "게시판".equals(coffo_nav_currentPage) ? "active" : "" %>">
                     <a class="nav-link" href="list.jsp">게시판</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="cart.jsp">장바구니</a>
                  </li>
                  
                  <li class="nav-item" style="display: flex; align-items: center;">
                     <span class="time-link-custom" id="liveClock">
                        <fmt:message key="clock_prefix" /><fmt:message key="clock_calculating" />
                     </span>
                  </li>

                  <li class="nav-item" style="display: flex; align-items: center;">
                     <% 
                         String curLang = (String) session.getAttribute("currentLang"); 
                         if ("en".equals(curLang)) { 
                     %>
                         <a href="setLocale.jsp?lang=ko" class="lang-toggle-link">🇰🇷 KO</a>
                     <% } else { %>
                         <a href="setLocale.jsp?lang=en" class="lang-toggle-link">🇺🇸 EN</a>
                     <% } %>
                  </li>
               </ul>
               
               <div class="form-inline my-2 my-lg-0">
                  <div class="login_bt">
                     <ul>
                        <li class="dropdown">
                           <a href="#" id="loginDropdown" onclick="toggleLoginDropdown(event)">
                              <span class="user_icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                              <% if (coffo_nav_loginUser != null) { %>
                                  <%= coffo_nav_loginUser %>님
                              <% } else { %>
                                  <fmt:message key="menu_login" />
                              <% } %>
                           </a>
     
                           <div class="dropdown-menu-custom" id="customLoginMenu">
                              <% if (coffo_nav_loginUser == null) { %>
                                 <a class="dropdown-item" href="login.jsp"><fmt:message key="menu_login" /></a>
                                 <a class="dropdown-item" href="register.jsp"><fmt:message key="menu_register" /></a>
                              <% } else { %>
                                 <a class="dropdown-item" href="mypage.jsp"><i class="fa fa-id-card-o mr-1"></i> 마이페이지</a>
                                 <div class="dropdown-divider-custom"></div>
                                 <a class="dropdown-item" href="logout.jsp"><i class="fa fa-sign-out mr-1"></i> 로그아웃</a>
                              <% } %>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </nav>
      </div>
   </div>

   <!-- 계층형 자동 브레드크럼 -->
   <% if (!coffo_nav_isMain) { %>
       <div class="breadcrumb_section" style="background-color: #f8f9fa; padding: 14px 0; margin-bottom: 25px; border-bottom: 1px solid #e9ecef;">
           <div class="container" style="max-width: 96%;">
               <nav aria-label="breadcrumb">
                   <ol style="display: flex; flex-wrap: wrap; list-style: none; margin: 0; padding: 0; font-size: 13px; align-items: center;">
                       <li style="display: inline-flex; align-items: center;">
                           <a href="main.jsp" style="color: #6c757d; text-decoration: none; font-weight: 500;">
                               <i class="fa fa-home" style="margin-right: 4px;"></i>홈
                           </a>
                           <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                       </li>

                       <% if (coffo_nav_uri.contains("Products.jsp") || coffo_nav_uri.contains("shop.jsp")) { %>
                           <li style="color: #ff0000; font-weight: 700;">상점</li>

                       <% } else if (coffo_nav_uri.contains("product.jsp") || coffo_nav_uri.contains("ShowProductData.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="Products.jsp" style="color: #6c757d; text-decoration: none;">상점</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">상세정보</li>

                       <% } else if (coffo_nav_uri.contains("cart.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="Products.jsp" style="color: #6c757d; text-decoration: none;">상점</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">장바구니</li>

                       <% } else if (coffo_nav_uri.contains("shippingInfo.jsp") || coffo_nav_uri.contains("orderConfirmation.jsp") || coffo_nav_uri.contains("thankCustomer.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="Products.jsp" style="color: #6c757d; text-decoration: none;">상점</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="cart.jsp" style="color: #6c757d; text-decoration: none;">장바구니</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">주문결제</li>

                       <% } else if (coffo_nav_uri.contains("list.jsp")) { %>
                           <li style="color: #ff0000; font-weight: 700;">게시판</li>

                       <% } else if (coffo_nav_uri.contains("view.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="list.jsp" style="color: #6c757d; text-decoration: none;">게시판</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">게시글 보기</li>

                       <% } else if (coffo_nav_uri.contains("writeForm.jsp") || coffo_nav_uri.contains("updateForm.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <a href="list.jsp" style="color: #6c757d; text-decoration: none;">게시판</a>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">글쓰기</li>

                       <% } else if (coffo_nav_uri.contains("InProduct.jsp") || coffo_nav_uri.contains("editProduct.jsp")) { %>
                           <li style="display: inline-flex; align-items: center;">
                               <span style="color: #6c757d;">관리자</span>
                               <span style="margin: 0 8px; color: #adb5bd;">&gt;</span>
                           </li>
                           <li style="color: #ff0000; font-weight: 700;">
                               <%= coffo_nav_uri.contains("InProduct.jsp") ? "상품 등록" : "상품 수정/삭제" %>
                           </li>

                       <% } else if (coffo_nav_uri.contains("login.jsp")) { %>
                           <li style="color: #ff0000; font-weight: 700;">로그인</li>

                       <% } else if (coffo_nav_uri.contains("register.jsp")) { %>
                           <li style="color: #ff0000; font-weight: 700;">회원가입</li>

                       <% } else if (coffo_nav_uri.contains("mypage.jsp")) { %>
                           <li style="color: #ff0000; font-weight: 700;">마이페이지</li>

                       <% } else { %>
                           <li style="color: #ff0000; font-weight: 700;">
                               <%= (request.getAttribute("currentPage") != null) ? request.getAttribute("currentPage") : "페이지" %>
                           </li>
                       <% } %>
                   </ol>
               </nav>
           </div>
       </div>
   <% } %>