<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    // 세션 사용자 확인
    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    // 페이징 설정 (페이지당 5개)
    int pageSize = 5;
    String pageNumStr = request.getParameter("pageNum");
    int pageNum = 1;
    if (pageNumStr != null && !pageNumStr.trim().isEmpty()) {
        try {
            pageNum = Integer.parseInt(pageNumStr);
        } catch (Exception e) {
            pageNum = 1;
        }
    }

    // 검색 파라미터 처리
    String searchField = request.getParameter("searchField");
    String searchText = request.getParameter("searchText");
    if (searchField == null) searchField = "subject";
    if (searchText == null) searchText = "";
    searchText = searchText.trim();

    Connection conn = null;
    PreparedStatement pstmtCount = null;
    PreparedStatement pstmtList = null;
    ResultSet rsCount = null;
    ResultSet rsList = null;

    int totalCount = 0;
    int totalPage = 1;

    int startRow = (pageNum - 1) * pageSize + 1;
    int endRow = pageNum * pageSize;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");

        // 1. 전체 게시글 수 조회
        String countSql = "SELECT COUNT(*) FROM board";
        if (!searchText.isEmpty()) {
            if ("subject".equals(searchField)) {
                countSql += " WHERE subject LIKE ?";
            } else if ("content".equals(searchField)) {
                countSql += " WHERE content LIKE ?";
            } else if ("name".equals(searchField)) {
                countSql += " WHERE name LIKE ?";
            }
        }

        pstmtCount = conn.prepareStatement(countSql);
        if (!searchText.isEmpty()) {
            pstmtCount.setString(1, "%" + searchText + "%");
        }
        rsCount = pstmtCount.executeQuery();
        if (rsCount.next()) {
            totalCount = rsCount.getInt(1);
        }

        totalPage = (int) Math.ceil((double) totalCount / pageSize);
        if (totalPage == 0) totalPage = 1;

        // 2. 오라클 페이징 쿼리 (regist_day 그대로 조회)
        String listSql = "SELECT * FROM ("
                       + "  SELECT ROWNUM AS rnum, a.* FROM ("
                       + "    SELECT num, id, name, subject, hit, regist_day "
                       + "    FROM board ";

        if (!searchText.isEmpty()) {
            if ("subject".equals(searchField)) {
                listSql += " WHERE subject LIKE ?";
            } else if ("content".equals(searchField)) {
                listSql += " WHERE content LIKE ?";
            } else if ("name".equals(searchField)) {
                listSql += " WHERE name LIKE ?";
            }
        }

        listSql += "    ORDER BY num DESC"
                + "  ) a WHERE ROWNUM <= ?"
                + ") WHERE rnum >= ?";

        pstmtList = conn.prepareStatement(listSql);
        int paramIdx = 1;
        if (!searchText.isEmpty()) {
            pstmtList.setString(paramIdx++, "%" + searchText + "%");
        }
        pstmtList.setInt(paramIdx++, endRow);
        pstmtList.setInt(paramIdx++, startRow);

        rsList = pstmtList.executeQuery();
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>고객 소통 Q&amp;A 게시판</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <style>
        body {
            background-color: #1a222d;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
        }
        .header-title-area {
            text-align: center;
            padding: 45px 0 25px 0;
            color: #ffffff;
        }
        .header-title-area h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .header-title-area p {
            color: #94a3b8;
            font-size: 14px;
        }
        .board-container {
            max-width: 1050px;
            margin: 0 auto 60px auto;
            background: #ffffff;
            border-radius: 12px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
        }
        .board-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .total-badge {
            font-size: 14px;
            color: #334155;
            font-weight: 600;
        }
        .total-badge span {
            color: #e11d48;
            font-weight: 700;
        }
        .btn-write {
            background-color: #0f172a;
            color: #ffffff !important;
            padding: 8px 18px;
            font-size: 14px;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none !important;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-write:hover {
            background-color: #1e293b;
        }
        .board-table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
        }
        .board-table th {
            background-color: #f8fafc;
            color: #475569;
            font-weight: 700;
            font-size: 14px;
            padding: 14px 10px;
            border-top: 1px solid #e2e8f0;
            border-bottom: 1px solid #e2e8f0;
        }
        .board-table td {
            padding: 15px 10px;
            font-size: 14px;
            color: #334155;
            border-bottom: 1px solid #f1f5f9;
        }
        .board-table td.subject {
            text-align: left;
            padding-left: 20px;
        }
        .board-table td.subject a {
            color: #0f172a;
            text-decoration: none;
            font-weight: 500;
        }
        .board-table td.subject a:hover {
            color: #e11d48;
            text-decoration: underline;
        }
        .pagination-area {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 6px;
            margin: 30px 0 20px 0;
        }
        .page-link-custom {
            display: inline-block;
            min-width: 32px;
            height: 32px;
            line-height: 32px;
            text-align: center;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none !important;
            color: #475569;
            border: 1px solid #e2e8f0;
            background: #ffffff;
        }
        .page-link-custom.active {
            background-color: #ff3b30;
            border-color: #ff3b30;
            color: #ffffff !important;
        }
        .page-link-custom:hover:not(.active) {
            background-color: #f1f5f9;
        }
        .search-area {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        .search-select, .search-input {
            height: 36px;
            padding: 4px 10px;
            font-size: 13px;
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            outline: none;
        }
        .search-btn {
            background-color: #1e293b;
            color: #ffffff;
            border: none;
            padding: 0 16px;
            font-size: 13px;
            font-weight: 600;
            border-radius: 4px;
            cursor: pointer;
        }
        .search-btn:hover {
            background-color: #334155;
        }
    </style>
</head>
<body>

    <jsp:include page="nav.jsp" />

    <div class="header-title-area">
        <h2>고객 소통 Q&amp;A 게시판</h2>
        <p>원두 문의, 배송 질문 및 쇼핑몰 이용 후기를 확인하세요.</p>
    </div>

    <div class="board-container">
        <div class="board-top">
            <div class="total-badge">전체 게시글: <span><%= totalCount %></span>건</div>
            <a href="writeForm.jsp" class="btn-write"><i class="fa fa-pencil"></i> 글쓰기</a>
        </div>

        <table class="board-table">
            <thead>
                <tr>
                    <th style="width: 8%;">번호</th>
                    <th style="width: 54%;">제목</th>
                    <th style="width: 14%;">작성자</th>
                    <th style="width: 14%;">작성일</th>
                    <th style="width: 10%;">조회</th>
                </tr>
            </thead>
            <tbody>
<%
        boolean hasRow = false;
        while (rsList.next()) {
            hasRow = true;
            int num = rsList.getInt("num");
            String subject = rsList.getString("subject");
            String name = rsList.getString("name");
            
            // VARCHAR2 및 DATE 타입 모두 안전하게 처리
            String regDay = rsList.getString("regist_day");
            if (regDay == null) {
                regDay = "-";
            } else if (regDay.length() > 10) {
                regDay = regDay.substring(0, 10);
            }
            
            int hit = rsList.getInt("hit");
%>
                <tr>
                    <td><%= num %></td>
                    <td class="subject">
                        <a href="view.jsp?num=<%= num %>&pageNum=<%= pageNum %>"><%= subject %></a>
                    </td>
                    <td><%= name %></td>
                    <td><%= regDay %></td>
                    <td><%= hit %></td>
                </tr>
<%
        }
        if (!hasRow) {
%>
                <tr>
                    <td colspan="5" style="padding: 40px 0; color: #94a3b8;">등록된 게시글이 없습니다.</td>
                </tr>
<%
        }
%>
            </tbody>
        </table>

        <!-- 페이징 영역 -->
        <div class="pagination-area">
<%
        for (int i = 1; i <= totalPage; i++) {
%>
            <a href="list.jsp?pageNum=<%= i %>&searchField=<%= searchField %>&searchText=<%= searchText %>" 
               class="page-link-custom <%= (i == pageNum) ? "active" : "" %>"><%= i %></a>
<%
        }
%>
        </div>

        <!-- 검색 영역 -->
        <form action="list.jsp" method="get">
            <div class="search-area">
                <select name="searchField" class="search-select">
                    <option value="subject" <%= "subject".equals(searchField) ? "selected" : "" %>>제목</option>
                    <option value="content" <%= "content".equals(searchField) ? "selected" : "" %>>내용</option>
                    <option value="name" <%= "name".equals(searchField) ? "selected" : "" %>>작성자</option>
                </select>
                <input type="text" name="searchText" value="<%= searchText %>" placeholder="검색어 입력" class="search-input">
                <button type="submit" class="search-btn">검색</button>
            </div>
        </form>
    </div>

</body>
</html>
<%
    } catch (Exception e) {
        e.printStackTrace();
        out.println("<div style='color:red; padding:20px;'>게시글 목록 로딩 오류: " + e.getMessage() + "</div>");
    } finally {
        if (rsList != null) try { rsList.close(); } catch (Exception e) {}
        if (rsCount != null) try { rsCount.close(); } catch (Exception e) {}
        if (pstmtList != null) try { pstmtList.close(); } catch (Exception e) {}
        if (pstmtCount != null) try { pstmtCount.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>