<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>

<%
    request.setCharacterEncoding("UTF-8");

    String sessionId = (String) session.getAttribute("sessionId");
    if (sessionId == null || sessionId.trim().isEmpty()) {
        sessionId = (String) session.getAttribute("loginUser");
    }

    String id = request.getParameter("id");
    if (id == null || id.trim().isEmpty()) {
        id = sessionId;
    }
    if (id == null || id.trim().isEmpty()) {
        id = "admin";
    }

    String name = request.getParameter("name");
    if (name == null || name.trim().isEmpty()) {
        name = "관리자";
    }

    String subject = request.getParameter("subject");
    String content = request.getParameter("content");
    String ip = request.getRemoteAddr();

    if (subject == null || subject.trim().isEmpty() || content == null || content.trim().isEmpty()) {
%>
        <script>
            alert("제목과 내용을 모두 입력해주세요.");
            history.back();
        </script>
<%
        return;
    }

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "C##dbexam", "m1234");
        conn.setAutoCommit(false); // 수동 커밋 모드

        // 현재 board 테이블 규격: num, id, name, subject, content, hit, ip, regist_day, update_day
        String sql = "INSERT INTO board (num, id, name, subject, content, hit, ip, regist_day, update_day) "
                   + "VALUES (num.NEXTVAL, ?, ?, ?, ?, 0, ?, SYSDATE, SYSDATE)";
        
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, id.trim());
        pstmt.setString(2, name.trim());
        pstmt.setString(3, subject.trim());
        pstmt.setString(4, content.trim());
        pstmt.setString(5, ip);

        int result = pstmt.executeUpdate();

        if (result > 0) {
            conn.commit(); // DB 영구 저장 확정
%>
            <script>
                alert("게시글이 성공적으로 등록되었습니다!");
                location.href = "list.jsp";
            </script>
<%
        } else {
            conn.rollback();
%>
            <script>
                alert("게시글 등록에 실패했습니다.");
                history.back();
            </script>
<%
        }
    } catch (Exception e) {
        if (conn != null) try { conn.rollback(); } catch (Exception ex) {}
        e.printStackTrace();
        String errMsg = (e.getMessage() != null) ? e.getMessage().replace("\"", "'").replace("\r", " ").replace("\n", " ") : "알 수 없는 오류";
%>
        <script>
            alert("게시글 저장 중 DB 에러:\n<%= errMsg %>");
            history.back();
        </script>
<%
    } finally {
        if (pstmt != null) try { pstmt.close(); } catch (Exception e) {}
        if (conn != null) try { conn.close(); } catch (Exception e) {}
    }
%>